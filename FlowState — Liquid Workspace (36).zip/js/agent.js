/* ============================================================
   agent.js — FlowState Module Agent IA
   IA spécialisée avec commandes vocales & accès inter-modules
   ============================================================ */

(function () {
  'use strict';

  /* ── Garde d'initialisation ─────────────────────────── */
  let agentInited = false;

  /* ── Observer MutationObserver ──────────────────────── */
  const viewEl = document.getElementById('view-agent');
  if (viewEl) {
    const obs = new MutationObserver(m => {
      m.forEach(mut => {
        if (mut.attributeName === 'class' &&
            !mut.target.classList.contains('view-hidden') &&
            !agentInited) {
          setTimeout(tryInit, 60);
        }
      });
    });
    obs.observe(viewEl, { attributes: true });
    if (!viewEl.classList.contains('view-hidden')) tryInit();
  }
  document.addEventListener('click', e => {
    if (e.target.closest('[data-view="agent"]')) setTimeout(tryInit, 60);
  });

  function tryInit() {
    if (agentInited) return;
    agentInited = true;
    initAgent();
  }

  /* ── État global ────────────────────────────────────── */
  const STATE = {
    mode: 'idle',        // idle | listening | thinking | speaking
    voiceEnabled: false,
    messages: [],
    actionHistory: [],
    activeSector: null,
  };

  /* ── Données secteurs ───────────────────────────────── */
  const SECTORS = [
    {
      id: 'dashboard', name: 'Tableau de bord', view: 'dashboard',
      desc: 'KPIs, flows actifs, score',
      color: '#818cf8',
      bg: 'rgba(129,140,248,.15)',
      icon: `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <rect x="2" y="2" width="7" height="7" rx="1.5"/><rect x="11" y="2" width="7" height="7" rx="1.5"/>
        <rect x="2" y="11" width="7" height="7" rx="1.5"/><rect x="11" y="11" width="7" height="7" rx="1.5"/>
      </svg>`,
    },
    {
      id: 'projets', name: 'Projets', view: 'projets',
      desc: 'Tâches, sprints, burndown',
      color: '#a78bfa',
      bg: 'rgba(167,139,250,.15)',
      icon: `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <path d="M4 5h12M4 10h8M4 15h6"/>
      </svg>`,
    },
    {
      id: 'equipes', name: 'Équipes', view: 'equipes',
      desc: 'Membres, tâches, progression',
      color: '#22d3ee',
      bg: 'rgba(34,211,238,.15)',
      icon: `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <circle cx="7" cy="7" r="3"/><circle cx="14" cy="7" r="2.5"/>
        <path d="M1 17c0-3 2.7-5 6-5s6 2 6 5"/><path d="M14 12c2.5 0 5 1.5 5 4"/>
      </svg>`,
    },
    {
      id: 'calendrier', name: 'Calendrier', view: 'calendrier',
      desc: 'Événements, plannings, partages',
      color: '#fbbf24',
      bg: 'rgba(251,191,36,.15)',
      icon: `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <rect x="3" y="4" width="14" height="14" rx="2"/>
        <path d="M3 8h14M7 4V2M13 4V2"/>
      </svg>`,
    },
    {
      id: 'finance', name: 'Finances', view: 'finance',
      desc: 'Budget, dépenses, revenus',
      color: '#34d399',
      bg: 'rgba(52,211,153,.15)',
      icon: `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5">
        <rect x="2" y="5" width="16" height="11" rx="2"/>
        <path d="M2 8h16" stroke-linecap="round"/>
        <circle cx="6" cy="12" r="1" fill="currentColor"/>
      </svg>`,
    },
  ];

  /* ── Commandes vocales ──────────────────────────────── */
  const COMMANDS = [
    {
      patterns: ['ouvre', 'va vers', 'affiche', 'montre', 'navigue vers'],
      sectors: {
        'tableau de bord': 'dashboard',
        'dashboard': 'dashboard',
        'projets': 'projets',
        'projet': 'projets',
        'équipes': 'equipes',
        'equipes': 'equipes',
        'équipe': 'equipes',
        'calendrier': 'calendrier',
        'agenda': 'calendrier',
        'finances': 'finance',
        'finance': 'finance',
        'agent': 'agent',
        'ia': 'agent',
      },
      handler: (text) => navigateTo(text),
    },
    {
      patterns: ['crée', 'ajoute', 'planifie', 'nouveau', 'nouvelle'],
      handler: (text) => handleCreate(text),
    },
    {
      patterns: ['analyse', 'rapport', 'résumé', 'synthèse', 'bilan'],
      handler: (text) => handleAnalysis(text),
    },
    {
      patterns: ['recommande', 'conseille', 'suggère', 'aide', 'optimise'],
      handler: (text) => handleRecommendation(text),
    },
    {
      patterns: ['bonjour', 'salut', 'hello', 'hey'],
      handler: () => handleGreeting(),
    },
    {
      patterns: ['merci', 'parfait', 'bien', 'ok'],
      handler: () => handleAck(),
    },
  ];

  /* ── Réponses IA ────────────────────────────────────── */
  const AI_RESPONSES = {
    greeting: [
      "Bonjour ! Je suis ARIA, votre agent IA FlowState. Je peux naviguer entre vos secteurs, créer des événements, analyser vos projets et vous donner des recommandations. Comment puis-je vous aider ?",
      "Salut ! ARIA à votre service. J'ai accès à tous vos secteurs — projets, équipes, calendrier et finances. Quelle est votre mission du jour ?",
    ],
    ack: [
      "Parfait ! N'hésitez pas si vous avez besoin d'autre chose.",
      "Avec plaisir. Je reste disponible pour toute action ou analyse.",
      "Super ! Votre espace FlowState est toujours optimisé et prêt.",
    ],
    navigate: (sector) => [
      `Je vous oriente vers **${sector.name}**. Section chargée — vous pouvez maintenant interagir avec vos ${sector.desc.toLowerCase()}.`,
      `Navigation vers **${sector.name}** effectuée. Que souhaitez-vous faire dans cette section ?`,
    ],
    create_event: [
      "Je peux créer un événement dans votre calendrier. Donnez-moi le titre, la date et l'heure, et je l'ajoute immédiatement.",
      "Pour créer un événement, dites-moi : titre, date, heure de début et de fin. Je l'intègre dans votre calendrier partagé.",
    ],
    create_task: [
      "Création de tâche en cours. Précisez le projet, l'assignataire et l'échéance pour que j'organise tout correctement.",
      "Je vais ajouter cette tâche à vos projets actifs. Quel membre de l'équipe souhaitez-vous assigner ?",
    ],
    analysis_projects: [
      "**Analyse Projets** — Vous avez 4 projets actifs. Le Pipeline d'intégration IA progresse à 91% et est en bonne voie. La Feuille de route produit Q2 (72%) nécessite une attention particulière — 4 tâches critiques restent ouvertes. Je recommande de prioriser ces blocages avant la fin du sprint.",
      "**Synthèse Projets** — Taux de complétion moyen : 68%. Sprint Identité de marque présente du retard (38%). Suggestion : redistribuer 2 tâches à Jean Parent qui dispose de capacité disponible cette semaine.",
    ],
    analysis_finance: [
      "**Bilan Financier** — Budget mensuel utilisé à 67%. Trois postes de dépenses dépassent les prévisions : outils SaaS (+12%), freelances (+8%), marketing (+5%). Recommandation : renegocier les abonnements non utilisés pour économiser ~340€/mois.",
      "**Analyse Finances** — Revenus Q1 en hausse de 18% vs objectif. La marge opérationnelle se situe à 23%. Attention : 2 factures clients en attente depuis plus de 30 jours représentent 4200€ à relancer.",
    ],
    analysis_team: [
      "**Rapport Équipes** — 5 membres actifs. Alex Klass et Marie Leclerc affichent les taux de complétion les plus élevés (>85%). Tom Rioux a 3 tâches en retard — une discussion de suivi est recommandée. La vélocité d'équipe globale est en progression de +12% ce mois.",
      "**Synthèse Équipes** — 25 tâches en cours, 20 terminées ce mois. Le taux de retard global est de 12%. Recommandation : tenir un stand-up de 15 min pour aligner les priorités.",
    ],
    analysis_calendar: [
      "**Vue Calendrier** — 19 événements ce mois d'avril. Semaine prochaine : 4 réunions planifiées. Point d'attention : le 15 avril, vous avez 3 événements simultanés entre 14h et 15h30. Je peux réorganiser certains créneaux si nécessaire.",
      "**Analyse Planning** — Vos créneaux les plus chargés sont les mardis et jeudis matin. Les vendredis après-midi sont systématiquement libres — idéal pour des sessions de travail profond ou rétrospectives d'équipe.",
    ],
    recommendation_project: [
      "**Recommandations Projets**\n\n1. Démarrez chaque sprint par une session de priorisation de 30 min\n2. Utilisez la méthode MoSCoW pour classifier les tâches critiques\n3. Le Pipeline IA est à 91% — planifiez la revue finale cette semaine\n4. Assignez un responsable unique par livrable pour réduire les ambiguïtés",
      "**Plan d'action suggéré**\n\n→ Cette semaine : finir les 4 tâches critiques du projet produit\n→ Mardi : réunion de synchronisation équipe (30 min)\n→ Vendredi : revue de sprint et planification Q3\n→ Bloquer 2h de Deep Work quotidien pour chaque développeur",
    ],
    recommendation_team: [
      "**Optimisation Équipe**\n\n1. Sara Khalil est en sous-charge cette semaine — idéale pour absorber les tâches en retard\n2. Mise en place d'un système de pair-programming entre Jean et Tom\n3. Célébrer les 20 tâches terminées ce mois pour maintenir la motivation\n4. Considérer une formation React pour l'équipe frontend",
    ],
    default: [
      "Je traite votre demande en accédant aux données de FlowState. Voici ce que j'observe dans votre espace de travail...",
      "Analyse en cours de vos secteurs. Je croise les données de vos projets, calendrier et équipes pour vous donner la meilleure réponse.",
      "Bonne question ! En tant qu'agent IA spécialisé FlowState, j'analyse le contexte de votre workspace. Voici mes observations et recommandations...",
    ],
  };

  function randFrom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  /* ── Web Speech API ─────────────────────────────────── */
  let recognition = null;
  let isMicActive = false;

  function initSpeech() {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return false;

    recognition = new SpeechRecognition();
    recognition.lang = 'fr-FR';
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      setMode('listening');
      updateTranscript('En écoute...', true);
    };

    recognition.onresult = (e) => {
      let interim = '';
      let final = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript;
        if (e.results[i].isFinal) final += t;
        else interim += t;
      }
      if (interim) updateTranscript(interim, true);
      if (final) {
        updateTranscript(final, true);
        processVoiceInput(final.trim());
      }
    };

    recognition.onerror = (e) => {
      console.warn('Speech recognition error:', e.error);
      if (e.error === 'not-allowed') {
        addMessage('system', 'Accès au microphone refusé. Autorisez le microphone dans les paramètres du navigateur.');
      }
      stopMic();
    };

    recognition.onend = () => {
      if (isMicActive && STATE.mode === 'listening') {
        // Restart for continuous mode
        setTimeout(() => {
          if (isMicActive) recognition.start();
        }, 300);
      } else {
        stopMic();
      }
    };

    return true;
  }

  function startMic() {
    if (!recognition && !initSpeech()) {
      addMessage('system', 'La reconnaissance vocale n\'est pas supportée par ce navigateur. Utilisez Chrome ou Edge. Vous pouvez aussi taper vos commandes dans le champ ci-dessous.');
      return;
    }
    try {
      isMicActive = true;
      recognition.start();
      updateMicButtons(true);
    } catch (e) {
      console.warn('Mic start error:', e);
    }
  }

  function stopMic() {
    isMicActive = false;
    if (recognition) {
      try { recognition.stop(); } catch (e) {}
    }
    if (STATE.mode !== 'thinking' && STATE.mode !== 'speaking') {
      setMode('idle');
    }
    updateMicButtons(false);
    updateTranscript('', false);
  }

  function toggleMic() {
    if (isMicActive) stopMic();
    else startMic();
  }

  function updateMicButtons(active) {
    const mainBtn = document.getElementById('agent-mic-btn');
    const inlineBtn = document.getElementById('agent-mic-inline');
    if (mainBtn) {
      mainBtn.classList.toggle('active', active);
      const label = mainBtn.querySelector('.mic-btn-label');
      if (label) label.textContent = active ? 'Arrêter' : 'Commande vocale';
    }
    if (inlineBtn) inlineBtn.classList.toggle('active', active);
  }

  /* ── Synthèse vocale ────────────────────────────────── */
  function speak(text) {
    if (!window.speechSynthesis) return;
    const clean = text.replace(/\*\*/g, '').replace(/\n→/g, '.').replace(/\n\d+\./g, '.').replace(/\n/g, ' ');
    const utt = new SpeechSynthesisUtterance(clean);
    utt.lang = 'fr-FR';
    utt.rate = 1.05;
    utt.pitch = 1;

    // Choisir une voix française si disponible
    const voices = window.speechSynthesis.getVoices();
    const frVoice = voices.find(v => v.lang.startsWith('fr') && !v.name.includes('Google'))
      || voices.find(v => v.lang.startsWith('fr'));
    if (frVoice) utt.voice = frVoice;

    setMode('speaking');
    utt.onend = () => setMode('idle');
    utt.onerror = () => setMode('idle');
    window.speechSynthesis.speak(utt);
  }

  /* ── Modes visuels ──────────────────────────────────── */
  function setMode(mode) {
    STATE.mode = mode;
    const orb = document.getElementById('agent-orb');
    const status = document.getElementById('agent-orb-status');
    if (!orb || !status) return;

    orb.classList.remove('listening', 'thinking', 'speaking');
    status.classList.remove('active', 'listening', 'thinking', 'speaking');

    const labels = {
      idle: 'Cliquez pour activer',
      listening: 'En écoute...',
      thinking: 'Analyse en cours...',
      speaking: 'En train de répondre...',
    };

    if (mode !== 'idle') {
      orb.classList.add(mode);
      status.classList.add(mode);
    }
    status.textContent = labels[mode] || '';
  }

  function updateTranscript(text, active) {
    const el = document.getElementById('agent-transcript-live');
    if (!el) return;
    el.textContent = text || 'Parlez maintenant...';
    el.classList.toggle('active', active && !!text);
  }

  /* ── Traitement des commandes ───────────────────────── */
  function processVoiceInput(text) {
    if (!text) return;
    const lower = text.toLowerCase();
    updateTranscript('', false);

    addMessage('user', text);
    setMode('thinking');

    // Délai simulé "réflexion IA"
    const delay = 900 + Math.random() * 600;

    setTimeout(() => {
      let handled = false;

      // Détection navigation secteur
      for (const [keyword, viewId] of Object.entries(COMMANDS[0].sectors)) {
        if (lower.includes(keyword)) {
          const sector = SECTORS.find(s => s.view === viewId);
          if (sector) {
            handleNavigateToSector(sector);
            handled = true;
            break;
          }
        }
      }

      if (!handled) {
        // Détection analyse
        if (['analyse', 'rapport', 'résumé', 'synthèse', 'bilan'].some(p => lower.includes(p))) {
          handleAnalysisText(lower);
          handled = true;
        }
      }

      if (!handled) {
        // Détection recommandation
        if (['recommande', 'conseille', 'suggère', 'aide', 'optimise', 'comment'].some(p => lower.includes(p))) {
          handleRecommendationText(lower);
          handled = true;
        }
      }

      if (!handled) {
        // Détection création
        if (['crée', 'ajoute', 'planifie', 'nouveau', 'nouvelle', 'créer', 'ajouter'].some(p => lower.includes(p))) {
          handleCreateText(lower);
          handled = true;
        }
      }

      if (!handled) {
        // Salutation
        if (['bonjour', 'salut', 'hello', 'hey', 'coucou'].some(p => lower.startsWith(p))) {
          const resp = randFrom(AI_RESPONSES.greeting);
          addMessage('agent', resp);
          speak(resp.replace(/\*\*/g, '').split('.')[0]);
          handled = true;
        }
      }

      if (!handled) {
        // Réponse par défaut
        const resp = randFrom(AI_RESPONSES.default) + ' ' + generateContextualResponse(lower);
        addMessage('agent', resp);
      }

    }, delay);
  }

  function generateContextualResponse(text) {
    if (text.includes('projet')) return randFrom(AI_RESPONSES.analysis_projects);
    if (text.includes('equipe') || text.includes('équipe') || text.includes('membre')) return randFrom(AI_RESPONSES.analysis_team);
    if (text.includes('finance') || text.includes('budget') || text.includes('argent')) return randFrom(AI_RESPONSES.analysis_finance);
    if (text.includes('calendrier') || text.includes('agenda') || text.includes('réunion')) return randFrom(AI_RESPONSES.analysis_calendar);
    return "J'ai analysé l'ensemble de votre workspace FlowState. Vos métriques clés sont dans les objectifs. Souhaitez-vous un détail sur un secteur spécifique ?";
  }

  function handleNavigateToSector(sector) {
    const resp = randFrom(AI_RESPONSES.navigate(sector));
    addMessage('agent', resp, {
      action: `Navigation vers ${sector.name}`,
      sector,
    });

    // Naviguer réellement vers le secteur
    setTimeout(() => {
      if (typeof showView === 'function') {
        showView(sector.view);
        // Mettre à jour la nav active
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const navItem = document.querySelector(`[data-view="${sector.view}"]`);
        if (navItem) navItem.classList.add('active');
      }
    }, 1200);

    addToHistory(`Navigué vers ${sector.name}`, sector.color);
    highlightSector(sector.id);
    speak(resp.replace(/\*\*/g, '').split('.')[0]);
    setMode('idle');
  }

  function handleAnalysisText(text) {
    let resp;
    if (text.includes('projet')) resp = randFrom(AI_RESPONSES.analysis_projects);
    else if (text.includes('equipe') || text.includes('membre')) resp = randFrom(AI_RESPONSES.analysis_team);
    else if (text.includes('finance') || text.includes('budget')) resp = randFrom(AI_RESPONSES.analysis_finance);
    else if (text.includes('calendrier') || text.includes('agenda')) resp = randFrom(AI_RESPONSES.analysis_calendar);
    else resp = randFrom(AI_RESPONSES.analysis_projects);

    addMessage('agent', resp);
    addToHistory('Analyse générée', '#818cf8');
    speak(resp.replace(/\*\*/g, '').split('\n')[0]);
    setMode('idle');
  }

  function handleRecommendationText(text) {
    let resp;
    if (text.includes('equipe') || text.includes('membre')) resp = randFrom(AI_RESPONSES.recommendation_team);
    else resp = randFrom(AI_RESPONSES.recommendation_project);

    addMessage('agent', resp);
    addToHistory('Recommandation fournie', '#a78bfa');
    speak(resp.replace(/\*\*/g, '').split('\n')[0]);
    setMode('idle');
  }

  function handleCreateText(text) {
    let resp;
    if (text.includes('événement') || text.includes('reunion') || text.includes('réunion') || text.includes('rendez-vous')) {
      resp = randFrom(AI_RESPONSES.create_event);
      addMessage('agent', resp, { action: 'Ouvrir le calendrier pour créer un événement', sector: SECTORS.find(s => s.id === 'calendrier') });
    } else if (text.includes('tâche') || text.includes('task')) {
      resp = randFrom(AI_RESPONSES.create_task);
      addMessage('agent', resp, { action: 'Ouvrir les projets pour créer une tâche', sector: SECTORS.find(s => s.id === 'projets') });
    } else {
      resp = "Que souhaitez-vous créer ? Un événement dans le calendrier, une tâche dans les projets, ou autre chose ?";
      addMessage('agent', resp);
    }
    addToHistory('Action de création initiée', '#34d399');
    speak(resp.split('.')[0]);
    setMode('idle');
  }

  /* Wrappers pour les boutons de commandes rapides */
  function navigateTo(text) { processVoiceInput(text); }
  function handleCreate(text) { processVoiceInput(text); }
  function handleAnalysis(text) { processVoiceInput(text); }
  function handleRecommendation(text) { processVoiceInput(text); }
  function handleGreeting() { processVoiceInput('bonjour'); }
  function handleAck() {
    const resp = randFrom(AI_RESPONSES.ack);
    addMessage('agent', resp);
    speak(resp);
  }

  /* ── Messages UI ─────────────────────────────────────── */
  function addMessage(role, text, extra) {
    const id = 'msg-' + Date.now();
    STATE.messages.push({ id, role, text, extra, ts: new Date() });
    renderMessage({ id, role, text, extra, ts: new Date() });
    scrollChat();
  }

  function renderMessage({ id, role, text, extra }) {
    const body = document.getElementById('agent-chat-body');
    if (!body) return;

    // Supprimer le thinking si présent
    const thinking = body.querySelector('.agent-thinking');
    if (thinking) thinking.remove();

    const isAgent = role === 'agent';
    const isSystem = role === 'system';
    const initiales = isAgent ? 'IA' : isSystem ? '⚙' : 'AK';

    // Formater le texte markdown léger
    const formatted = text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\n→ /g, '<br><span style="color:rgba(255,255,255,.4)">→</span> ')
      .replace(/\n(\d+)\./g, '<br><strong style="color:var(--c-indigo,#818cf8)">$1.</strong>')
      .replace(/\n/g, '<br>');

    const now = new Date();
    const hm = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;

    let actionHTML = '';
    if (extra?.action && extra?.sector) {
      actionHTML = `
        <div class="agent-action-card">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M8 3v10M3 8h10"/>
          </svg>
          <span>${extra.action}</span>
          <span class="agent-sector-badge">
            <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" width="10" height="10">
              <path d="M2 6h8M6 2l4 4-4 4"/>
            </svg>
            ${extra.sector.name}
          </span>
        </div>`;
    }

    const el = document.createElement('div');
    el.className = `agent-msg${isAgent ? '' : ' user'}`;
    el.id = id;
    el.innerHTML = `
      <div class="agent-msg-avatar">${initiales}</div>
      <div class="agent-msg-content">
        <div class="agent-msg-bubble">${formatted}${actionHTML}</div>
        <div class="agent-msg-time">${hm}</div>
      </div>`;
    body.appendChild(el);
  }

  function showThinking() {
    const body = document.getElementById('agent-chat-body');
    if (!body || body.querySelector('.agent-thinking')) return;
    const el = document.createElement('div');
    el.className = 'agent-msg agent-thinking';
    el.innerHTML = `
      <div class="agent-msg-avatar">IA</div>
      <div class="agent-msg-content">
        <div class="agent-msg-bubble">
          <div class="agent-thinking-dots">
            <span></span><span></span><span></span>
          </div>
        </div>
      </div>`;
    body.appendChild(el);
    scrollChat();
  }

  // Surcharger setMode pour montrer les dots
  const _setMode = setMode;

  function scrollChat() {
    const body = document.getElementById('agent-chat-body');
    if (body) body.scrollTop = body.scrollHeight;
  }

  /* ── Historique actions ──────────────────────────────── */
  function addToHistory(text, color) {
    const now = new Date();
    const hm = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
    STATE.actionHistory.unshift({ text, color, time: hm });
    if (STATE.actionHistory.length > 8) STATE.actionHistory.pop();
    renderHistory();
  }

  function renderHistory() {
    const el = document.getElementById('agent-history-list');
    if (!el) return;
    el.innerHTML = STATE.actionHistory.map(h => `
      <div class="agent-history-item">
        <div class="agent-history-dot" style="background:${h.color}"></div>
        <div class="agent-history-text">${h.text}</div>
        <div class="agent-history-time">${h.time}</div>
      </div>`).join('');
  }

  /* ── Secteurs sidebar ────────────────────────────────── */
  function renderSectors() {
    const el = document.getElementById('agent-sectors-list');
    if (!el) return;
    el.innerHTML = SECTORS.map(s => `
      <div class="agent-sector-item" data-sector-id="${s.id}">
        <div class="agent-sector-icon" style="background:${s.bg};color:${s.color}">
          ${s.icon}
        </div>
        <div class="agent-sector-info">
          <div class="agent-sector-name">${s.name}</div>
          <div class="agent-sector-desc">${s.desc}</div>
        </div>
        <div class="agent-sector-access"></div>
      </div>`).join('');

    // Listeners
    el.querySelectorAll('.agent-sector-item').forEach(item => {
      item.addEventListener('click', () => {
        const sector = SECTORS.find(s => s.id === item.dataset.sectorId);
        if (sector) {
          highlightSector(sector.id);
          addMessage('user', `Ouvre ${sector.name}`);
          setTimeout(() => handleNavigateToSector(sector), 400);
        }
      });
    });
  }

  function highlightSector(id) {
    document.querySelectorAll('.agent-sector-item').forEach(el => {
      el.classList.toggle('active', el.dataset.sectorId === id);
    });
    STATE.activeSector = id;
  }

  /* ── Suggestions rapides ─────────────────────────────── */
  const SUGGESTIONS = [
    { label: 'Analyse mes projets', icon: '📊', text: 'Analyse mes projets en cours' },
    { label: 'Rapport équipes', icon: '👥', text: 'Donne-moi un rapport sur mes équipes' },
    { label: 'Planifier Q2', icon: '📅', text: 'Recommande-moi un plan pour le Q2' },
    { label: 'Bilan finances', icon: '💰', text: 'Synthèse financière du mois' },
    { label: 'Optimiser équipe', icon: '⚡', text: 'Comment optimiser la performance de mon équipe' },
    { label: 'Prochaines tâches', icon: '✅', text: 'Quelles sont les tâches prioritaires cette semaine' },
  ];

  function renderSuggestions() {
    const el = document.getElementById('agent-suggestions');
    if (!el) return;
    el.innerHTML = SUGGESTIONS.map(s => `
      <button class="agent-suggest-btn" data-text="${s.text}">
        <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5" width="11" height="11">
          <path d="M2 6h8M6 2l4 4-4 4"/>
        </svg>
        ${s.icon} ${s.label}
      </button>`).join('');

    el.querySelectorAll('.agent-suggest-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const text = btn.dataset.text;
        if (STATE.mode === 'thinking') return;
        processVoiceInput(text);
      });
    });
  }

  /* ── Message de bienvenue ────────────────────────────── */
  function sendWelcome() {
    setTimeout(() => {
      setMode('thinking');
      setTimeout(() => {
        const resp = randFrom(AI_RESPONSES.greeting);
        addMessage('agent', resp);
        setMode('idle');
        addToHistory('Session démarrée', '#818cf8');
      }, 800);
    }, 300);
  }

  /* ── Input texte ─────────────────────────────────────── */
  function bindInputs() {
    const input = document.getElementById('agent-text-input');
    const sendBtn = document.getElementById('agent-send-btn');
    const micBtn = document.getElementById('agent-mic-btn');
    const micInline = document.getElementById('agent-mic-inline');
    const clearBtn = document.getElementById('agent-clear-chat');

    if (sendBtn) {
      sendBtn.addEventListener('click', () => {
        const text = input?.value?.trim();
        if (!text || STATE.mode === 'thinking') return;
        input.value = '';
        processVoiceInput(text);
      });
    }

    if (input) {
      input.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          const text = input.value.trim();
          if (!text || STATE.mode === 'thinking') return;
          input.value = '';
          processVoiceInput(text);
        }
      });
    }

    if (micBtn) micBtn.addEventListener('click', toggleMic);
    if (micInline) micInline.addEventListener('click', toggleMic);

    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        const body = document.getElementById('agent-chat-body');
        if (body) body.innerHTML = '';
        STATE.messages = [];
        sendWelcome();
      });
    }

    // Clic sur l'orbe
    const orb = document.getElementById('agent-orb');
    if (orb) orb.addEventListener('click', toggleMic);
  }

  /* ── Init principale ─────────────────────────────────── */
  function initAgent() {
    renderSectors();
    renderSuggestions();
    bindInputs();
    sendWelcome();
    renderHistory();

    // Charger les voix TTS en avance
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
    }
  }

})();
