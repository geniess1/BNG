/* ═══════════════════════════════════════════════════════════
   FlowState — App Interactions
   Hover states, animations, timer, modals, toasts
   ═══════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── SVG gradient for timer ─────────────────────────── */
  const timerSVG = document.querySelector('.timer-ring');
  if (timerSVG) {
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    defs.innerHTML = `
      <linearGradient id="timer-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%"   stop-color="#a78bfa"/>
        <stop offset="100%" stop-color="#22d3ee"/>
      </linearGradient>`;
    timerSVG.prepend(defs);
  }

  /* ── Theme Toggle ───────────────────────────────────── */
  const html = document.documentElement;
  let currentTheme = 'dark';
  const themeBtn = document.querySelector('[data-theme-toggle]');
  function setTheme(t) {
    currentTheme = t;
    html.setAttribute('data-theme', t);
    if (themeBtn) {
      themeBtn.innerHTML = t === 'dark'
        ? `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`
        : `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>`;
    }
  }
  themeBtn && themeBtn.addEventListener('click', () => setTheme(currentTheme === 'dark' ? 'light' : 'dark'));

  /* ── Liquid button mouse tracking ───────────────────── */
  document.querySelectorAll('.liquid-btn').forEach(btn => {
    btn.addEventListener('mousemove', e => {
      const r = btn.getBoundingClientRect();
      btn.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
      btn.style.setProperty('--my', ((e.clientY - r.top)  / r.height * 100) + '%');
    });
  });

  /* ── Ripple on click ────────────────────────────────── */
  function addRipple(el) {
    el.addEventListener('click', e => {
      const r = el.getBoundingClientRect();
      const span = document.createElement('span');
      const size = Math.max(r.width, r.height);
      span.className = 'ripple-burst';
      span.style.cssText = `
        width:${size}px; height:${size}px;
        left:${e.clientX - r.left - size/2}px;
        top:${e.clientY - r.top - size/2}px;
      `;
      el.appendChild(span);
      setTimeout(() => span.remove(), 700);
    });
  }
  document.querySelectorAll('.liquid-btn, .btn-primary').forEach(addRipple);

  /* ── Nav switching géré par le loader central (index.html) ── */
  // Supprimé ici pour éviter les conflits d'écouteurs dupliqués

  /* ── Sidebar toggle ─────────────────────────────────── */
  const sidebar = document.getElementById('sidebar');
  const sidebarToggle = document.getElementById('sidebar-toggle');
  let sidebarOpen = true;
  sidebarToggle && sidebarToggle.addEventListener('click', () => {
    sidebarOpen = !sidebarOpen;
    sidebar && sidebar.classList.toggle('collapsed', !sidebarOpen);
  });

  /* ── Stat count-up ──────────────────────────────────── */
  function countUp(el, target, duration = 900) {
    const start = performance.now();
    const update = (ts) => {
      const p = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(ease * target);
      if (p < 1) requestAnimationFrame(update);
      else el.textContent = target;
    };
    requestAnimationFrame(update);
  }

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count, 10);
        if (!isNaN(target)) countUp(el, target);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.2, rootMargin: "0px 0px -20px 0px" });

  document.querySelectorAll('[data-count]').forEach(el => observer.observe(el));

  /* ── Focus Timer ────────────────────────────────────── */
  const TIMER_TOTAL = 25 * 60; // 25 min in seconds
  let timerSeconds = 24 * 60 + 37; // start offset
  let timerRunning = true;
  let timerInterval;

  const timerDisplay   = document.getElementById('timer-display');
  const timerCircle    = document.getElementById('timer-progress-circle');
  const timerPauseBtn  = document.getElementById('timer-pause');
  const CIRCUMFERENCE  = 2 * Math.PI * 52; // r=52

  function updateTimerUI() {
    const m = Math.floor(timerSeconds / 60);
    const s = timerSeconds % 60;
    if (timerDisplay) timerDisplay.textContent = `${m}:${String(s).padStart(2,'0')}`;
    if (timerCircle) {
      const progress = timerSeconds / TIMER_TOTAL;
      timerCircle.style.strokeDashoffset = CIRCUMFERENCE * (1 - progress);
    }
  }

  function tickTimer() {
    if (!timerRunning) return;
    timerSeconds = Math.max(0, timerSeconds - 1);
    updateTimerUI();
    if (timerSeconds === 0) {
      clearInterval(timerInterval);
      timerRunning = false;
      showToast('Session terminée ! Prends une pause.', 'violet');
    }
  }

  updateTimerUI();
  timerInterval = setInterval(tickTimer, 1000);

  timerPauseBtn && timerPauseBtn.addEventListener('click', () => {
    timerRunning = !timerRunning;
    timerPauseBtn.innerHTML = timerRunning
      ? `<svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><rect x="5" y="4" width="3" height="12" rx="1.5"/><rect x="12" y="4" width="3" height="12" rx="1.5"/></svg>`
      : `<svg viewBox="0 0 20 20" fill="currentColor" width="18" height="18"><path d="M6 4l10 6-10 6V4z"/></svg>`;
    showToast(timerRunning ? 'Minuteur repris' : 'Minuteur en pause');
  });

  /* ── Notification Drawer ────────────────────────────── */
  const notifBtn    = document.getElementById('notif-btn');
  const notifDrawer = document.getElementById('notif-drawer');
  const markAllRead = document.getElementById('mark-all-read');
  let drawerOpen = false;

  function openDrawer() {
    drawerOpen = true;
    notifDrawer.classList.add('open');
    notifDrawer.setAttribute('aria-hidden', 'false');
  }

  function closeDrawer() {
    drawerOpen = false;
    notifDrawer.classList.add('closing');
    notifDrawer.setAttribute('aria-hidden', 'true');
    setTimeout(() => {
      notifDrawer.classList.remove('open', 'closing');
    }, 280);
  }

  notifBtn && notifBtn.addEventListener('click', e => {
    e.stopPropagation();
    drawerOpen ? closeDrawer() : openDrawer();
  });

  markAllRead && markAllRead.addEventListener('click', () => {
    document.querySelectorAll('.notif-item.unread').forEach(item => item.classList.remove('unread'));
    const dot = document.querySelector('.notif-dot');
    if (dot) dot.style.display = 'none';
    showToast('Toutes les notifications lues');
  });

  document.addEventListener('click', e => {
    if (drawerOpen && !notifDrawer.contains(e.target) && e.target !== notifBtn) {
      closeDrawer();
    }
  });

  /* ── Command Palette ────────────────────────────────── */
  const cmdBtn     = document.getElementById('command-btn');
  const cmdOverlay = document.getElementById('cmd-overlay');
  const cmdModal   = document.getElementById('cmd-modal');
  const cmdInput   = document.getElementById('cmd-input');
  const searchTrigger = document.getElementById('search-trigger');

  function openCmd() {
    cmdOverlay.classList.add('open');
    cmdOverlay.setAttribute('aria-hidden', 'false');
    setTimeout(() => cmdInput && cmdInput.focus(), 50);
  }

  function closeCmd() {
    cmdOverlay.classList.remove('open');
    cmdOverlay.setAttribute('aria-hidden', 'true');
    if (cmdInput) cmdInput.value = '';
  }

  cmdBtn && cmdBtn.addEventListener('click', openCmd);
  searchTrigger && searchTrigger.addEventListener('click', openCmd);

  cmdOverlay && cmdOverlay.addEventListener('click', e => {
    if (!cmdModal.contains(e.target)) closeCmd();
  });

  /* Keyboard shortcuts */
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); openCmd(); }
    if (e.key === 'Escape') { closeCmd(); closeDrawer(); }
  });

  /* Cmd item navigation */
  const cmdItems = document.querySelectorAll('.cmd-item');
  let cmdActive = 0;
  cmdInput && cmdInput.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') {
      cmdActive = (cmdActive + 1) % cmdItems.length;
      cmdItems.forEach((el, i) => el.classList.toggle('active', i === cmdActive));
    }
    if (e.key === 'ArrowUp') {
      cmdActive = (cmdActive - 1 + cmdItems.length) % cmdItems.length;
      cmdItems.forEach((el, i) => el.classList.toggle('active', i === cmdActive));
    }
    if (e.key === 'Enter') {
      closeCmd();
      showToast('Action exécutée');
    }
  });

  /* ── Quick Capture ──────────────────────────────────── */
  const captureInput  = document.getElementById('capture-input');
  const captureSubmit = document.getElementById('capture-submit');
  const tagChips      = document.querySelectorAll('.tag-chip');

  tagChips.forEach(chip => {
    chip.addEventListener('click', () => {
      tagChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    });
  });

  captureSubmit && captureSubmit.addEventListener('click', () => {
    const text = captureInput ? captureInput.value.trim() : '';
    if (!text) {
      captureInput && captureInput.animate([
        { transform: 'translateX(-4px)' }, { transform: 'translateX(4px)' },
        { transform: 'translateX(-3px)' }, { transform: 'translateX(0)' }
      ], { duration: 300 });
      return;
    }
    // Add to stream
    addStreamItem(text);
    captureInput.value = '';
    showToast('Capture enregistrée !');
  });

  /* ── New Flow button ────────────────────────────────── */
  const newFlowBtn = document.getElementById('new-flow-btn');
  newFlowBtn && newFlowBtn.addEventListener('click', () => {
    showToast('Nouveau flow créé ✦', 'violet');
  });

  /* ── Dynamic stream item ────────────────────────────── */
  function addStreamItem(text) {
    const feed = document.getElementById('stream-feed');
    if (!feed) return;
    const item = document.createElement('div');
    item.className = 'stream-item';
    item.style.setProperty('--delay', '0s');
    item.innerHTML = `
      <div class="stream-avatar rose">AK</div>
      <div class="stream-content">
        <strong>Vous</strong> avez capturé : <em>${escapeHtml(text)}</em>
        <span class="stream-time">À l'instant</span>
      </div>
      <div class="stream-tag tag-insight">Capture</div>`;
    feed.prepend(item);
    item.animate([
      { opacity: 0, transform: 'translateX(-12px)' },
      { opacity: 1, transform: 'translateX(0)' }
    ], { duration: 400, easing: 'cubic-bezier(0.16,1,0.3,1)', fill: 'both' });
  }

  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  /* ── Flow item hover glow ───────────────────────────── */
  document.querySelectorAll('.flow-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
      item.style.transition = 'background 180ms ease, box-shadow 180ms ease';
    });
  });

  /* ── Toast ──────────────────────────────────────────── */
  function showToast(msg, type = 'default') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const iconSvg = type === 'violet'
      ? `<svg class="toast-icon violet" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M10 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4L10 14.4l-4.8 2.5.9-5.4L2.2 7.7l5.4-.8z"/></svg>`
      : `<svg class="toast-icon" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M4 10l4 4 8-8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

    const toast = document.createElement('div');
    toast.className = 'toast';
    // Utiliser textContent pour le span au lieu de innerHTML (XSS safe + plus rapide)
    const icon = document.createElement('span');
    icon.innerHTML = iconSvg;
    const txt = document.createElement('span');
    txt.textContent = msg;
    toast.append(icon, txt);
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('removing');
      setTimeout(() => toast.remove(), 280);
    }, 2800);
  }

  /* ── Staggered card entrance ───────────────────────── */
  function animateIn(selector, stagger = 60) {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.animate([
        { opacity: 0, transform: 'translateY(12px)' },
        { opacity: 1, transform: 'translateY(0)' }
      ], {
        duration: 500,
        delay: i * stagger,
        easing: 'cubic-bezier(0.16,1,0.3,1)',
        fill: 'both'
      });
    });
  }

  // Animations d'entrée différées (non bloquantes)
  // Utilise requestIdleCallback pour ne pas bloquer le thread principal
  const scheduleIdle = typeof requestIdleCallback !== 'undefined'
    ? requestIdleCallback
    : (cb) => setTimeout(cb, 100);

  scheduleIdle(() => {
    animateIn('.stat-card', 55);
    animateIn('.glass-card.panel', 70);
  }, { timeout: 1000 });

  /* ── Flow progress bar animation (delayed) ───────────── */
  document.querySelectorAll('.flow-bar').forEach((bar, i) => {
    bar.style.setProperty('--bar-delay', `${0.3 + i * 0.12}s`);
  });

  /* Initial toast */
  setTimeout(() => showToast('Bienvenue dans FlowState ✦', 'violet'), 800);

})();
