/**
 * FlowState — IA Rédaction Courriel (ARIA Mail Assistant)
 * Suggestion, amélioration, reformulation, traduction, ton
 * Fonctionne en mode offline avec templates intelligents
 */

(function () {
  'use strict';

  /* ─────────────────────────────────────────────
     ÉTAT
  ───────────────────────────────────────────── */
  const ia = {
    open: false,
    tone: 'professionnel',
    history: [],
    thinking: false
  };

  /* ─────────────────────────────────────────────
     TEMPLATES IA PAR CATÉGORIE ET TON
  ───────────────────────────────────────────── */

  const TONS = {
    professionnel: {
      label: 'Professionnel',
      intro: ['Bonjour', 'Chère/Cher', 'Madame, Monsieur'],
      closing: ['Cordialement', 'Bien à vous', 'Avec mes salutations distinguées']
    },
    amical: {
      label: 'Amical',
      intro: ['Salut', 'Bonjour', 'Hey'],
      closing: ['À bientôt', 'Bonne journée', 'Bises']
    },
    formel: {
      label: 'Formel',
      intro: ['Madame, Monsieur', 'À qui de droit', 'Chère équipe'],
      closing: ['Veuillez agréer mes salutations distinguées', 'Dans l\'attente de votre retour', 'Je vous prie d\'accepter mes cordiales salutations']
    },
    concis: {
      label: 'Concis',
      intro: ['Bonjour', 'Bonjour à tous'],
      closing: ['Merci', 'Bonne journée', 'À bientôt']
    },
    persuasif: {
      label: 'Persuasif',
      intro: ['Bonjour', 'Cher(e) partenaire', 'Cher(e) client(e)'],
      closing: ['J\'attends avec impatience votre retour', 'N\'hésitez pas à me contacter', 'Je reste disponible pour en discuter']
    }
  };

  function getTon() {
    return TONS[ia.tone] || TONS.professionnel;
  }

  function randomFrom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  /* ─────────────────────────────────────────────
     GÉNÉRATEUR DE CONTENU IA (offline simulé)
  ───────────────────────────────────────────── */

  const TEMPLATES = {

    rediger: function (subject, to) {
      const ton = getTon();
      const intro = randomFrom(ton.intro);
      const closing = randomFrom(ton.closing);
      const dest = to ? to.split('@')[0].split('.')[0] : '';
      const destCapit = dest ? dest.charAt(0).toUpperCase() + dest.slice(1) : '';

      const corps = {
        professionnel: `Je me permets de vous contacter au sujet de "${subject || 'notre projet en cours'}".\n\nSuite à nos échanges récents, je souhaitais faire le point sur l\'avancement et convenir des prochaines étapes.\n\nPourriez-vous me confirmer vos disponibilités pour un appel cette semaine ?\n\nJe reste à votre disposition pour toute question.`,
        amical: `Comment ça va ?\n\nJe t'écris au sujet de "${subject || 'notre projet'}". On devrait se synchroniser rapidement là-dessus.\n\nTu es disponible pour un appel rapide cette semaine ? Je suis flexible.\n\nHâte d'avoir ton retour !`,
        formel: `Je vous contacte concernant "${subject || 'l\'affaire susmentionnée'}".\n\nConformément à nos engagements respectifs, il me semble opportun de procéder à un point de situation et de définir ensemble les actions à entreprendre dans les meilleurs délais.\n\nJe vous saurais gré de bien vouloir me faire part de vos disponibilités à cet effet.`,
        concis: `Concernant "${subject || 'le sujet en cours'}".\n\nPoint rapide nécessaire — disponible pour un appel de 15 min cette semaine ?`,
        persuasif: `J\'ai une excellente nouvelle concernant "${subject || 'notre collaboration'}" !\n\nNous avons identifié une opportunité qui pourrait considérablement accélérer vos résultats. Les bénéfices sont concrets et mesurables dès les premières semaines.\n\nJe serais ravi de vous présenter cela en détail — quand pouvons-nous échanger ?`
      };

      const body = corps[ia.tone] || corps.professionnel;
      const name = destCapit ? ' ' + destCapit + ',' : ',';

      return `${intro}${name}\n\n${body}\n\n${closing},\nAlex Klass`;
    },

    ameliorer: function (current) {
      if (!current || current.trim().length < 10) {
        return 'Veuillez d\'abord rédiger un contenu dans le champ de message pour que l\'IA puisse l\'améliorer.';
      }
      const ton = getTon();
      const closing = randomFrom(ton.closing);
      const intro = randomFrom(ton.intro);

      // Améliorer: restructurer le texte avec le ton choisi
      const lines = current.trim().split('\n').filter(l => l.trim());
      const mainContent = lines.slice(0, -1).join('\n') || current.trim();

      const prefixes = {
        professionnel: 'Suite à notre échange, je me permets de reformuler ce message de manière plus structurée :\n\n',
        amical: 'Voici une version plus naturelle et directe :\n\n',
        formel: 'Voici une formulation plus formelle et rigoureuse :\n\n',
        concis: 'Version condensée et percutante :\n\n',
        persuasif: 'Version optimisée pour convaincre :\n\n'
      };

      const improvements = {
        professionnel: `\n\nJ'espère que ce message vous trouvera en bonne forme. Je reste disponible pour tout renseignement complémentaire.`,
        amical: `\n\nN'hésite pas à me ping si tu as des questions !`,
        formel: `\n\nJe vous prie de bien vouloir me faire part de toute interrogation que vous pourriez avoir.`,
        concis: `\n\nMerci de votre retour rapide.`,
        persuasif: `\n\nCette opportunité est limitée dans le temps — je compte sur votre réponse rapide !`
      };

      return (prefixes[ia.tone] || prefixes.professionnel) + mainContent + (improvements[ia.tone] || improvements.professionnel) + '\n\n' + closing + ',\nAlex Klass';
    },

    raccourcir: function (current) {
      if (!current || current.trim().length < 20) {
        return 'Rédigez d\'abord un message pour que l\'IA puisse le résumer.';
      }
      // Extraire les idées clés
      const lines = current.trim().split('\n').filter(l => l.trim().length > 5);
      const keyLines = lines.slice(0, Math.ceil(lines.length / 2));
      const ton = getTon();

      return `${randomFrom(ton.intro)},\n\n${keyLines.join(' ').substring(0, 200).trim()}${keyLines.join(' ').length > 200 ? '...' : ''}\n\n${randomFrom(ton.closing)},\nAlex`;
    },

    objet: function (current, subject) {
      const ctx = (subject + ' ' + current).toLowerCase();
      const suggestions = [];

      if (ctx.includes('reun') || ctx.includes('meeting') || ctx.includes('appel')) {
        suggestions.push('Invitation — Réunion de coordination [Date à confirmer]');
        suggestions.push('Demande de disponibilités pour notre prochain échange');
      }
      if (ctx.includes('client') || ctx.includes('projet') || ctx.includes('proposi')) {
        suggestions.push('Proposition commerciale — Suite à notre échange');
        suggestions.push('Suivi de dossier — [Nom du projet]');
      }
      if (ctx.includes('rapport') || ctx.includes('bilan') || ctx.includes('rapport')) {
        suggestions.push('Rapport d\'avancement — Semaine du [Date]');
        suggestions.push('Bilan mensuel — Points clés et prochaines étapes');
      }
      if (ctx.includes('merci') || ctx.includes('remerci')) {
        suggestions.push('Merci pour notre échange — Prochaines étapes');
      }
      if (ctx.includes('urgent') || ctx.includes('important') || ctx.includes('priorit')) {
        suggestions.push('[URGENT] Action requise avant [Date]');
        suggestions.push('[PRIORITAIRE] Votre attention est requise');
      }

      if (suggestions.length === 0) {
        suggestions.push('Re: ' + (subject || 'Notre collaboration'));
        suggestions.push('Point d\'avancement — ' + new Date().toLocaleDateString('fr-CA', { month: 'long', year: 'numeric' }));
        suggestions.push('Information importante — À votre attention');
      }

      return 'Suggestions d\'objet :\n\n' + suggestions.map((s, i) => `${i + 1}. ${s}`).join('\n');
    },

    traduire: function (current) {
      if (!current || current.trim().length < 10) {
        return 'Rédigez un message en français pour le traduire.';
      }
      // Traduction simulée FR→EN basée sur des patterns courants
      const result = current
        .replace(/Bonjour/gi, 'Hello')
        .replace(/Cordialement/gi, 'Best regards')
        .replace(/Bien à vous/gi, 'Kind regards')
        .replace(/Madame, Monsieur/gi, 'Dear Sir or Madam')
        .replace(/Salut/gi, 'Hi')
        .replace(/À bientôt/gi, 'Talk soon')
        .replace(/Bonne journée/gi, 'Have a great day')
        .replace(/je vous contacte/gi, 'I am reaching out to you')
        .replace(/je me permets/gi, 'I am taking the liberty')
        .replace(/suite à/gi, 'Following')
        .replace(/n'hésitez pas/gi, 'please don\'t hesitate')
        .replace(/à votre disposition/gi, 'at your disposal')
        .replace(/dans les meilleurs délais/gi, 'as soon as possible')
        .replace(/prochaines étapes/gi, 'next steps')
        .replace(/je reste disponible/gi, 'I remain available')
        .replace(/votre retour/gi, 'your feedback')
        .replace(/réunion/gi, 'meeting')
        .replace(/disponibilités/gi, 'availability');

      return '[Traduction EN]\n\n' + result + '\n\n— Traduit par ARIA';
    },

    repondre: function (emailBody) {
      if (!emailBody || emailBody.trim().length < 5) {
        return 'Ouvrez un email reçu, puis utilisez "Générer réponse" pour que l\'IA rédige une réponse adaptée.';
      }
      const ton = getTon();
      const intro = randomFrom(ton.intro);
      const closing = randomFrom(ton.closing);

      const reponses = {
        professionnel: `${intro},\n\nJe vous remercie pour votre message.\n\nJ'ai bien pris note des informations communiquées et je reviens vers vous rapidement avec une réponse complète.\n\nN'hésitez pas à me contacter si vous avez besoin d'informations complémentaires dans l'intervalle.\n\n${closing},\nAlex Klass`,
        amical: `${intro} !\n\nMerci pour ton message !\n\nJe regarde ça dès que possible et je te tiens au courant. Bonne idée en tout cas !\n\n${closing},\nAlex`,
        formel: `${intro},\n\nNous accusons bonne réception de votre message et vous remercions de l'intérêt que vous portez à notre collaboration.\n\nNous nous engageons à vous apporter une réponse détaillée dans les meilleurs délais.\n\n${closing},\nAlex Klass`,
        concis: `${intro},\n\nReçu, merci !\n\nJe reviens vers toi/vous rapidement.\n\n${closing},\nAlex`,
        persuasif: `${intro},\n\nMerci pour ce message — c'est exactement ce dont nous avons besoin pour avancer !\n\nJe suis enthousiaste à l'idée de collaborer sur ce projet. Je vous propose de nous appeler cette semaine pour concrétiser tout ça rapidement.\n\n${closing},\nAlex Klass`
      };

      return reponses[ia.tone] || reponses.professionnel;
    },

    custom: function (prompt, current, subject, to) {
      const p = prompt.toLowerCase();
      const ton = getTon();

      if (p.includes('remerci') || p.includes('merci')) {
        return `${randomFrom(ton.intro)},\n\nJe tenais à vous adresser mes plus sincères remerciements pour ${subject || 'votre collaboration et votre confiance accordée'}.\n\nVotre contribution a été précieuse et a permis d'avancer efficacement sur nos objectifs communs.\n\nAu plaisir de continuer à travailler ensemble.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
      }

      if (p.includes('excuse') || p.includes('pardon') || p.includes('désolé')) {
        return `${randomFrom(ton.intro)},\n\nJe souhaite vous présenter mes sincères excuses concernant ${subject || 'la situation récente'}.\n\nCette situation n'est pas à la hauteur de nos standards habituels et j'en prends l'entière responsabilité.\n\nNous mettons tout en œuvre pour rectifier cela dans les plus brefs délais et éviter que cela ne se reproduise.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
      }

      if (p.includes('invitation') || p.includes('invite') || p.includes('réunion')) {
        return `${randomFrom(ton.intro)},\n\nJ'ai le plaisir de vous convier à ${subject || 'notre prochaine réunion d\'équipe'}.\n\nCette rencontre sera l'occasion de faire le point sur nos avancées et de définir nos prochaines étapes stratégiques.\n\n📅 Date : À confirmer\n⏰ Heure : À confirmer\n📍 Lieu/Lien : À préciser\n\nMerci de me confirmer votre présence.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
      }

      if (p.includes('suivi') || p.includes('follow') || p.includes('relance')) {
        return `${randomFrom(ton.intro)},\n\nJe me permets de revenir vers vous suite à mon précédent message concernant "${subject || 'notre projet en cours'}".\n\nN'ayant pas encore eu l'occasion d'avoir votre retour, je souhaitais m'assurer que tout vous est bien parvenu et rester disponible pour répondre à vos éventuelles questions.\n\nJe reste à votre entière disposition.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
      }

      if (p.includes('rapport') || p.includes('bilan') || p.includes('résumé')) {
        return `${randomFrom(ton.intro)},\n\nVeuillez trouver ci-dessous le point de situation concernant "${subject || 'nos activités en cours'}" :\n\n✅ Réalisations :\n— Point 1 accompli\n— Point 2 finalisé\n\n🔄 En cours :\n— Avancement de la tâche principale\n— Finalisation des ajustements\n\n📋 Prochaines étapes :\n— Action à planifier\n— Validation requise\n\nRestant disponible pour toute question.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
      }

      // Génération générique avec le prompt
      return `${randomFrom(ton.intro)},\n\nSuite à votre demande : "${prompt}"\n\nJe souhaitais vous apporter les éléments suivants concernant "${subject || 'le sujet en question'}" :\n\nNous avons examiné attentivement la situation et identifié les meilleures options disponibles. Notre recommandation est de procéder de manière structurée en priorisant les aspects les plus impactants.\n\nJe reste disponible pour approfondir ce sujet avec vous.\n\n${randomFrom(ton.closing)},\nAlex Klass`;
    }
  };

  /* ─────────────────────────────────────────────
     LOGIQUE IA
  ───────────────────────────────────────────── */

  function getComposeContent() {
    const editor = document.getElementById('compose-editor');
    const subject = document.getElementById('compose-subject');
    const to = document.getElementById('compose-to');
    return {
      body: editor ? editor.value : '',
      subject: subject ? subject.value : '',
      to: to ? to.value : ''
    };
  }

  function showThinking() {
    const t = document.getElementById('ia-thinking');
    const r = document.getElementById('ia-result-box');
    const e = document.getElementById('ia-result-empty');
    if (t) t.classList.add('visible');
    if (r) r.classList.remove('visible');
    if (e) e.style.display = 'none';
  }

  function showResult(text) {
    const t = document.getElementById('ia-thinking');
    const r = document.getElementById('ia-result-box');
    const rt = document.getElementById('ia-result-text');
    const e = document.getElementById('ia-result-empty');
    if (t) t.classList.remove('visible');
    if (rt) rt.textContent = text;
    if (r) r.classList.add('visible');
    if (e) e.style.display = 'none';
    // Store in history
    ia.history.unshift(text);
    if (ia.history.length > 5) ia.history.pop();
    renderHistory();
  }

  function insertResult() {
    const rt = document.getElementById('ia-result-text');
    const editor = document.getElementById('compose-editor');
    if (!rt || !editor) return;
    editor.value = rt.textContent;
    editor.focus();
    showToastIA('Texte inséré dans le message');
  }

  function copyResult() {
    const rt = document.getElementById('ia-result-text');
    if (!rt) return;
    navigator.clipboard.writeText(rt.textContent).then(() => {
      showToastIA('Copié dans le presse-papiers');
    }).catch(() => {
      showToastIA('Copie impossible (clipboard non disponible)');
    });
  }

  function simulateThinking(fn, delay) {
    ia.thinking = true;
    showThinking();
    setTimeout(() => {
      const result = fn();
      ia.thinking = false;
      showResult(result);
    }, delay || (700 + Math.random() * 600));
  }

  function executeAction(action) {
    const ctx = getComposeContent();
    simulateThinking(() => {
      switch (action) {
        case 'rediger':   return TEMPLATES.rediger(ctx.subject, ctx.to);
        case 'ameliorer': return TEMPLATES.ameliorer(ctx.body);
        case 'raccourcir':return TEMPLATES.raccourcir(ctx.body);
        case 'objet':     return TEMPLATES.objet(ctx.body, ctx.subject);
        case 'traduire':  return TEMPLATES.traduire(ctx.body);
        case 'repondre':  return TEMPLATES.repondre(ctx.body || getLastEmailBody());
        default:          return TEMPLATES.rediger(ctx.subject, ctx.to);
      }
    });
  }

  function executeCustomPrompt() {
    const input = document.getElementById('ia-prompt-input');
    if (!input || !input.value.trim()) return;
    const prompt = input.value.trim();
    const ctx = getComposeContent();
    simulateThinking(() => TEMPLATES.custom(prompt, ctx.body, ctx.subject, ctx.to));
    input.value = '';
  }

  function getLastEmailBody() {
    const body = document.getElementById('mail-read-body');
    return body ? body.textContent : '';
  }

  function renderHistory() {
    const hist = document.getElementById('ia-history-list');
    if (!hist) return;
    if (ia.history.length === 0) {
      hist.innerHTML = '<div class="ia-history-item" style="cursor:default;opacity:.4">Aucun historique</div>';
      return;
    }
    hist.innerHTML = ia.history.slice(0, 3).map((h, i) => `
      <div class="ia-history-item" data-idx="${i}">
        <span class="ia-history-icon">📝</span>
        <span>${h.substring(0, 45).replace(/\n/g, ' ')}…</span>
      </div>
    `).join('');
    hist.querySelectorAll('.ia-history-item[data-idx]').forEach(item => {
      item.addEventListener('click', () => {
        const idx = parseInt(item.dataset.idx);
        showResult(ia.history[idx]);
      });
    });
  }

  /* ─────────────────────────────────────────────
     PANNEAU IA — OPEN / CLOSE
  ───────────────────────────────────────────── */

  function openIAPanel() {
    const modal = document.querySelector('.compose-modal');
    const btn = document.getElementById('compose-ia-btn');
    if (!modal) return;
    ia.open = true;
    modal.classList.add('ia-open');
    if (btn) btn.classList.add('active');
    // Reset état
    const empty = document.getElementById('ia-result-empty');
    const box = document.getElementById('ia-result-box');
    const think = document.getElementById('ia-thinking');
    if (empty) empty.style.display = '';
    if (box) box.classList.remove('visible');
    if (think) think.classList.remove('visible');
  }

  function closeIAPanel() {
    const modal = document.querySelector('.compose-modal');
    const btn = document.getElementById('compose-ia-btn');
    if (!modal) return;
    ia.open = false;
    modal.classList.remove('ia-open');
    if (btn) btn.classList.remove('active');
  }

  function toggleIAPanel() {
    if (ia.open) closeIAPanel();
    else openIAPanel();
  }

  /* ─────────────────────────────────────────────
     TOAST
  ───────────────────────────────────────────── */

  function showToastIA(msg) {
    let toast = document.getElementById('ia-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'ia-toast';
      toast.style.cssText = 'position:fixed;bottom:80px;right:32px;z-index:9999;background:linear-gradient(135deg,#a78bfa,#22d3ee);color:#0f172a;padding:10px 20px;border-radius:10px;font-weight:700;font-size:.85rem;box-shadow:0 4px 24px rgba(167,139,250,.4);transition:opacity .3s;opacity:0;pointer-events:none;';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    clearTimeout(toast._t);
    toast._t = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
  }

  /* ─────────────────────────────────────────────
     INIT
  ───────────────────────────────────────────── */

  function initMailIA() {
    // Bouton IA dans toolbar compose
    const iaBtn = document.getElementById('compose-ia-btn');
    if (iaBtn) iaBtn.addEventListener('click', toggleIAPanel);

    // Fermer panneau IA
    const closeBtn = document.getElementById('ia-panel-close');
    if (closeBtn) closeBtn.addEventListener('click', closeIAPanel);

    // Chips de ton
    document.querySelectorAll('.ia-tone-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        ia.tone = chip.dataset.tone;
        document.querySelectorAll('.ia-tone-chip').forEach(c => c.classList.toggle('active', c.dataset.tone === ia.tone));
      });
    });

    // Cartes d'actions
    document.querySelectorAll('.ia-action-card[data-action]').forEach(card => {
      card.addEventListener('click', () => executeAction(card.dataset.action));
    });

    // Prompt libre
    const promptSend = document.getElementById('ia-prompt-send');
    if (promptSend) promptSend.addEventListener('click', executeCustomPrompt);

    const promptInput = document.getElementById('ia-prompt-input');
    if (promptInput) {
      promptInput.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); executeCustomPrompt(); }
      });
    }

    // Boutons résultat
    const insertBtn = document.getElementById('ia-result-insert');
    if (insertBtn) insertBtn.addEventListener('click', insertResult);

    const copyBtn = document.getElementById('ia-result-copy');
    if (copyBtn) copyBtn.addEventListener('click', copyResult);

    const regenBtn = document.getElementById('ia-result-regen');
    if (regenBtn) {
      regenBtn.addEventListener('click', () => {
        // Régénérer avec le même ton (varier légèrement)
        const ctx = getComposeContent();
        simulateThinking(() => TEMPLATES.ameliorer(ctx.body || TEMPLATES.rediger(ctx.subject, ctx.to)));
      });
    }

    // Fermer compose = fermer aussi le panneau IA
    const composeClose = document.getElementById('compose-close');
    if (composeClose) {
      const original = composeClose.onclick;
      composeClose.addEventListener('click', () => {
        closeIAPanel();
      });
    }

    // Raccourci clavier : Alt+I pour ouvrir/fermer l'IA dans compose
    document.addEventListener('keydown', e => {
      const overlay = document.getElementById('compose-overlay');
      if (e.altKey && e.key === 'i' && overlay && overlay.classList.contains('open')) {
        e.preventDefault();
        toggleIAPanel();
      }
    });

    renderHistory();
    console.log('[ARIA Mail] IA rédaction initialisée');
  }

  /* ─────────────────────────────────────────────
     LAZY INIT
  ───────────────────────────────────────────── */
  function setup() {
    const view = document.getElementById('view-courriel');
    if (!view) { setTimeout(setup, 200); return; }

    let ready = false;
    const tryInit = () => {
      if (ready) return;
      if (!view.classList.contains('view-hidden')) {
        ready = true;
        initMailIA();
      }
    };
    new MutationObserver(tryInit).observe(view, { attributes: true, attributeFilter: ['class'] });
    const navBtn = document.querySelector('[data-view="courriel"]');
    if (navBtn) navBtn.addEventListener('click', () => setTimeout(tryInit, 80));
    tryInit();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
  else setup();

})();
