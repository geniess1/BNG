/**
 * FlowState — Module Courriel & Visioconférence
 * Gestion emails, contacts, notes, Zoom/Teams deep links
 */

(function () {
  'use strict';

  /* ─────────────────────────────────────────────
     DONNÉES INITIALES
  ───────────────────────────────────────────── */

  const EMAILS = [
    {
      id: 1,
      folder: 'inbox',
      starred: true,
      unread: true,
      from: 'Marie Leclerc',
      email: 'marie.leclerc@flowstate.io',
      avatar: 'ML',
      color: '#22d3ee',
      subject: 'Revue du sprint Q2 — points d\'action',
      preview: 'Bonjour, suite à notre réunion d\'hier voici les points à traiter avant vendredi...',
      body: 'Bonjour,\n\nSuite à notre réunion d\'hier, voici les points d\'action à traiter avant vendredi :\n\n1. Finaliser la maquette du tableau de bord\n2. Valider les estimations de charge pour le module agent\n3. Planifier la démo client pour la semaine prochaine\n\nMerci de confirmer votre disponibilité pour la réunion de jeudi à 14h.\n\nCordialement,\nMarie',
      date: 'Auj. 17h42',
      tags: ['Sprint', 'Urgent']
    },
    {
      id: 2,
      folder: 'inbox',
      starred: false,
      unread: true,
      from: 'Jean Parent',
      email: 'jean.parent@flowstate.io',
      avatar: 'JP',
      color: '#a78bfa',
      subject: 'Pipeline IA — mise à jour des modèles',
      preview: 'Voici le rapport d\'avancement sur l\'intégration des nouveaux modèles de langage...',
      body: 'Bonjour,\n\nVoici le rapport d\'avancement sur l\'intégration des nouveaux modèles de langage :\n\n• GPT-4o : intégré et testé ✓\n• Claude 3.5 : en cours d\'intégration\n• Gemini 2.0 : prévu pour la semaine prochaine\n\nLes performances sont très prometteuses. Je vous envoie les benchmarks complets d\'ici demain.\n\nBonne journée,\nJean',
      date: 'Auj. 14h15',
      tags: ['IA', 'Dev']
    },
    {
      id: 3,
      folder: 'inbox',
      starred: true,
      unread: true,
      from: 'Claire Dupont',
      email: 'claire@clientabc.com',
      avatar: 'CD',
      color: '#fb7185',
      subject: 'Proposition commerciale — ABC Corp',
      preview: 'Merci pour votre présentation hier. Nous sommes très intéressés par la solution...',
      body: 'Bonjour,\n\nMerci pour votre excellente présentation hier. Nous sommes très intéressés par la solution FlowState pour notre équipe.\n\nPourriez-vous nous transmettre :\n1. Une proposition commerciale détaillée\n2. Les conditions pour 25 utilisateurs\n3. Les SLA garantis\n\nNous aimerions procéder rapidement. Est-il possible d\'organiser un appel cette semaine ?\n\nCordialement,\nClaire Dupont\nDirectrice Générale — ABC Corp',
      date: 'Hier 09h30',
      tags: ['Client', 'Urgent']
    },
    {
      id: 4,
      folder: 'inbox',
      starred: false,
      unread: false,
      from: 'Sara Khalil',
      email: 'sara.khalil@flowstate.io',
      avatar: 'SK',
      color: '#34d399',
      subject: 'Design system — nouvelles composantes',
      preview: 'J\'ai finalisé les nouvelles composantes UI pour le module calendrier...',
      body: 'Bonjour,\n\nJ\'ai finalisé les nouvelles composantes UI pour le module calendrier. Vous trouverez les fichiers Figma mis à jour dans le dossier partagé.\n\nPrincipaux changements :\n• Nouveau picker de couleur pour les calendriers\n• Amélioration de l\'accessibilité (contraste WCAG AA)\n• Animations de transition plus fluides\n• Mode sombre affiné\n\nN\'hésitez pas à me faire part de vos retours.\n\nSara',
      date: 'Hier 11h20',
      tags: ['Design']
    },
    {
      id: 5,
      folder: 'inbox',
      starred: false,
      unread: false,
      from: 'Tom Rioux',
      email: 'tom.rioux@flowstate.io',
      avatar: 'TR',
      color: '#fbbf24',
      subject: 'Rapport performance — serveurs avril',
      preview: 'Le rapport mensuel de performance des serveurs est disponible...',
      body: 'Bonjour,\n\nLe rapport mensuel de performance des serveurs est disponible. Voici les points saillants :\n\n• Disponibilité : 99.97% (objectif 99.9% ✓)\n• Temps de réponse moyen : 142ms\n• Incidents critiques : 0\n• Incidents mineurs : 2 (résolus sous 15 min)\n\nLe rapport complet est accessible dans le tableau de bord infrastructure.\n\nTom',
      date: 'Lun. 16h05',
      tags: ['Infra']
    },
    {
      id: 6,
      folder: 'sent',
      starred: false,
      unread: false,
      from: 'Vous',
      email: 'klass.a1@hotmail.com',
      avatar: 'AK',
      color: '#818cf8',
      subject: 'Re: Proposition commerciale — ABC Corp',
      preview: 'Chère Claire, merci pour votre intérêt. Je vous transmets notre proposition...',
      body: 'Chère Claire,\n\nMerci pour votre intérêt pour FlowState. Je vous transmets notre proposition adaptée à vos besoins.\n\nPour 25 utilisateurs, nous recommandons le plan Équipe Pro qui inclut :\n• Accès complet à tous les modules\n• Support prioritaire 24/7\n• Onboarding personnalisé\n• SLA 99.9%\n\nJe reste disponible pour un appel jeudi à 10h ou vendredi après-midi.\n\nCordialement,\nAlex Klass\nCo-fondateur, FlowState',
      date: 'Hier 10h45',
      tags: ['Client']
    },
    {
      id: 7,
      folder: 'sent',
      starred: false,
      unread: false,
      from: 'Vous',
      email: 'klass.a1@hotmail.com',
      avatar: 'AK',
      color: '#818cf8',
      subject: 'Ordre du jour — Réunion équipe vendredi',
      preview: 'Bonjour à tous, voici l\'ordre du jour pour notre réunion de vendredi...',
      body: 'Bonjour à tous,\n\nVoici l\'ordre du jour pour notre réunion de vendredi 10h-11h30 :\n\n1. Revue du sprint en cours (20 min)\n2. Démonstration module Courriel (30 min)\n3. Planification sprint suivant (25 min)\n4. Questions diverses (15 min)\n\nMerci de préparer vos points d\'avancement.\n\nÀ vendredi,\nAlex',
      date: 'Lun. 09h00',
      tags: []
    },
    {
      id: 8,
      folder: 'starred',
      starred: true,
      unread: false,
      from: 'Marie Leclerc',
      email: 'marie.leclerc@flowstate.io',
      avatar: 'ML',
      color: '#22d3ee',
      subject: 'Roadmap Q3 2026 — à valider',
      preview: 'Voici la proposition de roadmap pour le troisième trimestre. J\'attends votre validation...',
      body: 'Bonjour,\n\nVoici la proposition de roadmap pour le Q3 2026 :\n\nJuillet :\n• Module analytics avancé\n• Intégration API tierces\n\nAoût :\n• Application mobile (iOS/Android)\n• Mode hors-ligne\n\nSeptembre :\n• Marketplace d\'extensions\n• Programme partenaires\n\nMerci de valider ou d\'ajuster selon les priorités business.\n\nMarie',
      date: 'Sem. dern.',
      tags: ['Stratégie', 'Roadmap']
    }
  ];

  const CONTACTS = [
    {
      id: 1,
      initials: 'AK',
      color: '#818cf8',
      name: 'Alex Klass',
      email: 'klass.a1@hotmail.com',
      company: 'FlowState',
      role: 'Co-fondateur & CEO',
      phone: '+1 514 000 0001',
      status: 'online',
      tags: ['Équipe', 'Admin']
    },
    {
      id: 2,
      initials: 'ML',
      color: '#22d3ee',
      name: 'Marie Leclerc',
      email: 'marie.leclerc@flowstate.io',
      company: 'FlowState',
      role: 'Chef de projet',
      phone: '+1 514 000 0002',
      status: 'online',
      tags: ['Équipe', 'Projet']
    },
    {
      id: 3,
      initials: 'JP',
      color: '#a78bfa',
      name: 'Jean Parent',
      email: 'jean.parent@flowstate.io',
      company: 'FlowState',
      role: 'Développeur IA',
      phone: '+1 514 000 0003',
      status: 'busy',
      tags: ['Équipe', 'Dev']
    },
    {
      id: 4,
      initials: 'SK',
      color: '#34d399',
      name: 'Sara Khalil',
      email: 'sara.khalil@flowstate.io',
      company: 'FlowState',
      role: 'Designer UX',
      phone: '+1 514 000 0004',
      status: 'online',
      tags: ['Équipe', 'Design']
    },
    {
      id: 5,
      initials: 'TR',
      color: '#fbbf24',
      name: 'Tom Rioux',
      email: 'tom.rioux@flowstate.io',
      company: 'FlowState',
      role: 'DevOps',
      phone: '+1 514 000 0005',
      status: 'away',
      tags: ['Équipe', 'Infra']
    },
    {
      id: 6,
      initials: 'CD',
      color: '#fb7185',
      name: 'Claire Dupont',
      email: 'claire@clientabc.com',
      company: 'ABC Corp',
      role: 'Directrice Générale',
      phone: '+1 438 000 0006',
      status: 'offline',
      tags: ['Client', 'VIP']
    }
  ];

  const NOTES = [
    {
      id: 1,
      title: 'R\u00e9union Q2 — Points cl\u00e9s',
      content: 'Objectifs Q2 :\n- Lancement module courriel\n- Int\u00e9gration Zoom & Teams\n- Refonte onboarding\n- Test beta avec 10 clients\n\nD\u00e9cisions prises :\n- Prioriser mobile en Q3\n- Budget marketing +20%\n- Recruter 2 d\u00e9veloppeurs',
      date: '3 avr. 2026',
      tag: 'R\u00e9union'
    },
    {
      id: 2,
      title: 'Id\u00e9es fonctionnalit\u00e9s',
      content: 'Features \u00e0 explorer :\n\n1. Mode hors-ligne avec sync automatique\n2. IA de tri d\'emails intelligente\n3. R\u00e9sum\u00e9 automatique des r\u00e9unions\n4. Int\u00e9gration Google Drive / OneDrive\n5. Signature email personnalis\u00e9e\n6. Templates d\u00e9mail pr\u00e9-r\u00e9dig\u00e9s\n7. Rappels de suivi automatiques',
      date: '2 avr. 2026',
      tag: 'Id\u00e9es'
    },
    {
      id: 3,
      title: 'Suivi client ABC Corp',
      content: 'Historique des contacts :\n\n01/04 - Premier appel de d\u00e9couverte (30 min)\n02/04 - D\u00e9mo produit (1h) - tr\u00e8s int\u00e9ress\u00e9s\n03/04 - Envoi proposition commerciale\n\nProchain \u00e9tape :\n- Appel n\u00e9gociation jeudi 10h\n- Valider p\u00e9rim\u00e8tre et tarification\n- Signature pr\u00e9vue semaine prochaine\n\nContact : Claire Dupont (DG)',
      date: '3 avr. 2026',
      tag: 'Client'
    },
    {
      id: 4,
      title: 'Plan de sprint — Sem. 14',
      content: 'Sprint 14 (31 mars - 11 avr.) :\n\nEn cours :\n[x] Module courriel CSS\n[ ] Module courriel JS\n[ ] Tests Playwright\n\n\u00c0 faire :\n[ ] D\u00e9ploiement module courriel\n[ ] Fix: tri des emails\n[ ] Revue accessibilit\u00e9\n\nCapacit\u00e9 : 40 points\nBrule : 18/40',
      date: '31 mars 2026',
      tag: 'Sprint'
    },
    {
      id: 5,
      title: 'Notes conf\u00e9rence Tech MTL',
      content: 'Conf\u00e9rence TechMTL 2026 :\n\nInterventions int\u00e9ressantes :\n- "L\'IA g\u00e9n\u00e9rative en entreprise" — Dr. Lavoie\n- "S\u00e9curit\u00e9 des donn\u00e9es cloud" — Eq. Cloudflare\n- "UX pour la productivit\u00e9" — M. Tremblay\n\nContacts \u00e9tablis :\n- Yann Côt\u00e9 (Ubisoft, partenariat potentiel)\n- Dr. Lavoie (conseil consultatif ?)\n\nAction : envoyer emails de suivi avant vendredi',
      date: '28 mars 2026',
      tag: 'Networking'
    }
  ];

  const ZOOM_MEETINGS = [
    {
      id: 1,
      time: '09:00',
      title: 'Standup quotidien',
      participants: 5,
      badge: 'now',
      badgeLabel: 'En cours',
      meetingId: '123-456-7890',
      link: 'https://zoom.us/j/1234567890'
    },
    {
      id: 2,
      time: '14:00',
      title: 'D\u00e9mo Pipeline IA',
      participants: 8,
      badge: 'soon',
      badgeLabel: 'Bient\u00f4t',
      meetingId: '234-567-8901',
      link: 'https://zoom.us/j/2345678901'
    },
    {
      id: 3,
      time: '15:30',
      title: 'Revue de sprint',
      participants: 6,
      badge: 'soon',
      badgeLabel: 'Bient\u00f4t',
      meetingId: '345-678-9012',
      link: 'https://zoom.us/j/3456789012'
    },
    {
      id: 4,
      time: '10:00',
      title: 'Formation React avanc\u00e9',
      participants: 3,
      badge: 'later',
      badgeLabel: 'Demain',
      meetingId: '456-789-0123',
      link: 'https://zoom.us/j/4567890123'
    }
  ];

  const TEAMS_MEETINGS = [
    {
      id: 1,
      time: '11:00',
      title: 'Team building virtuel',
      participants: 12,
      badge: 'soon',
      badgeLabel: 'Bient\u00f4t',
      link: 'https://teams.microsoft.com/l/meetup-join/virtual'
    },
    {
      id: 2,
      time: '14:00',
      title: 'Revue trimestrielle',
      participants: 15,
      badge: 'later',
      badgeLabel: 'Cet apr\u00e8s-midi',
      link: 'https://teams.microsoft.com/l/meetup-join/quarterly'
    },
    {
      id: 3,
      time: '16:00',
      title: 'Entretien candidat',
      participants: 3,
      badge: 'later',
      badgeLabel: 'Ce soir',
      link: 'https://teams.microsoft.com/l/meetup-join/interview'
    }
  ];

  /* ─────────────────────────────────────────────
     STATE
  ───────────────────────────────────────────── */

  const state = {
    activeTab: 'mail',
    activeFolder: 'inbox',
    selectedEmail: null,
    selectedContact: null,
    activeNote: null,
    notes: JSON.parse(JSON.stringify(NOTES)),
    emails: JSON.parse(JSON.stringify(EMAILS)),
    mailSearch: '',
    contactSearch: '',
    composeDraft: { to: '', subject: '', body: '' }
  };

  /* ─────────────────────────────────────────────
     DOM HELPERS
  ───────────────────────────────────────────── */

  function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }
  function setText(sel, val, ctx) { const el = qs(sel, ctx); if (el) el.textContent = val; }

  /* ─────────────────────────────────────────────
     CHIPS HERO — STATS
  ───────────────────────────────────────────── */

  function updateChips() {
    const inbox = state.emails.filter(e => e.folder === 'inbox').length;
    const unread = state.emails.filter(e => e.unread).length;
    const starred = state.emails.filter(e => e.starred).length;
    const contacts = CONTACTS.length;
    const notes = state.notes.length;
    setText('#chip-val-inbox', inbox);
    setText('#chip-val-unread', unread);
    setText('#chip-val-starred', starred);
    setText('#chip-val-contacts', contacts);
    setText('#chip-val-notes', notes);
  }

  /* ─────────────────────────────────────────────
     ONGLETS
  ───────────────────────────────────────────── */

  function switchTab(tab) {
    state.activeTab = tab;
    qsa('.courriel-tab').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
    qsa('.courriel-panel').forEach(panel => panel.classList.toggle('active', panel.id === 'panel-' + tab));
  }

  /* ─────────────────────────────────────────────
     MODULE COURRIEL — MAIL
  ───────────────────────────────────────────── */

  function getFolderEmails() {
    let emails = state.emails;
    if (state.activeFolder === 'starred') {
      emails = emails.filter(e => e.starred);
    } else {
      emails = emails.filter(e => e.folder === state.activeFolder);
    }
    if (state.mailSearch) {
      const q = state.mailSearch.toLowerCase();
      emails = emails.filter(e =>
        e.from.toLowerCase().includes(q) ||
        e.subject.toLowerCase().includes(q) ||
        e.preview.toLowerCase().includes(q)
      );
    }
    return emails;
  }

  function renderMailList() {
    const list = qs('#mail-list');
    if (!list) return;
    const emails = getFolderEmails();
    if (emails.length === 0) {
      list.innerHTML = '<div style="padding:32px;text-align:center;color:var(--c-muted,#6b7280);font-size:0.85rem;">Aucun message</div>';
      return;
    }
    list.innerHTML = emails.map(e => `
      <div class="mail-item${e.unread ? ' unread' : ''}${state.selectedEmail === e.id ? ' selected' : ''}"
           data-id="${e.id}">
        ${e.unread ? '<div class="mail-unread-dot"></div>' : '<div style="width:8px;flex-shrink:0"></div>'}
        <div class="mail-item-avatar" style="background:${e.color}22;color:${e.color}">${e.initials || e.avatar}</div>
        <div class="mail-item-content">
          <div class="mail-item-header">
            <span class="mail-item-sender">${e.from}</span>
            <span class="mail-item-time">${e.date}</span>
          </div>
          <div class="mail-item-subject">${e.subject}</div>
          <div class="mail-item-preview">${e.preview}</div>
          ${e.tags && e.tags.length ? '<div class="mail-tags">' + e.tags.map(t => '<span class="mail-tag">' + t + '</span>').join('') + '</div>' : ''}
        </div>
      </div>
    `).join('');
    list.querySelectorAll('.mail-item').forEach(item => {
      item.addEventListener('click', () => openEmail(parseInt(item.dataset.id)));
    });
  }

  function updateFolderCounts() {
    const inboxCount = state.emails.filter(e => e.folder === 'inbox' && e.unread).length;
    const sentCount = state.emails.filter(e => e.folder === 'sent').length;
    const starredCount = state.emails.filter(e => e.starred).length;
    const el = qs('#mail-folder-inbox .mail-folder-count');
    if (el) el.textContent = inboxCount > 0 ? inboxCount : '';
    const elSent = qs('#mail-folder-sent .mail-folder-count');
    if (elSent) elSent.textContent = '';
    const elStar = qs('#mail-folder-starred .mail-folder-count');
    if (elStar) elStar.textContent = starredCount > 0 ? starredCount : '';
  }

  function openEmail(id) {
    const email = state.emails.find(e => e.id === id);
    if (!email) return;
    // Mark as read
    email.unread = false;
    state.selectedEmail = id;
    renderMailList();
    updateFolderCounts();
    updateChips();
    // Show read panel
    const panel = qs('#mail-read-panel');
    const empty = qs('.mail-read-empty');
    if (panel) panel.style.display = '';
    if (empty) empty.style.display = 'none';
    setText('#mail-read-subject', email.subject);
    setText('#mail-read-from', email.from + ' <' + email.email + '>');
    setText('#mail-read-date', email.date);
    const bodyEl = qs('#mail-read-body');
    if (bodyEl) bodyEl.textContent = email.body;
    // Avatar
    const avatarEl = qs('#mail-read-avatar');
    if (avatarEl) {
      avatarEl.textContent = email.avatar;
      avatarEl.style.background = (email.color || '#818cf8') + '22';
      avatarEl.style.color = email.color || '#818cf8';
    }
    // Star button
    const starBtn = qs('#mail-action-star');
    if (starBtn) {
      starBtn.textContent = email.starred ? '★' : '☆';
      starBtn.title = email.starred ? 'Retirer des favoris' : 'Ajouter aux favoris';
    }
  }

  function deleteEmail(id) {
    const idx = state.emails.findIndex(e => e.id === id);
    if (idx === -1) return;
    state.emails.splice(idx, 1);
    state.selectedEmail = null;
    const panel = qs('#mail-read-panel');
    const empty = qs('.mail-read-empty');
    if (panel) panel.style.display = 'none';
    if (empty) empty.style.display = '';
    renderMailList();
    updateFolderCounts();
    updateChips();
  }

  function toggleStar(id) {
    const email = state.emails.find(e => e.id === id);
    if (!email) return;
    email.starred = !email.starred;
    if (email.starred && !state.emails.find(e => e.id === id && e.folder === 'starred')) {
      // just toggle the flag
    }
    renderMailList();
    updateFolderCounts();
    updateChips();
    const starBtn = qs('#mail-action-star');
    if (starBtn) {
      starBtn.textContent = email.starred ? '★' : '☆';
    }
  }

  function initMailModule() {
    // Folders
    qsa('.mail-folder').forEach(folder => {
      folder.addEventListener('click', () => {
        state.activeFolder = folder.dataset.folder;
        state.selectedEmail = null;
        qsa('.mail-folder').forEach(f => f.classList.remove('active'));
        folder.classList.add('active');
        const panel = qs('#mail-read-panel');
        const empty = qs('.mail-read-empty');
        if (panel) panel.style.display = 'none';
        if (empty) empty.style.display = '';
        renderMailList();
      });
    });
    // Search
    const searchInput = qs('#mail-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', e => {
        state.mailSearch = e.target.value;
        renderMailList();
      });
    }
    // Actions
    const replyBtn = qs('#mail-action-reply');
    if (replyBtn) {
      replyBtn.addEventListener('click', () => {
        const email = state.emails.find(e => e.id === state.selectedEmail);
        if (!email) return;
        openCompose({ to: email.email, subject: 'Re: ' + email.subject });
      });
    }
    const forwardBtn = qs('#mail-action-forward');
    if (forwardBtn) {
      forwardBtn.addEventListener('click', () => {
        const email = state.emails.find(e => e.id === state.selectedEmail);
        if (!email) return;
        openCompose({ subject: 'Fwd: ' + email.subject });
      });
    }
    const deleteBtn = qs('#mail-action-delete');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', () => {
        if (state.selectedEmail) deleteEmail(state.selectedEmail);
      });
    }
    const starBtn = qs('#mail-action-star');
    if (starBtn) {
      starBtn.addEventListener('click', () => {
        if (state.selectedEmail) toggleStar(state.selectedEmail);
      });
    }
    renderMailList();
    updateFolderCounts();
  }

  /* ─────────────────────────────────────────────
     COMPOSE
  ───────────────────────────────────────────── */

  function openCompose(prefill) {
    prefill = prefill || {};
    const overlay = qs('#compose-overlay');
    if (overlay) overlay.classList.add('open');
    const toEl = qs('#compose-to');
    const subEl = qs('#compose-subject');
    const bodyEl = qs('#compose-editor');
    if (toEl) toEl.value = prefill.to || '';
    if (subEl) subEl.value = prefill.subject || '';
    if (bodyEl) bodyEl.value = prefill.body || '';
    if (toEl) toEl.focus();
  }

  function closeCompose() {
    const overlay = qs('#compose-overlay');
    if (overlay) overlay.classList.remove('open');
  }

  function sendCompose() {
    const to = (qs('#compose-to') || {}).value || '';
    const subject = (qs('#compose-subject') || {}).value || '';
    const body = (qs('#compose-editor') || {}).value || '';
    if (!to.trim()) {
      alert('Veuillez entrer une adresse destinataire.');
      return;
    }
    if (!subject.trim()) {
      alert('Veuillez entrer un objet.');
      return;
    }
    // Add to sent
    const newEmail = {
      id: Date.now(),
      folder: 'sent',
      starred: false,
      unread: false,
      from: 'Vous',
      email: 'klass.a1@hotmail.com',
      avatar: 'AK',
      color: '#818cf8',
      subject: subject,
      preview: body.substring(0, 80) + '...',
      body: body,
      date: 'Maintenant',
      tags: []
    };
    state.emails.push(newEmail);
    closeCompose();
    // Show sent folder
    state.activeFolder = 'sent';
    qsa('.mail-folder').forEach(f => f.classList.toggle('active', f.dataset.folder === 'sent'));
    renderMailList();
    updateFolderCounts();
    updateChips();
    // Flash notification
    showToast('Message envoy\u00e9 !');
  }

  function initComposeModule() {
    const btnCompose = qs('#btn-compose');
    if (btnCompose) btnCompose.addEventListener('click', () => openCompose());
    const btnClose = qs('#compose-close');
    if (btnClose) btnClose.addEventListener('click', closeCompose);
    const btnSend = qs('#compose-send');
    if (btnSend) btnSend.addEventListener('click', sendCompose);
    // Close on overlay click
    const overlay = qs('#compose-overlay');
    if (overlay) {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) closeCompose();
      });
    }
  }

  /* ─────────────────────────────────────────────
     MODULE CONTACTS
  ───────────────────────────────────────────── */

  function statusLabel(s) {
    const map = { online: 'En ligne', busy: 'Occup\u00e9', away: 'Absent', offline: 'Hors ligne' };
    return map[s] || s;
  }

  function renderContacts(filter) {
    const list = qs('#contacts-list');
    if (!list) return;
    let contacts = CONTACTS;
    if (filter) {
      const q = filter.toLowerCase();
      contacts = contacts.filter(c =>
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.company.toLowerCase().includes(q)
      );
    }
    list.innerHTML = contacts.map(c => `
      <div class="contact-row${state.selectedContact === c.id ? ' selected' : ''}" data-id="${c.id}">
        <div class="contact-avatar" style="background:${c.color}22;color:${c.color}">${c.initials}</div>
        <div class="contact-name">${c.name}</div>
        <div class="contact-email">${c.email}</div>
        <div class="contact-company">${c.company}</div>
        <div class="contact-status-dot status-${c.status}" title="${statusLabel(c.status)}"></div>
        <div class="contact-actions">
          <button class="contact-action-btn" data-action="mail" data-id="${c.id}" title="Envoyer un courriel">✉</button>
          <button class="contact-action-btn" data-action="zoom" data-id="${c.id}" title="Appel Zoom">🎥</button>
        </div>
      </div>
    `).join('');
    list.querySelectorAll('.contact-row').forEach(row => {
      row.addEventListener('click', e => {
        if (e.target.closest('.contact-action-btn')) return;
        openContactCard(parseInt(row.dataset.id));
      });
    });
    list.querySelectorAll('.contact-action-btn[data-action="mail"]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const c = CONTACTS.find(c => c.id === parseInt(btn.dataset.id));
        if (c) {
          switchTab('mail');
          openCompose({ to: c.email });
        }
      });
    });
    list.querySelectorAll('.contact-action-btn[data-action="zoom"]').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        window.open('https://zoom.us/start/videomeeting', '_blank');
      });
    });
  }

  function openContactCard(id) {
    const contact = CONTACTS.find(c => c.id === id);
    if (!contact) return;
    state.selectedContact = id;
    renderContacts(qs('#contacts-search-input') ? qs('#contacts-search-input').value : '');
    const card = qs('#contact-card-panel');
    if (!card) return;
    card.innerHTML = `
      <div class="contact-card">
        <div class="contact-card-avatar" style="background:${contact.color}22;color:${contact.color}">${contact.initials}</div>
        <div class="contact-card-name">${contact.name}</div>
        <div class="contact-card-role">${contact.role} · ${contact.company}</div>
        <div class="contact-card-meta">
          <div class="contact-meta-row">
            <span class="contact-meta-icon">✉</span>
            <span>${contact.email}</span>
          </div>
          <div class="contact-meta-row">
            <span class="contact-meta-icon">📞</span>
            <span>${contact.phone}</span>
          </div>
          <div class="contact-meta-row">
            <span class="contact-meta-icon contact-status-dot status-${contact.status}" style="display:inline-block;margin-right:4px"></span>
            <span>${statusLabel(contact.status)}</span>
          </div>
        </div>
        <div class="contact-card-actions">
          <button class="contact-card-btn rose" id="cc-btn-mail">Courriel</button>
          <button class="contact-card-btn cyan" id="cc-btn-zoom">Zoom</button>
          <button class="contact-card-btn violet" id="cc-btn-teams">Teams</button>
          <button class="contact-card-btn emerald" id="cc-btn-note">Note</button>
        </div>
        <div class="contact-tags">${(contact.tags || []).map(t => '<span class="mail-tag">' + t + '</span>').join('')}</div>
      </div>
    `;
    qs('#cc-btn-mail', card).addEventListener('click', () => {
      switchTab('mail');
      openCompose({ to: contact.email });
    });
    qs('#cc-btn-zoom', card).addEventListener('click', () => {
      window.open('https://zoom.us/start/videomeeting', '_blank');
    });
    qs('#cc-btn-teams', card).addEventListener('click', () => {
      window.open('https://teams.microsoft.com/l/chat/0/0?users=' + encodeURIComponent(contact.email), '_blank');
    });
    qs('#cc-btn-note', card).addEventListener('click', () => {
      switchTab('notes');
      createNewNote('Note — ' + contact.name, 'Suivi avec ' + contact.name + ' (' + contact.email + ')\n\n');
    });
  }

  function initContactsModule() {
    const searchInput = qs('#contacts-search-input');
    if (searchInput) {
      searchInput.addEventListener('input', e => {
        state.contactSearch = e.target.value;
        renderContacts(state.contactSearch);
      });
    }
    renderContacts();
  }

  /* ─────────────────────────────────────────────
     MODULE NOTES
  ───────────────────────────────────────────── */

  function renderNotesList() {
    const list = qs('#notes-list');
    if (!list) return;
    list.innerHTML = state.notes.map(n => `
      <div class="note-item${state.activeNote === n.id ? ' active' : ''}" data-id="${n.id}">
        <div class="note-item-title">${n.title}</div>
        <div class="note-item-preview">${n.content.substring(0, 60).replace(/\n/g, ' ')}…</div>
        <div class="note-item-footer">
          <span class="note-item-date">${n.date}</span>
          ${n.tag ? '<span class="note-item-tag">' + n.tag + '</span>' : ''}
        </div>
      </div>
    `).join('');
    list.querySelectorAll('.note-item').forEach(item => {
      item.addEventListener('click', () => openNote(parseInt(item.dataset.id)));
    });
  }

  function openNote(id) {
    const note = state.notes.find(n => n.id === id);
    if (!note) return;
    state.activeNote = id;
    renderNotesList();
    const titleEl = qs('#notes-title-input');
    const contentEl = qs('#notes-content-area');
    if (titleEl) titleEl.value = note.title;
    if (contentEl) contentEl.value = note.content;
  }

  function saveNote() {
    const titleEl = qs('#notes-title-input');
    const contentEl = qs('#notes-content-area');
    const title = titleEl ? titleEl.value.trim() : '';
    const content = contentEl ? contentEl.value : '';
    if (!title) {
      alert('Veuillez entrer un titre pour la note.');
      return;
    }
    if (state.activeNote) {
      const note = state.notes.find(n => n.id === state.activeNote);
      if (note) {
        note.title = title;
        note.content = content;
        note.date = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'short', year: 'numeric' });
      }
    } else {
      createNewNote(title, content);
      return;
    }
    renderNotesList();
    showToast('Note enregistr\u00e9e !');
  }

  function createNewNote(title, content) {
    const newNote = {
      id: Date.now(),
      title: title || 'Nouvelle note',
      content: content || '',
      date: new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'short', year: 'numeric' }),
      tag: ''
    };
    state.notes.unshift(newNote);
    state.activeNote = newNote.id;
    renderNotesList();
    const titleEl = qs('#notes-title-input');
    const contentEl = qs('#notes-content-area');
    if (titleEl) { titleEl.value = newNote.title; titleEl.focus(); titleEl.select(); }
    if (contentEl) contentEl.value = newNote.content;
    updateChips();
  }

  function initNotesModule() {
    const newBtn = qs('#notes-new-btn');
    if (newBtn) newBtn.addEventListener('click', () => createNewNote());
    const saveBtn = qs('#notes-save-btn');
    if (saveBtn) saveBtn.addEventListener('click', saveNote);
    renderNotesList();
    if (state.notes.length > 0) openNote(state.notes[0].id);
  }

  /* ─────────────────────────────────────────────
     MODULE ZOOM
  ───────────────────────────────────────────── */

  function renderZoomMeetings() {
    const list = qs('#zoom-meetings-list');
    if (!list) return;
    list.innerHTML = ZOOM_MEETINGS.map(m => `
      <div class="visio-meeting-item">
        <div class="visio-meeting-time">${m.time}</div>
        <div class="visio-meeting-info">
          <div class="visio-meeting-title">${m.title}</div>
          <div class="visio-meeting-sub">${m.participants} participants · ID: ${m.meetingId}</div>
        </div>
        <span class="visio-meeting-badge badge-${m.badge}">${m.badgeLabel}</span>
        <button class="visio-join-btn" onclick="window.open('${m.link}','_blank')">Rejoindre</button>
      </div>
    `).join('');
  }

  function initZoomModule() {
    const btnNew = qs('#zoom-btn-new');
    if (btnNew) btnNew.addEventListener('click', () => window.open('https://zoom.us/start/videomeeting', '_blank'));
    const btnSchedule = qs('#zoom-btn-schedule');
    if (btnSchedule) btnSchedule.addEventListener('click', () => window.open('https://zoom.us/meeting/schedule', '_blank'));
    renderZoomMeetings();
  }

  /* ─────────────────────────────────────────────
     MODULE TEAMS
  ───────────────────────────────────────────── */

  function renderTeamsMeetings() {
    const list = qs('#teams-meetings-list');
    if (!list) return;
    list.innerHTML = TEAMS_MEETINGS.map(m => `
      <div class="visio-meeting-item">
        <div class="visio-meeting-time">${m.time}</div>
        <div class="visio-meeting-info">
          <div class="visio-meeting-title">${m.title}</div>
          <div class="visio-meeting-sub">${m.participants} participants</div>
        </div>
        <span class="visio-meeting-badge badge-${m.badge}">${m.badgeLabel}</span>
        <button class="visio-join-btn teams-join-btn" onclick="window.open('${m.link}','_blank')">Rejoindre</button>
      </div>
    `).join('');
  }

  function initTeamsModule() {
    const btnNew = qs('#teams-btn-new');
    if (btnNew) btnNew.addEventListener('click', () => window.open('https://teams.microsoft.com/l/meeting/new', '_blank'));
    const btnSchedule = qs('#teams-btn-schedule');
    if (btnSchedule) btnSchedule.addEventListener('click', () => window.open('https://teams.microsoft.com/l/meeting/schedule', '_blank'));
    renderTeamsMeetings();
  }

  /* ─────────────────────────────────────────────
     TOAST NOTIFICATION
  ───────────────────────────────────────────── */

  function showToast(msg) {
    let toast = qs('#courriel-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'courriel-toast';
      toast.style.cssText = 'position:fixed;bottom:32px;right:32px;z-index:9999;background:var(--c-emerald,#34d399);color:#0f172a;padding:12px 24px;border-radius:10px;font-weight:600;font-size:0.9rem;box-shadow:0 4px 24px rgba(0,0,0,.3);transition:opacity .3s;opacity:0;pointer-events:none;';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 2500);
  }

  /* ─────────────────────────────────────────────
     INIT PRINCIPAL
  ───────────────────────────────────────────── */

  function initCourriel() {
    // Tabs
    qsa('.courriel-tab').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
    // Modules
    initMailModule();
    initComposeModule();
    initContactsModule();
    initNotesModule();
    initZoomModule();
    initTeamsModule();
    updateChips();
    // Show active tab
    switchTab(state.activeTab);
  }

  /* ─────────────────────────────────────────────
     LAZY INIT via MutationObserver
  ───────────────────────────────────────────── */

  function setupLazyInit() {
    const viewEl = document.getElementById('view-courriel');
    if (!viewEl) return;
    let initialized = false;
    const navBtn = document.querySelector('[data-view="courriel"]');
    function tryInit() {
      if (initialized) return;
      if (!viewEl.classList.contains('view-hidden')) {
        initialized = true;
        initCourriel();
      }
    }
    const observer = new MutationObserver(tryInit);
    observer.observe(viewEl, { attributes: true, attributeFilter: ['class'] });
    if (navBtn) navBtn.addEventListener('click', () => setTimeout(tryInit, 50));
    // If already visible on load
    tryInit();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupLazyInit);
  } else {
    setupLazyInit();
  }

})();
