/* ═══════════════════════════════════════════════════════════════
   FlowState — Documents IA (Premium)
   documents.js — Generateur de contrats, soumissions,
                  estimations, documents administratifs
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── Etat ─────────────────────────────────────────────────── */
  const STATE = {
    isPremium: true,  // desactive pour dev
    docs: [],
    activeDoc: null,
    activeTab: 'form', // 'form' | 'preview'
    nextId: 1
  };

  /* ── Types de documents ───────────────────────────────────── */
  const DOC_TYPES = {
    contrat_service: {
      label: 'Contrat de service',
      icon: '📋',
      badge: 'contrat',
      color: '#818cf8',
      bg: 'rgba(129,140,248,.12)',
      fields: ['parties', 'objet', 'duree', 'montant', 'clauses']
    },
    contrat_emploi: {
      label: 'Contrat d\'emploi',
      icon: '👤',
      badge: 'contrat',
      color: '#818cf8',
      bg: 'rgba(129,140,248,.12)',
      fields: ['parties', 'poste', 'duree', 'salaire', 'clauses']
    },
    contrat_nda: {
      label: 'NDA / Confidentialite',
      icon: '🔒',
      badge: 'contrat',
      color: '#818cf8',
      bg: 'rgba(129,140,248,.12)',
      fields: ['parties', 'objet', 'duree', 'clauses']
    },
    soumission: {
      label: 'Soumission',
      icon: '📨',
      badge: 'soumission',
      color: '#22d3ee',
      bg: 'rgba(34,211,238,.12)',
      fields: ['parties', 'items', 'conditions']
    },
    estimation: {
      label: 'Estimation de projet',
      icon: '📐',
      badge: 'estimation',
      color: '#34d399',
      bg: 'rgba(52,211,153,.12)',
      fields: ['parties', 'items', 'conditions', 'validite']
    },
    facture: {
      label: 'Facture',
      icon: '🧾',
      badge: 'admin',
      color: '#f59e0b',
      bg: 'rgba(245,158,11,.12)',
      fields: ['parties', 'items', 'paiement']
    },
    lettre_affaires: {
      label: 'Lettre d\'affaires',
      icon: '✉️',
      badge: 'lettre',
      color: '#fb7185',
      bg: 'rgba(251,113,133,.12)',
      fields: ['parties', 'objet', 'corps']
    },
    bon_commande: {
      label: 'Bon de commande',
      icon: '🛒',
      badge: 'admin',
      color: '#f59e0b',
      bg: 'rgba(245,158,11,.12)',
      fields: ['parties', 'items', 'livraison']
    },
    rapport_admin: {
      label: 'Rapport administratif',
      icon: '📊',
      badge: 'admin',
      color: '#f59e0b',
      bg: 'rgba(245,158,11,.12)',
      fields: ['meta', 'sections']
    },
    politique_interne: {
      label: 'Politique interne',
      icon: '📜',
      badge: 'admin',
      color: '#f59e0b',
      bg: 'rgba(245,158,11,.12)',
      fields: ['meta', 'sections']
    }
  };

  /* ── Donnees par defaut des documents ─────────────────────── */
  const DEFAULT_DOCS = [
    {
      id: 1, type: 'contrat_service', name: 'Contrat developpement web',
      date: '2026-04-03', status: 'brouillon',
      data: {
        emetteur_nom: 'FlowState Inc.', emetteur_adresse: '123 Rue Principale, Montreal, QC H2X 1Y5',
        emetteur_tel: '514 555-0123', emetteur_email: 'info@flowstate.ca',
        client_nom: 'Boutique Vert Nature', client_adresse: '456 Avenue du Commerce, Quebec, QC G1K 2Z8',
        client_tel: '418 555-0456', client_email: 'contact@vertnature.ca',
        objet: 'Developpement et livraison d\'un site e-commerce complet avec gestion des stocks et integration de paiement.',
        date_debut: '2026-05-01', date_fin: '2026-08-31',
        montant: '18500.00', devise: 'CAD',
        paiement: 'Acompte de 30% a la signature, 40% a mi-parcours, 30% a la livraison.',
        clauses: [
          { num: '1', titre: 'Objet du contrat', texte: 'Le Prestataire s\'engage a realiser les services decrits dans le cahier des charges annexe au present contrat, dans les delais et conditions stipules.' },
          { num: '2', titre: 'Delais et livrables', texte: 'Les travaux seront realises selon le calendrier convenu. Tout retard imputable au Client ne saurait etre reproche au Prestataire.' },
          { num: '3', titre: 'Propriete intellectuelle', texte: 'A la reception du paiement integral, la propriete intellectuelle du livrable est transferee au Client, a l\'exception des outils et composants tiers.' },
          { num: '4', titre: 'Confidentialite', texte: 'Les parties s\'engagent a maintenir confidentielles toutes informations echangees dans le cadre de ce contrat.' },
          { num: '5', titre: 'Resiliation', texte: 'Toute resiliation doit etre notifiee par ecrit 30 jours a l\'avance. Les travaux realises seront facturer au prorata.' }
        ]
      }
    },
    {
      id: 2, type: 'soumission', name: 'Soumission renovation bureau',
      date: '2026-04-02', status: 'envoye',
      data: {
        emetteur_nom: 'Construction Beausoleil', emetteur_adresse: '789 Boulevard Industriel, Laval, QC H7N 5J4',
        emetteur_tel: '450 555-0789', emetteur_email: 'soumissions@beausoleil.ca',
        client_nom: 'Immobilier Delta', client_adresse: '321 Rue des Affaires, Montreal, QC H3B 4G7',
        client_tel: '514 555-0321', client_email: 'projets@deltaimmo.ca',
        validite: '30 jours',
        items: [
          { desc: 'Demolition et preparation', qte: '1', unite: 'forfait', prix: '4200' },
          { desc: 'Plancher de bois franc - installation', qte: '85', unite: 'm2', prix: '65' },
          { desc: 'Peinture complete (murs et plafonds)', qte: '120', unite: 'm2', prix: '18' },
          { desc: 'Eclairage LED encastre', qte: '24', unite: 'unite', prix: '85' },
          { desc: 'Cloisons vitrées bureau direction', qte: '2', unite: 'unite', prix: '1800' },
          { desc: 'Nettoyage final et evacuation debris', qte: '1', unite: 'forfait', prix: '650' }
        ],
        tps: '5', tvq: '9.975',
        conditions: 'Paiement a 50% au debut des travaux et 50% a la remise des cles. Garantie d\'un an sur la main-d\'oeuvre.'
      }
    },
    {
      id: 3, type: 'estimation', name: 'Estimation app mobile Q3',
      date: '2026-04-01', status: 'brouillon',
      data: {
        emetteur_nom: 'DevStudio Pro', emetteur_adresse: '555 Rue Tech, Montreal, QC H2Y 1A1',
        emetteur_tel: '514 555-0555', emetteur_email: 'projets@devstudio.ca',
        client_nom: 'Startup Innova', client_adresse: '888 Avenue Startup, Montreal, QC H3A 2T8',
        client_tel: '514 555-0888', client_email: 'cto@innova.io',
        validite: '60 jours',
        items: [
          { desc: 'Analyse et architecture technique', qte: '40', unite: 'heures', prix: '145' },
          { desc: 'Design UX/UI (maquettes interactives)', qte: '60', unite: 'heures', prix: '120' },
          { desc: 'Developpement iOS (Swift/SwiftUI)', qte: '200', unite: 'heures', prix: '135' },
          { desc: 'Developpement Android (Kotlin)', qte: '200', unite: 'heures', prix: '135' },
          { desc: 'Backend API (Node.js + PostgreSQL)', qte: '120', unite: 'heures', prix: '145' },
          { desc: 'Tests QA et correction bugs', qte: '80', unite: 'heures', prix: '95' },
          { desc: 'Deploiement App Store & Google Play', qte: '1', unite: 'forfait', prix: '2500' },
          { desc: 'Formation equipe (2 jours)', qte: '16', unite: 'heures', prix: '200' }
        ],
        tps: '5', tvq: '9.975',
        conditions: 'Cette estimation est basee sur les specifications initiales. Tout ajout de fonctionnalites fera l\'objet d\'un avenant. Delai de realisation estime: 5 mois.'
      }
    },
    {
      id: 4, type: 'lettre_affaires', name: 'Lettre de partenariat',
      date: '2026-03-28', status: 'signe',
      data: {
        emetteur_nom: 'Marie-Claude Tremblay', emetteur_titre: 'Directrice des partenariats',
        emetteur_entreprise: 'FlowState Inc.',
        client_nom: 'Jean-Philippe Morin', client_titre: 'Directeur general',
        client_entreprise: 'Groupe Synergix',
        objet: 'Proposition de partenariat strategique',
        corps: 'Madame, Monsieur,\n\nSuite a notre rencontre du 15 mars dernier, nous sommes heureux de vous soumettre cette proposition de partenariat strategique entre nos deux organisations.\n\nNous croyons fermement que la complementarite de nos expertises et de nos reseaux respectifs constitue une opportunite unique de croissance mutuelle.\n\nNous demeurons disponibles pour une rencontre afin de discuter des modalites de cette collaboration.\n\nVeuillez agreer, Madame, Monsieur, l\'expression de nos salutations distinguees.'
      }
    }
  ];

  /* ── Calculs financiers ───────────────────────────────────── */
  function calcTotals(items, tps, tvq) {
    const subtotal = (items || []).reduce((sum, it) => {
      return sum + (parseFloat(it.qte || 0) * parseFloat(it.prix || 0));
    }, 0);
    const tpsAmt = subtotal * (parseFloat(tps || 0) / 100);
    const tvqAmt = subtotal * (parseFloat(tvq || 0) / 100);
    const total  = subtotal + tpsAmt + tvqAmt;
    return { subtotal, tpsAmt, tvqAmt, total };
  }

  function fmt(n) {
    return new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD' }).format(n || 0);
  }

  function fmtDate(d) {
    if (!d) return '';
    try { return new Date(d).toLocaleDateString('fr-CA', { year: 'numeric', month: 'long', day: 'numeric' }); }
    catch { return d; }
  }

  function today() {
    return new Date().toISOString().split('T')[0];
  }

  /* ── Rendu liste documents ────────────────────────────────── */
  function renderDocList(filter) {
    const list = document.getElementById('doc-list');
    if (!list) return;

    let docs = STATE.docs;
    if (filter && filter !== 'tous') {
      docs = docs.filter(d => DOC_TYPES[d.type]?.badge === filter);
    }

    list.innerHTML = '';
    if (docs.length === 0) {
      list.innerHTML = '<div style="padding:1.5rem;text-align:center;color:rgba(255,255,255,.25);font-size:.75rem;">Aucun document</div>';
      return;
    }

    docs.forEach(doc => {
      const typeInfo = DOC_TYPES[doc.type] || {};
      const item = document.createElement('div');
      item.className = `doc-item${doc.id === STATE.activeDoc?.id ? ' active' : ''}`;
      item.dataset.id = doc.id;

      const statusColors = { brouillon: '#fbbf24', envoye: '#22d3ee', signe: '#34d399', refuse: '#fb7185' };
      const statusLabels = { brouillon: 'Brouillon', envoye: 'Envoye', signe: 'Signe', refuse: 'Refuse' };

      item.innerHTML = `
        <div class="doc-item-icon" style="background:${typeInfo.bg || 'rgba(255,255,255,.06)'}">
          ${typeInfo.icon || '📄'}
        </div>
        <div class="doc-item-info">
          <div class="doc-item-name">${doc.name}</div>
          <div class="doc-item-meta">
            <span class="doc-item-badge ${typeInfo.badge || 'admin'}">${typeInfo.badge?.toUpperCase() || 'DOC'}</span>
            <span style="color:${statusColors[doc.status] || '#fff'};font-weight:700;">${statusLabels[doc.status] || doc.status}</span>
            <span>${fmtDate(doc.date)}</span>
          </div>
        </div>`;
      item.addEventListener('click', () => loadDoc(doc));
      list.appendChild(item);
    });
  }

  /* ── Charger un document ──────────────────────────────────── */
  function loadDoc(doc) {
    STATE.activeDoc = doc;
    renderDocList(STATE.activeFilter);
    renderForm(doc);
    renderPreview(doc);
    switchTab(STATE.activeTab);
    updateEditorHeader(doc);
  }

  function updateEditorHeader(doc) {
    const typeInfo = DOC_TYPES[doc.type] || {};
    const title = document.getElementById('doc-editor-doc-title');
    if (title) title.textContent = doc.name;
    const docType = document.getElementById('doc-editor-doc-type');
    if (docType) docType.textContent = typeInfo.label || doc.type;
  }

  /* ── Rendu formulaire ─────────────────────────────────────── */
  function renderForm(doc) {
    const panel = document.getElementById('doc-form-panel');
    if (!panel) return;
    panel.innerHTML = '';

    const d = doc.data || {};
    const typeInfo = DOC_TYPES[doc.type] || {};
    const fields = typeInfo.fields || [];

    // Section infos document
    const infoSection = createFormSection('Informations du document', '📄', `
      <div class="doc-form-row triple">
        <div class="doc-field">
          <div class="doc-field-label">Titre</div>
          <input type="text" class="doc-field-input" id="df-name" value="${esc(doc.name)}" placeholder="Titre du document" />
        </div>
        <div class="doc-field">
          <div class="doc-field-label">Date</div>
          <input type="date" class="doc-field-input" id="df-date" value="${doc.date || today()}" />
        </div>
        <div class="doc-field">
          <div class="doc-field-label">Statut</div>
          <select class="doc-field-input doc-field-select" id="df-status">
            ${['brouillon','envoye','signe','refuse'].map(s => `<option value="${s}"${doc.status===s?' selected':''}>${s.charAt(0).toUpperCase()+s.slice(1)}</option>`).join('')}
          </select>
        </div>
      </div>
    `);
    panel.appendChild(infoSection);

    // Parties
    if (fields.includes('parties')) {
      const partiesSection = createFormSection('Parties', '👥', `
        <div class="doc-form-row">
          <div>
            <div class="doc-field-label" style="margin-bottom:.4rem;color:var(--c-indigo,#818cf8);">🏢 Emetteur / Prestataire</div>
            <div class="doc-field" style="margin-bottom:.5rem;">
              <div class="doc-field-label">Nom / Entreprise</div>
              <input type="text" class="doc-field-input" id="df-em-nom" value="${esc(d.emetteur_nom || '')}" placeholder="Votre entreprise" />
            </div>
            <div class="doc-field" style="margin-bottom:.5rem;">
              <div class="doc-field-label">Adresse</div>
              <input type="text" class="doc-field-input" id="df-em-adresse" value="${esc(d.emetteur_adresse || '')}" placeholder="123 Rue Principale, Ville, Province" />
            </div>
            <div class="doc-form-row" style="margin:0">
              <div class="doc-field">
                <div class="doc-field-label">Telephone</div>
                <input type="text" class="doc-field-input" id="df-em-tel" value="${esc(d.emetteur_tel || '')}" placeholder="514 555-0000" />
              </div>
              <div class="doc-field">
                <div class="doc-field-label">Courriel</div>
                <input type="email" class="doc-field-input" id="df-em-email" value="${esc(d.emetteur_email || '')}" placeholder="contact@entreprise.ca" />
              </div>
            </div>
          </div>
          <div>
            <div class="doc-field-label" style="margin-bottom:.4rem;color:var(--c-cyan,#22d3ee);">👤 Client / Destinataire</div>
            <div class="doc-field" style="margin-bottom:.5rem;">
              <div class="doc-field-label">Nom / Entreprise</div>
              <input type="text" class="doc-field-input" id="df-cl-nom" value="${esc(d.client_nom || '')}" placeholder="Nom du client" />
            </div>
            <div class="doc-field" style="margin-bottom:.5rem;">
              <div class="doc-field-label">Adresse</div>
              <input type="text" class="doc-field-input" id="df-cl-adresse" value="${esc(d.client_adresse || '')}" placeholder="456 Avenue Client, Ville, Province" />
            </div>
            <div class="doc-form-row" style="margin:0">
              <div class="doc-field">
                <div class="doc-field-label">Telephone</div>
                <input type="text" class="doc-field-input" id="df-cl-tel" value="${esc(d.client_tel || '')}" placeholder="514 555-0000" />
              </div>
              <div class="doc-field">
                <div class="doc-field-label">Courriel</div>
                <input type="email" class="doc-field-input" id="df-cl-email" value="${esc(d.client_email || '')}" placeholder="client@entreprise.ca" />
              </div>
            </div>
          </div>
        </div>
      `);
      panel.appendChild(partiesSection);
    }

    // Objet / Corps
    if (fields.includes('objet')) {
      const objetSection = createFormSection('Description / Objet', '📝', `
        <div class="doc-form-row full">
          <div class="doc-field">
            <div class="doc-field-label">Description des services ou de la lettre</div>
            <textarea class="doc-field-input doc-field-textarea" id="df-objet" rows="4" placeholder="Decrivez l'objet du document...">${esc(d.objet || d.corps || '')}</textarea>
          </div>
        </div>
      `);
      panel.appendChild(objetSection);
    }

    // Duree et montant (contrats)
    if (fields.includes('duree') || fields.includes('montant')) {
      const finSection = createFormSection('Conditions financieres et duree', '💰', `
        <div class="doc-form-row triple">
          ${fields.includes('duree') ? `
          <div class="doc-field">
            <div class="doc-field-label">Date de debut</div>
            <input type="date" class="doc-field-input" id="df-date-debut" value="${d.date_debut || ''}" />
          </div>
          <div class="doc-field">
            <div class="doc-field-label">Date de fin</div>
            <input type="date" class="doc-field-input" id="df-date-fin" value="${d.date_fin || ''}" />
          </div>
          ` : ''}
          ${fields.includes('montant') ? `
          <div class="doc-field">
            <div class="doc-field-label">Montant total ($)</div>
            <input type="number" class="doc-field-input" id="df-montant" value="${d.montant || ''}" placeholder="0.00" step="0.01" />
          </div>
          ` : ''}
        </div>
        ${fields.includes('montant') ? `
        <div class="doc-form-row full">
          <div class="doc-field">
            <div class="doc-field-label">Modalites de paiement</div>
            <textarea class="doc-field-input doc-field-textarea" id="df-paiement" rows="2" placeholder="Ex: 50% a la signature, 50% a la livraison...">${esc(d.paiement || '')}</textarea>
          </div>
        </div>
        ` : ''}
      `);
      panel.appendChild(finSection);
    }

    // Lignes d'items (soumission, estimation, facture)
    if (fields.includes('items')) {
      const itemsSection = createItemsSection(doc);
      panel.appendChild(itemsSection);
    }

    // Clauses (contrats)
    if (fields.includes('clauses')) {
      const clausesSection = createClausesSection(doc);
      panel.appendChild(clausesSection);
    }

    // Conditions generales
    if (fields.includes('conditions') || fields.includes('livraison')) {
      const condSection = createFormSection('Conditions et notes', '📋', `
        <div class="doc-form-row full">
          <div class="doc-field">
            <div class="doc-field-label">Validite de la soumission / conditions</div>
            <input type="text" class="doc-field-input" id="df-validite" value="${esc(d.validite || '')}" placeholder="Ex: 30 jours, 60 jours..." />
          </div>
        </div>
        <div class="doc-form-row full">
          <div class="doc-field">
            <div class="doc-field-label">Conditions generales</div>
            <textarea class="doc-field-input doc-field-textarea" id="df-conditions" rows="3" placeholder="Conditions de paiement, garantie, delai...">${esc(d.conditions || '')}</textarea>
          </div>
        </div>
      `);
      panel.appendChild(condSection);
    }

    // Bouton sauvegarder
    const saveBar = document.createElement('div');
    saveBar.style.cssText = 'display:flex;gap:.6rem;align-items:center;padding-top:.5rem;';
    saveBar.innerHTML = `
      <button class="doc-btn doc-btn-primary" id="df-save-btn" style="padding:.6rem 1.4rem;font-size:.8rem;">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" width="13" height="13"><path d="M13 4H6L3 7v6a1 1 0 001 1h9a1 1 0 001-1V5a1 1 0 00-1-1z"/><path d="M9 14V9H6v5"/></svg>
        Sauvegarder
      </button>
      <button class="doc-btn doc-btn-ia" id="df-ia-btn" style="padding:.6rem 1.2rem;font-size:.8rem;">
        🤖 Ameliorer avec ARIA
      </button>`;
    panel.appendChild(saveBar);

    // Evenements du formulaire
    document.getElementById('df-save-btn')?.addEventListener('click', () => saveFormToDoc(doc));
    document.getElementById('df-ia-btn')?.addEventListener('click', () => improveWithIA(doc));
  }

  function createFormSection(title, icon, html) {
    const section = document.createElement('div');
    section.className = 'doc-form-section';
    section.innerHTML = `<div class="doc-form-section-title">${icon} ${title}</div>${html}`;
    return section;
  }

  function createItemsSection(doc) {
    const d = doc.data || {};
    const items = d.items || [];
    const section = document.createElement('div');
    section.className = 'doc-form-section';
    section.id = 'df-items-section';

    function buildTable() {
      const totals = calcTotals(items, d.tps, d.tvq);
      section.innerHTML = `
        <div class="doc-form-section-title">📦 Lignes de service / produit</div>
        <table class="doc-items-table">
          <thead>
            <tr>
              <th style="width:40%">Description</th>
              <th style="width:12%">Qte</th>
              <th style="width:15%">Unite</th>
              <th style="width:17%">Prix unit.</th>
              <th style="width:13%">Total</th>
              <th style="width:5%"></th>
            </tr>
          </thead>
          <tbody id="df-items-body">
            ${items.map((it, idx) => `
              <tr data-idx="${idx}">
                <td><input type="text" class="doc-item-input" data-field="desc" data-idx="${idx}" value="${esc(it.desc || '')}" placeholder="Description..." /></td>
                <td><input type="number" class="doc-item-input" data-field="qte" data-idx="${idx}" value="${it.qte || 1}" min="0" step="0.5" style="width:60px;" /></td>
                <td><input type="text" class="doc-item-input" data-field="unite" data-idx="${idx}" value="${esc(it.unite || 'unite')}" style="width:70px;" /></td>
                <td><input type="number" class="doc-item-input" data-field="prix" data-idx="${idx}" value="${it.prix || ''}" min="0" step="0.01" style="width:90px;" /></td>
                <td style="font-weight:700;color:rgba(255,255,255,.7);font-size:.75rem;">${fmt(parseFloat(it.qte||0)*parseFloat(it.prix||0))}</td>
                <td><button class="doc-item-del" data-del="${idx}">✕</button></td>
              </tr>`).join('')}
          </tbody>
        </table>
        <button class="doc-add-line-btn" id="df-add-item">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M8 3v10M3 8h10"/></svg>
          Ajouter une ligne
        </button>
        <div class="doc-form-row" style="margin-top:.8rem;">
          <div class="doc-field">
            <div class="doc-field-label">TPS (%)</div>
            <input type="number" class="doc-field-input" id="df-tps" value="${d.tps || 5}" step="0.001" />
          </div>
          <div class="doc-field">
            <div class="doc-field-label">TVQ (%)</div>
            <input type="number" class="doc-field-input" id="df-tvq" value="${d.tvq || 9.975}" step="0.001" />
          </div>
        </div>
        <div class="doc-totals">
          <div class="doc-total-row"><span class="doc-total-label">Sous-total</span><span class="doc-total-val" id="df-subtotal">${fmt(totals.subtotal)}</span></div>
          <div class="doc-total-row"><span class="doc-total-label">TPS (${d.tps||5}%)</span><span class="doc-total-val" id="df-tps-amt">${fmt(totals.tpsAmt)}</span></div>
          <div class="doc-total-row"><span class="doc-total-label">TVQ (${d.tvq||9.975}%)</span><span class="doc-total-val" id="df-tvq-amt">${fmt(totals.tvqAmt)}</span></div>
          <div class="doc-total-row grand"><span class="doc-total-label">TOTAL</span><span class="doc-total-val" id="df-total">${fmt(totals.total)}</span></div>
        </div>`;

      // Events items
      section.querySelectorAll('.doc-item-input').forEach(input => {
        input.addEventListener('input', () => {
          const idx = parseInt(input.dataset.idx);
          const field = input.dataset.field;
          if (!items[idx]) items[idx] = {};
          items[idx][field] = input.value;
          updateTotals();
        });
      });
      section.querySelectorAll('[data-del]').forEach(btn => {
        btn.addEventListener('click', () => {
          items.splice(parseInt(btn.dataset.del), 1);
          buildTable();
        });
      });
      section.querySelector('#df-add-item')?.addEventListener('click', () => {
        items.push({ desc: '', qte: '1', unite: 'unite', prix: '' });
        buildTable();
        const inputs = section.querySelectorAll('.doc-item-input[data-field="desc"]');
        inputs[inputs.length - 1]?.focus();
      });
      ['#df-tps','#df-tvq'].forEach(id => {
        section.querySelector(id)?.addEventListener('input', (e) => {
          d[id.replace('#df-','').replace('-','q')] = e.target.value;
          updateTotals();
        });
      });
      document.getElementById('df-tps')?.addEventListener('input', e => { d.tps = e.target.value; updateTotals(); });
      document.getElementById('df-tvq')?.addEventListener('input', e => { d.tvq = e.target.value; updateTotals(); });
    }

    function updateTotals() {
      const totals = calcTotals(items, d.tps, d.tvq);
      const st = section.querySelector('#df-subtotal'); if (st) st.textContent = fmt(totals.subtotal);
      const ta = section.querySelector('#df-tps-amt'); if (ta) ta.textContent = fmt(totals.tpsAmt);
      const va = section.querySelector('#df-tvq-amt'); if (va) va.textContent = fmt(totals.tvqAmt);
      const to = section.querySelector('#df-total'); if (to) to.textContent = fmt(totals.total);
    }

    buildTable();
    return section;
  }

  function createClausesSection(doc) {
    const d = doc.data || {};
    const clauses = d.clauses || [];
    const section = document.createElement('div');
    section.className = 'doc-form-section';
    section.innerHTML = `
      <div class="doc-form-section-title">📜 Clauses contractuelles</div>
      ${clauses.map((c, i) => `
        <div style="margin-bottom:1rem;padding:.85rem;background:rgba(255,255,255,.03);border-radius:10px;border:1px solid rgba(255,255,255,.07);">
          <div class="doc-form-row triple" style="margin-bottom:.4rem;">
            <div class="doc-field">
              <div class="doc-field-label">Article n°</div>
              <input type="text" class="doc-field-input" id="df-cl-num-${i}" value="${esc(c.num)}" style="width:60px;" />
            </div>
            <div class="doc-field" style="grid-column:2/4;">
              <div class="doc-field-label">Titre de la clause</div>
              <input type="text" class="doc-field-input" id="df-cl-titre-${i}" value="${esc(c.titre)}" placeholder="Ex: Propriete intellectuelle..." />
            </div>
          </div>
          <div class="doc-field">
            <div class="doc-field-label">Contenu</div>
            <textarea class="doc-field-input doc-field-textarea" id="df-cl-texte-${i}" rows="3">${esc(c.texte)}</textarea>
          </div>
        </div>`).join('')}
      <button class="doc-add-line-btn" id="df-add-clause">
        <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" width="12" height="12"><path d="M8 3v10M3 8h10"/></svg>
        Ajouter une clause
      </button>`;

    section.querySelector('#df-add-clause')?.addEventListener('click', () => {
      clauses.push({ num: String(clauses.length + 1), titre: 'Nouvelle clause', texte: '' });
      const cs = createClausesSection(doc);
      section.replaceWith(cs);
    });
    return section;
  }

  /* ── Sauvegarder formulaire → doc ────────────────────────── */
  function saveFormToDoc(doc) {
    const d = doc.data;
    const get = (id) => document.getElementById(id)?.value || '';

    doc.name   = get('df-name') || doc.name;
    doc.date   = get('df-date') || doc.date;
    doc.status = get('df-status') || doc.status;

    d.emetteur_nom     = get('df-em-nom');
    d.emetteur_adresse = get('df-em-adresse');
    d.emetteur_tel     = get('df-em-tel');
    d.emetteur_email   = get('df-em-email');
    d.client_nom       = get('df-cl-nom');
    d.client_adresse   = get('df-cl-adresse');
    d.client_tel       = get('df-cl-tel');
    d.client_email     = get('df-cl-email');
    d.objet     = get('df-objet') || d.objet;
    d.corps     = get('df-objet') || d.corps;
    d.montant   = get('df-montant') || d.montant;
    d.paiement  = get('df-paiement') || d.paiement;
    d.validite  = get('df-validite') || d.validite;
    d.conditions= get('df-conditions') || d.conditions;
    d.date_debut= get('df-date-debut') || d.date_debut;
    d.date_fin  = get('df-date-fin') || d.date_fin;
    d.tps       = get('df-tps') || d.tps;
    d.tvq       = get('df-tvq') || d.tvq;

    // Clauses
    const clauseInputs = [];
    let i = 0;
    while (document.getElementById(`df-cl-titre-${i}`)) {
      clauseInputs.push({
        num:   document.getElementById(`df-cl-num-${i}`)?.value || String(i+1),
        titre: document.getElementById(`df-cl-titre-${i}`)?.value || '',
        texte: document.getElementById(`df-cl-texte-${i}`)?.value || ''
      });
      i++;
    }
    if (clauseInputs.length > 0) d.clauses = clauseInputs;

    renderDocList(STATE.activeFilter);
    renderPreview(doc);
    updateEditorHeader(doc);
    showToast('Document sauvegarde', 'success');
  }

  /* ── Amelioration IA ──────────────────────────────────────── */
  function improveWithIA(doc) {
    const bar = document.getElementById('doc-ia-bar');
    if (bar) bar.classList.add('visible');
    setTimeout(() => {
      if (bar) bar.classList.remove('visible');
      showToast('ARIA a ameliore le document', 'success');
      renderPreview(doc);
    }, 2200 + Math.random() * 800);
  }

  /* ── Rendu apercu (papier) ───────────────────────────────── */
  function renderPreview(doc) {
    const paper = document.getElementById('doc-paper');
    if (!paper) return;
    const d = doc.data || {};
    const typeInfo = DOC_TYPES[doc.type] || {};

    let html = '';

    // En-tete
    html += `
      <div class="doc-paper-header">
        <div>
          <div class="doc-paper-logo">Flow<span>State</span></div>
          <div style="font-size:.72rem;color:#666;margin-top:.2rem;">${esc(d.emetteur_nom || '')}</div>
          <div style="font-size:.68rem;color:#888;">${esc(d.emetteur_adresse || '')}</div>
          <div style="font-size:.68rem;color:#888;">${esc(d.emetteur_tel || '')}${d.emetteur_tel && d.emetteur_email ? ' · ' : ''}${esc(d.emetteur_email || '')}</div>
        </div>
        <div class="doc-paper-meta">
          <div style="margin-bottom:.3rem;"><strong>${typeInfo.label || 'Document'}</strong></div>
          <div>N° <strong>${String(doc.id).padStart(4,'0')}</strong></div>
          <div>Date : <strong>${fmtDate(doc.date)}</strong></div>
          ${d.validite ? `<div>Valide jusqu'au : <strong>${d.validite}</strong></div>` : ''}
        </div>
      </div>
      <div class="doc-paper-title">${typeInfo.label || 'Document'}</div>
      <div class="doc-paper-subtitle">${esc(doc.name)}</div>`;

    // Parties
    if (d.client_nom || d.emetteur_nom) {
      html += `<div class="doc-paper-parties">`;
      if (d.emetteur_nom) {
        html += `<div class="doc-paper-party">
          <div class="doc-paper-party-label">Prestataire / Emetteur</div>
          <div class="doc-paper-party-name">${esc(d.emetteur_nom)}</div>
          <div class="doc-paper-party-info">${esc(d.emetteur_adresse || '')}<br>${esc(d.emetteur_tel || '')} — ${esc(d.emetteur_email || '')}</div>
        </div>`;
      }
      if (d.client_nom) {
        html += `<div class="doc-paper-party">
          <div class="doc-paper-party-label">Client / Destinataire</div>
          <div class="doc-paper-party-name">${esc(d.client_nom)}</div>
          <div class="doc-paper-party-info">${esc(d.client_adresse || '')}<br>${esc(d.client_tel || '')} — ${esc(d.client_email || '')}</div>
        </div>`;
      }
      html += '</div>';
    }

    // Objet / Corps (pour lettres et contrats)
    if (d.objet && !d.items) {
      html += `<div class="doc-paper-section">
        <div class="doc-paper-section-title">Objet</div>
        <p>${esc(d.objet).replace(/\n/g, '<br>')}</p>
      </div>`;
    }
    if (d.corps) {
      html += `<div class="doc-paper-section">
        <p>${esc(d.corps).replace(/\n/g, '<br>')}</p>
      </div>`;
    }

    // Duree / Montant fixe
    if (d.date_debut || d.date_fin || d.montant) {
      html += `<div class="doc-paper-section">
        <div class="doc-paper-section-title">Conditions financieres</div>
        <table style="width:100%;font-size:.8rem;">
          ${d.date_debut ? `<tr><td style="padding:.3rem 0;color:#555;width:35%">Date de debut</td><td style="font-weight:700;">${fmtDate(d.date_debut)}</td></tr>` : ''}
          ${d.date_fin ? `<tr><td style="padding:.3rem 0;color:#555;">Date de fin</td><td style="font-weight:700;">${fmtDate(d.date_fin)}</td></tr>` : ''}
          ${d.montant ? `<tr><td style="padding:.3rem 0;color:#555;">Montant total</td><td style="font-weight:900;font-size:.95rem;color:#111;">${fmt(parseFloat(d.montant))}</td></tr>` : ''}
          ${d.paiement ? `<tr><td style="padding:.3rem 0;color:#555;vertical-align:top;">Modalites de paiement</td><td>${esc(d.paiement)}</td></tr>` : ''}
        </table>
      </div>`;
    }

    // Tableau items
    if (d.items && d.items.length > 0) {
      const totals = calcTotals(d.items, d.tps, d.tvq);
      html += `<div class="doc-paper-section">
        <div class="doc-paper-section-title">Detail des services</div>
        <table class="doc-paper-table">
          <thead><tr>
            <th>Description</th><th>Qte</th><th>Unite</th><th>Prix unit.</th><th>Total</th>
          </tr></thead>
          <tbody>
            ${d.items.map(it => {
              const lineTotal = parseFloat(it.qte||0) * parseFloat(it.prix||0);
              return `<tr>
                <td>${esc(it.desc || '')}</td>
                <td style="text-align:center;">${esc(it.qte || 1)}</td>
                <td style="text-align:center;">${esc(it.unite || '')}</td>
                <td style="text-align:right;">${fmt(parseFloat(it.prix||0))}</td>
                <td>${fmt(lineTotal)}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
        <div class="doc-paper-totals">
          <div class="doc-paper-total-row"><span>Sous-total</span><span>${fmt(totals.subtotal)}</span></div>
          <div class="doc-paper-total-row"><span>TPS (${d.tps||5}%)</span><span>${fmt(totals.tpsAmt)}</span></div>
          <div class="doc-paper-total-row"><span>TVQ (${d.tvq||9.975}%)</span><span>${fmt(totals.tvqAmt)}</span></div>
          <div class="doc-paper-total-row grand"><span>TOTAL</span><span>${fmt(totals.total)}</span></div>
        </div>
      </div>`;
    }

    // Clauses (contrats)
    if (d.clauses && d.clauses.length > 0) {
      html += `<div class="doc-paper-section">
        <div class="doc-paper-section-title">Clauses et conditions</div>
        ${d.clauses.map(c => `
          <div class="doc-paper-clause">
            <span class="doc-paper-clause-num">Art. ${esc(c.num)} —</span>
            <strong>${esc(c.titre)}</strong><br/>
            ${esc(c.texte).replace(/\n/g,'<br>')}
          </div>`).join('')}
      </div>`;
    }

    // Conditions generales
    if (d.conditions) {
      html += `<div class="doc-paper-section">
        <div class="doc-paper-section-title">Conditions generales</div>
        <p style="font-size:.8rem;color:#444;">${esc(d.conditions).replace(/\n/g,'<br>')}</p>
      </div>`;
    }

    // Signatures
    html += `
      <div class="doc-paper-signatures">
        <div class="doc-paper-sig-block">
          <div class="doc-paper-sig-name">${esc(d.emetteur_nom || 'Prestataire')}</div>
          <div class="doc-paper-sig-line"></div>
          <div>Signature</div>
          <div style="margin-top:.3rem;">Date : ___________________</div>
        </div>
        <div class="doc-paper-sig-block">
          <div class="doc-paper-sig-name">${esc(d.client_nom || 'Client')}</div>
          <div class="doc-paper-sig-line"></div>
          <div>Signature</div>
          <div style="margin-top:.3rem;">Date : ___________________</div>
        </div>
      </div>
      <div class="doc-paper-footer">
        <span>FlowState — ${typeInfo.label || 'Document'} · ${esc(doc.name)}</span>
        <span>Genere le ${new Date().toLocaleDateString('fr-CA')} · Confidentiel</span>
        <span>Page 1</span>
      </div>`;

    paper.innerHTML = html;
  }

  function esc(str) {
    return String(str || '')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ── Onglets editeur ──────────────────────────────────────── */
  function switchTab(tab) {
    STATE.activeTab = tab;
    document.querySelectorAll('.doc-editor-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tab));
    const formPanel    = document.getElementById('doc-form-panel');
    const previewPanel = document.getElementById('doc-preview-panel');
    if (formPanel)    formPanel.classList.toggle('active', tab === 'form');
    if (previewPanel) previewPanel.classList.toggle('active', tab === 'preview');
  }

  /* ── Export HTML / Print ──────────────────────────────────── */
  function exportPrint() {
    if (!STATE.activeDoc) return;
    const paper = document.getElementById('doc-paper');
    if (!paper) return;
    const win = window.open('', '_blank');
    win.document.write(`<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>${STATE.activeDoc.name}</title>
      <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:#fff;font-family:'Georgia',serif;font-size:14px;color:#111;padding:40px 60px;max-width:800px;margin:0 auto;}
        .doc-paper-header{display:flex;justify-content:space-between;margin-bottom:2.5rem;padding-bottom:1.5rem;border-bottom:2px solid #111;}
        .doc-paper-logo{font-size:1.3rem;font-weight:900;font-family:Arial,sans-serif;}
        .doc-paper-logo span{color:#6366f1;}
        .doc-paper-meta{text-align:right;font-size:12px;color:#555;}
        .doc-paper-title{font-size:1.2rem;font-weight:900;text-align:center;text-transform:uppercase;letter-spacing:.05em;margin-bottom:.25rem;}
        .doc-paper-subtitle{font-size:12px;color:#666;text-align:center;margin-bottom:2rem;}
        .doc-paper-parties{display:grid;grid-template-columns:1fr 1fr;gap:2rem;margin-bottom:1.5rem;}
        .doc-paper-party-label{font-weight:900;font-size:10px;text-transform:uppercase;color:#555;margin-bottom:.3rem;}
        .doc-paper-party-name{font-size:13px;font-weight:700;margin-bottom:.2rem;}
        .doc-paper-section-title{font-weight:900;text-transform:uppercase;font-size:11px;letter-spacing:.07em;border-bottom:1px solid #ddd;padding-bottom:.3rem;margin:1.2rem 0 .6rem;}
        table{width:100%;border-collapse:collapse;font-size:12px;}
        th{background:#111;color:#fff;padding:6px 10px;text-align:left;font-size:10px;text-transform:uppercase;}
        td{padding:5px 10px;border-bottom:1px solid #eee;}
        .doc-paper-totals{margin-left:auto;width:250px;border:1px solid #ddd;margin-top:8px;}
        .trow{display:flex;justify-content:space-between;padding:4px 8px;font-size:12px;}
        .trow:not(:last-child){border-bottom:1px solid #eee;}
        .trow.grand{background:#111;color:#fff;font-weight:900;}
        .sigs{display:grid;grid-template-columns:1fr 1fr;gap:3rem;margin-top:3rem;padding-top:1.5rem;border-top:1px solid #ddd;}
        .sig-line{height:1px;background:#111;margin:2rem 0 .3rem;width:80%;}
        .clause{margin-bottom:1rem;font-size:13px;line-height:1.7;}
        footer{margin-top:3rem;padding-top:.6rem;border-top:1px solid #eee;display:flex;justify-content:space-between;font-size:10px;color:#aaa;}
        @media print{body{padding:0;} @page{margin:2cm;}}
      </style></head><body>${paper.innerHTML}</body></html>`);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 400);
  }

  function exportHTML() {
    if (!STATE.activeDoc) return;
    const paper = document.getElementById('doc-paper');
    if (!paper) return;
    const blob = new Blob([`<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><title>${STATE.activeDoc.name}</title></head><body style="font-family:Georgia,serif;padding:40px 60px;max-width:800px;margin:0 auto;">${paper.innerHTML}</body></html>`], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${STATE.activeDoc.name.replace(/\s+/g,'-')}.html`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
    showToast('Document exporte en HTML', 'success');
  }

  /* ── Toast ────────────────────────────────────────────────── */
  function showToast(msg, type) {
    const t = document.createElement('div');
    t.style.cssText = `position:fixed;bottom:2rem;right:2rem;padding:.55rem 1.2rem;border-radius:10px;z-index:9999;font-size:.78rem;font-weight:700;color:#fff;backdrop-filter:blur(12px);pointer-events:none;`;
    t.style.background = type === 'success' ? 'rgba(52,211,153,.92)' : 'rgba(251,113,133,.92)';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2600);
  }

  /* ── Modal nouveau document ───────────────────────────────── */
  function openNewDocModal() {
    document.getElementById('doc-new-overlay')?.classList.add('open');
  }
  function closeNewDocModal() {
    document.getElementById('doc-new-overlay')?.classList.remove('open');
  }

  function createDoc(type, name) {
    const typeInfo = DOC_TYPES[type] || DOC_TYPES.lettre_affaires;
    const hasItems = typeInfo.fields.includes('items');
    const hasClauses = typeInfo.fields.includes('clauses');
    const doc = {
      id: STATE.nextId++,
      type, name: name || typeInfo.label,
      date: today(), status: 'brouillon',
      data: {
        emetteur_nom: 'Votre entreprise', emetteur_adresse: '', emetteur_tel: '', emetteur_email: '',
        client_nom: '', client_adresse: '', client_tel: '', client_email: '',
        objet: '', corps: '', montant: '', paiement: '', validite: '30 jours',
        conditions: '', date_debut: '', date_fin: '',
        tps: '5', tvq: '9.975',
        items: hasItems ? [{ desc: '', qte: '1', unite: 'unite', prix: '' }] : undefined,
        clauses: hasClauses ? [
          { num: '1', titre: 'Objet du contrat', texte: 'Decrivez l\'objet du contrat ici...' },
          { num: '2', titre: 'Conditions de paiement', texte: 'Decrivez les modalites de paiement...' },
          { num: '3', titre: 'Confidentialite', texte: 'Les parties s\'engagent a maintenir confidentielles toutes les informations echangees.' }
        ] : undefined
      }
    };
    STATE.docs.unshift(doc);
    renderDocList(STATE.activeFilter);
    loadDoc(doc);
    return doc;
  }

  /* ════════════════════════════════════════════════════════════
     INIT
  ════════════════════════════════════════════════════════════ */
  function init() {
    const viewDoc = document.getElementById('view-documents');
    if (!viewDoc) return;

    const observer = new MutationObserver(() => {
      if (!viewDoc.classList.contains('view-hidden')) initDocUI();
    });
    observer.observe(viewDoc, { attributes: true, attributeFilter: ['class'] });
    const navBtn = document.querySelector('[data-view="documents"]');
    if (navBtn) navBtn.addEventListener('click', () => setTimeout(initDocUI, 100));
    if (!viewDoc.classList.contains('view-hidden')) initDocUI();
  }

  let _initialized = false;
  function initDocUI() {
    if (_initialized) return;
    _initialized = true;

    // Gate premium
    if (!STATE.isPremium) {
      document.getElementById('doc-premium-gate')?.classList.add('visible');
    }
    document.getElementById('doc-gate-btn')?.addEventListener('click', () => {
      STATE.isPremium = true;
      document.getElementById('doc-premium-gate')?.classList.remove('visible');
      initDocs();
    });
    document.getElementById('doc-gate-bypass')?.addEventListener('click', () => {
      STATE.isPremium = true;
      document.getElementById('doc-premium-gate')?.classList.remove('visible');
      initDocs();
    });

    if (STATE.isPremium) initDocs();
  }

  function initDocs() {
    // Charger les docs par defaut
    STATE.docs = DEFAULT_DOCS.map(d => ({...d, data: {...d.data}}));
    STATE.nextId = 5;
    STATE.activeFilter = 'tous';

    renderDocList('tous');
    loadDoc(STATE.docs[0]);

    // Filtres
    document.querySelectorAll('.doc-filter-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        document.querySelectorAll('.doc-filter-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        STATE.activeFilter = chip.dataset.filter;
        renderDocList(chip.dataset.filter);
      });
    });

    // Bouton + sidebar
    document.getElementById('doc-sidebar-add')?.addEventListener('click', openNewDocModal);
    document.getElementById('doc-btn-new')?.addEventListener('click', openNewDocModal);

    // Onglets editeur
    document.querySelectorAll('.doc-editor-tab').forEach(tab => {
      tab.addEventListener('click', () => switchTab(tab.dataset.tab));
    });

    // Actions editeur
    document.getElementById('doc-action-print')?.addEventListener('click', () => {
      if (STATE.activeDoc) { saveFormToDoc(STATE.activeDoc); setTimeout(exportPrint, 200); }
    });
    document.getElementById('doc-action-export')?.addEventListener('click', () => {
      if (STATE.activeDoc) { saveFormToDoc(STATE.activeDoc); exportHTML(); }
    });
    document.getElementById('doc-action-preview')?.addEventListener('click', () => switchTab('preview'));

    // IA bar close
    document.getElementById('doc-ia-close')?.addEventListener('click', () => {
      document.getElementById('doc-ia-bar')?.classList.remove('visible');
    });

    // Modal nouveau doc
    document.getElementById('doc-new-overlay')?.addEventListener('click', (e) => {
      if (e.target.id === 'doc-new-overlay') closeNewDocModal();
    });
    document.getElementById('doc-new-cancel')?.addEventListener('click', closeNewDocModal);
    document.getElementById('doc-new-close')?.addEventListener('click', closeNewDocModal);
    document.querySelectorAll('.doc-type-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('.doc-type-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });
    document.getElementById('doc-new-create')?.addEventListener('click', () => {
      const type = document.querySelector('.doc-type-card.selected')?.dataset.type || 'lettre_affaires';
      const name = document.getElementById('doc-new-name')?.value.trim() || DOC_TYPES[type]?.label || 'Nouveau document';
      createDoc(type, name);
      closeNewDocModal();
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
