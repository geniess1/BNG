/* ═══════════════════════════════════════════════════════════════
   FlowState — Finance Module Tabs + Budget Chart + Stock updater
   finance-modules.js
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── Onglets de modules ──────────────────────────────────────── */
  const MODULE_MAP = {
    overview:        'fin-overview',
    tresorerie:      'fin-tresorerie',
    investissements: 'fin-investissements',
    stocks:          'fin-stocks',
    fonds:           'fin-fonds',
    budget:          'fin-budget',
    transactions:    'fin-transactions',
  };

  let budgetChartInited = false;

  function switchModule(name) {
    // Tabs
    document.querySelectorAll('.fin-mod-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.module === name);
    });
    // Modules
    Object.values(MODULE_MAP).forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.toggle('fin-module-hidden', id !== MODULE_MAP[name]);
    });
    // Init budget chart on first visit
    if (name === 'budget' && !budgetChartInited) {
      budgetChartInited = true;
      setTimeout(initBudgetChart, 80);
    }
  }

  // Délégation sur le conteneur des onglets
  document.addEventListener('click', e => {
    const tab = e.target.closest('.fin-mod-tab');
    if (tab && tab.dataset.module) switchModule(tab.dataset.module);
  });

  /* ── Recherche stocks ────────────────────────────────────────── */
  document.addEventListener('input', e => {
    if (e.target.id !== 'stocks-search') return;
    const q = e.target.value.toLowerCase();
    document.querySelectorAll('#stocks-table tbody .tx-row').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });

  /* ── Mise à jour prix actions (contenteditable) ─────────────── */
  document.addEventListener('blur', e => {
    if (!e.target.classList.contains('stock-price-cell')) return;
    const cell = e.target;
    const row = cell.closest('.tx-row');
    if (!row) return;
    const cells = row.querySelectorAll('td');
    const qty = parseFloat(cells[2]?.textContent) || 0;
    const cost = parseFloat(cell.dataset.cost) || 0;
    const newPrice = parseFloat(cell.textContent.replace(/[^0-9.]/g, '')) || 0;

    const valActuelle = qty * newPrice;
    const gp_dollar = valActuelle - cost;
    const gp_pct = cost > 0 ? (gp_dollar / cost * 100) : 0;

    // Mise à jour val. actuelle
    if (cells[5]) cells[5].textContent = formatMoney(valActuelle);
    // G/P $
    if (cells[6]) {
      cells[6].textContent = (gp_dollar >= 0 ? '+' : '') + formatMoney(gp_dollar);
      cells[6].className = 'tx-amount ' + (gp_dollar >= 0 ? 'up' : 'down');
    }
    // G/P %
    if (cells[7]) {
      const badge = cells[7].querySelector('.tx-status') || cells[7];
      badge.textContent = (gp_pct >= 0 ? '+' : '') + gp_pct.toFixed(1) + '%';
      badge.className = 'tx-status ' + (gp_pct >= 0 ? 'ok' : 'pend');
    }
    // Format prix
    cell.textContent = newPrice.toFixed(2) + ' $';

    showFinToast('Prix mis à jour ✓');
  }, true);

  function formatMoney(n) {
    return new Intl.NumberFormat('fr-CA').format(Math.round(n)) + ' $';
  }

  /* ── Graphique Budget ────────────────────────────────────────── */
  function initBudgetChart() {
    const ctx = document.getElementById('budget-chart');
    if (!ctx || typeof Chart === 'undefined') return;
    const mois = ['Jan','Fév','Mar','Avr','Mai','Jun','Jul','Aoû','Sep','Oct','Nov','Déc'];
    const prevus  = [20800,20800,20800,20800,20800,20800,20800,20800,20800,20800,20800,20800];
    const reels   = [19200,21400,20100,18900,null,null,null,null,null,null,null,null];

    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: mois,
        datasets: [
          {
            label: 'Prévu',
            data: prevus,
            backgroundColor: 'rgba(167,139,250,.18)',
            borderColor: '#a78bfa',
            borderWidth: 1.5,
            borderRadius: 5,
            borderSkipped: false,
          },
          {
            label: 'Réel',
            data: reels,
            backgroundColor: 'rgba(52,211,153,.22)',
            borderColor: '#34d399',
            borderWidth: 1.5,
            borderRadius: 5,
            borderSkipped: false,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(17,16,26,.92)',
            borderColor: 'rgba(255,255,255,.1)',
            borderWidth: 1,
            titleColor: '#e8e6f0',
            bodyColor: '#9b97b4',
            padding: 10,
            callbacks: {
              label: ctx => ` ${ctx.dataset.label}: ${new Intl.NumberFormat('fr-CA').format(ctx.parsed.y)} $`,
            },
          },
        },
        scales: {
          x: { ticks: { color: 'rgba(232,230,240,.5)', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,.04)' }, border: { color: 'transparent' } },
          y: {
            ticks: { color: 'rgba(232,230,240,.5)', font: { size: 10 }, callback: v => (v/1000).toFixed(0)+'k $' },
            grid: { color: 'rgba(255,255,255,.05)' },
            border: { color: 'transparent' },
          },
        },
      },
    });
  }

  /* ── Toast ───────────────────────────────────────────────────── */
  function showFinToast(msg) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = `<svg class="toast-icon" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14"><path d="M4 10l4 4 8-8" stroke-linecap="round"/></svg><span>${msg}</span>`;
    container.appendChild(t);
    setTimeout(() => { t.classList.add('removing'); setTimeout(() => t.remove(), 280); }, 2400);
  }

  /* ── Initialisation quand la vue finance devient visible ─────── */
  const finView = document.getElementById('view-finance');
  if (finView) {
    const obs = new MutationObserver(() => {
      if (!finView.classList.contains('view-hidden')) {
        // S'assurer que l'onglet Overview est actif par défaut
        switchModule('overview');
      }
    });
    obs.observe(finView, { attributes: true, attributeFilter: ['class'] });
  }

})();
