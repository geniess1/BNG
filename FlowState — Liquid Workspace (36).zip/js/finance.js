/* ═══════════════════════════════════════════════════════════
   FlowState — Module Finances
   Navigation entre vues + graphiques Chart.js
   ═══════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── Auto-init quand la vue Finance devient visible ────── */
  // La navigation est gérée par le loader central (index.html)
  // On observe simplement l'apparition de la vue finance
  const financeViewEl = document.getElementById('view-finance');
  if (financeViewEl) {
    const finObs = new MutationObserver(() => {
      if (!financeViewEl.classList.contains('view-hidden')) {
        initFinanceCharts();
      }
    });
    finObs.observe(financeViewEl, { attributes: true, attributeFilter: ['class'] });
    // Init immédiate si la vue est déjà visible au chargement
    if (!financeViewEl.classList.contains('view-hidden')) initFinanceCharts();
  }

  /* ── Compteur financier formaté ─────────────────────────── */
  function countUpFinance(el, target, duration = 1000) {
    const start = performance.now();
    const fmt = new Intl.NumberFormat('fr-CA');
    const update = (ts) => {
      const p = Math.min((ts - start) / duration, 1);
      const ease = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt.format(Math.round(ease * target)) + ' $';
      if (p < 1) requestAnimationFrame(update);
    };
    requestAnimationFrame(update);
  }

  const finObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.fin, 10);
        if (!isNaN(target)) countUpFinance(el, target);
        finObserver.unobserve(el);
      }
    });
  }, { threshold: 0.3 });

  document.querySelectorAll('[data-fin]').forEach(el => finObserver.observe(el));

  /* ── Filtrage transactions ──────────────────────────────── */
  const txSearch = document.getElementById('tx-search');
  txSearch && txSearch.addEventListener('input', e => {
    const q = e.target.value.toLowerCase();
    document.querySelectorAll('.tx-row').forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    });
  });

  /* ── Export CSV ─────────────────────────────────────────── */
  document.getElementById('export-csv-btn')?.addEventListener('click', () => {
    const rows = [['Description','Catégorie','Date','Statut','Montant']];
    document.querySelectorAll('.tx-row').forEach(row => {
      const cells = row.querySelectorAll('td');
      rows.push([
        cells[0]?.querySelector('.tx-name')?.textContent?.trim()?.replace(/\s+/g,' ') || '',
        cells[1]?.textContent?.trim() || '',
        cells[2]?.textContent?.trim() || '',
        cells[3]?.textContent?.trim() || '',
        cells[4]?.textContent?.trim() || '',
      ]);
    });
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'transactions-flowstate.csv'; a.click();
    URL.revokeObjectURL(url);
    if (typeof showToastGlobal === 'function') showToastGlobal('Export CSV téléchargé');
  });

  /* ── Onglets période ─────────────────────────────────────── */
  document.querySelectorAll('.fin-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.fin-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      updateRevenueChart(tab.dataset.period);
    });
  });

  /* ── Graphiques Chart.js ────────────────────────────────── */
  let revenueChart = null;
  let donutChart   = null;
  let chartsInited = false;

  const DARK_GRID  = 'rgba(255,255,255,0.05)';
  const TEXT_MUTED = 'rgba(255,255,255,0.35)';

  const DATA = {
    mois: {
      labels: ['Sem 1','Sem 2','Sem 3','Sem 4'],
      revenus:  [10200, 14800, 12000, 11200],
      depenses: [4800,  5200,  4600,  4850],
      benefice: [5400,  9600,  7400,  6350],
    },
    trim: {
      labels: ['Janv.','Févr.','Mars','Avr.'],
      revenus:  [38000, 42000, 46500, 48200],
      depenses: [16000, 17400, 18900, 19450],
      benefice: [22000, 24600, 27600, 28750],
    },
    an: {
      labels: ['T1 25','T2 25','T3 25','T4 25','T1 26'],
      revenus:  [120000,135000,148000,162000,174700],
      depenses: [51000, 56000, 61000, 67000, 72650],
      benefice: [69000, 79000, 87000, 95000,102050],
    },
  };

  function getChartColors() {
    return {
      emerald: '#34d399',
      rose:    '#fb7185',
      cyan:    '#22d3ee',
      violet:  '#a78bfa',
      amber:   '#fbbf24',
      text:    'rgba(232,230,240,0.7)',
      grid:    'rgba(255,255,255,0.06)',
    };
  }

  function initFinanceCharts() {
    if (chartsInited) return;
    chartsInited = true;

    const c = getChartColors();

    // ── Graphique barres/lignes ──────────────────────────────
    const revenueCtx = document.getElementById('revenue-chart');
    if (revenueCtx) {
      const d = DATA.trim;
      revenueChart = new Chart(revenueCtx, {
        type: 'bar',
        data: {
          labels: d.labels,
          datasets: [
            {
              label: 'Revenus',
              data: d.revenus,
              backgroundColor: `rgba(52,211,153,0.2)`,
              borderColor: c.emerald,
              borderWidth: 1.5,
              borderRadius: 6,
              borderSkipped: false,
            },
            {
              label: 'Dépenses',
              data: d.depenses,
              backgroundColor: `rgba(251,113,133,0.15)`,
              borderColor: c.rose,
              borderWidth: 1.5,
              borderRadius: 6,
              borderSkipped: false,
            },
            {
              label: 'Bénéfice',
              type: 'line',
              data: d.benefice,
              borderColor: c.cyan,
              backgroundColor: `rgba(34,211,238,0.06)`,
              borderWidth: 2,
              pointBackgroundColor: c.cyan,
              pointRadius: 4,
              pointHoverRadius: 6,
              fill: true,
              tension: 0.4,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(17,16,26,0.92)',
              borderColor: 'rgba(255,255,255,0.1)',
              borderWidth: 1,
              titleColor: '#e8e6f0',
              bodyColor: '#9b97b4',
              padding: 12,
              callbacks: {
                label: ctx => ` ${ctx.dataset.label}: ${new Intl.NumberFormat('fr-CA').format(ctx.parsed.y)} $`,
              }
            },
          },
          scales: {
            x: {
              ticks:  { color: c.text, font: { size: 11 } },
              grid:   { color: c.grid },
              border: { color: 'transparent' },
            },
            y: {
              ticks: {
                color: c.text,
                font: { size: 11 },
                callback: v => (v >= 1000 ? (v/1000).toFixed(0)+'k $' : v+'$'),
              },
              grid:   { color: c.grid },
              border: { color: 'transparent' },
            },
          },
        },
      });
    }

    // ── Donut dépenses ───────────────────────────────────────
    const donutCtx = document.getElementById('donut-chart');
    if (donutCtx) {
      donutChart = new Chart(donutCtx, {
        type: 'doughnut',
        data: {
          labels: ['Marketing','Opérations','Salaires','Technologie'],
          datasets: [{
            data: [32, 24, 28, 16],
            backgroundColor: [
              'rgba(167,139,250,0.75)',
              'rgba(34,211,238,0.75)',
              'rgba(251,191,36,0.75)',
              'rgba(251,113,133,0.75)',
            ],
            borderColor: [
              'rgba(167,139,250,0.9)',
              'rgba(34,211,238,0.9)',
              'rgba(251,191,36,0.9)',
              'rgba(251,113,133,0.9)',
            ],
            borderWidth: 1.5,
            hoverOffset: 8,
          }],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          cutout: '72%',
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(17,16,26,0.92)',
              borderColor: 'rgba(255,255,255,0.1)',
              borderWidth: 1,
              titleColor: '#e8e6f0',
              bodyColor: '#9b97b4',
              padding: 10,
              callbacks: {
                label: ctx => ` ${ctx.label}: ${ctx.parsed}%`,
              }
            },
          },
        },
      });
    }
  }

  function updateRevenueChart(period) {
    if (!revenueChart) return;
    const d = DATA[period] || DATA.trim;
    revenueChart.data.labels = d.labels;
    revenueChart.data.datasets[0].data = d.revenus;
    revenueChart.data.datasets[1].data = d.depenses;
    revenueChart.data.datasets[2].data = d.benefice;
    revenueChart.update('active');
  }

  // Exposer showToast pour l'export CSV
  window.showToastGlobal = function(msg) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<svg class="toast-icon" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><path d="M4 10l4 4 8-8" stroke-linecap="round" stroke-linejoin="round"/></svg><span>${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.classList.add('removing'); setTimeout(() => toast.remove(), 280); }, 2800);
  };

})();
