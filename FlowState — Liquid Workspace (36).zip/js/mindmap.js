/* ═══════════════════════════════════════════════════════════════
   FlowState — Cartes Mentales IA (Premium)
   mindmap.js — Moteur complet : drag, zoom, pan, SVG edges,
                générateur IA simulé, templates, export, panneau
   ═══════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  /* ── État global ──────────────────────────────────────────── */
  let STATE = {
    nodes:    [],          // { id, label, sub, x, y, parentId, branch, level }
    edges:    [],          // { id, fromId, toId, branch }
    nextId:   1,
    selected: null,
    zoom:     1,
    panX:     0,
    panY:     0,
    isPanning:false,
    panStart: { x: 0, y: 0 },
    isDragging: false,
    dragNode: null,
    dragStart: { mx: 0, my: 0, nx: 0, ny: 0 },
    activeCard: null,      // id de la carte courante
    isPremium: true,       // désactivé pour dev — sera false en prod
    cards: []              // liste des cartes sauvegardées
  };

  /* ── Couleurs par branche ─────────────────────────────────── */
  const BRANCH_COLORS = [
    '#22d3ee', '#a78bfa', '#34d399',
    '#fb7185', '#fbbf24', '#818cf8'
  ];

  /* ── Templates IA prédéfinis ──────────────────────────────── */
  const TEMPLATES = {
    projet: {
      label: 'Gestion de Projet',
      children: [
        { label: 'Planification', children: ['Objectifs', 'Jalons', 'Ressources', 'Budget'] },
        { label: 'Exécution',     children: ['Sprints', 'Tâches', 'Assignations', 'Suivi'] },
        { label: 'Risques',       children: ['Identification', 'Mitigation', 'Contingence'] },
        { label: 'Livrables',     children: ['MVP', 'Tests', 'Documentation', 'Lancement'] },
        { label: 'Équipe',        children: ['Rôles', 'Communication', 'Réunions'] }
      ]
    },
    strategie: {
      label: 'Stratégie',
      children: [
        { label: 'Vision',     children: ['Mission', 'Valeurs', 'Objectifs 5 ans'] },
        { label: 'Marché',     children: ['Segments', 'Concurrents', 'Opportunités'] },
        { label: 'Offre',      children: ['Produit', 'Prix', 'Différenciation'] },
        { label: 'Croissance', children: ['Acquisition', 'Rétention', 'Expansion'] },
        { label: 'KPIs',       children: ['Revenus', 'Marge', 'NPS', 'CAC / LTV'] }
      ]
    },
    brainstorm: {
      label: 'Brainstorming',
      children: [
        { label: 'Problème',   children: ['Contexte', 'Contraintes', 'Parties prenantes'] },
        { label: 'Idées',      children: ['Option A', 'Option B', 'Option C', 'Idées folles'] },
        { label: 'Filtres',    children: ['Faisabilité', 'Impact', 'Effort', 'Priorité'] },
        { label: 'Actions',    children: ['Responsable', 'Délai', 'Suivi'] }
      ]
    },
    formation: {
      label: 'Formation / Apprentissage',
      children: [
        { label: 'Fondements',   children: ['Concepts clés', 'Vocabulaire', 'Prérequis'] },
        { label: 'Pratique',     children: ['Exercices', 'Projets', 'Cas concrets'] },
        { label: 'Ressources',   children: ['Livres', 'Vidéos', 'Outils', 'Mentors'] },
        { label: 'Progression',  children: ['Débutant', 'Intermédiaire', 'Expert'] }
      ]
    },
    swot: {
      label: 'Analyse SWOT',
      children: [
        { label: 'Forces',       children: ['Avantages', 'Compétences', 'Ressources'] },
        { label: 'Faiblesses',   children: ['Lacunes', 'Coûts', 'Risques internes'] },
        { label: 'Opportunités', children: ['Marché', 'Innovation', 'Partenariats'] },
        { label: 'Menaces',      children: ['Concurrents', 'Réglementation', 'Disruption'] }
      ]
    },
    vide: {
      label: 'Nouvelle carte',
      children: []
    }
  };

  /* ── Générateur IA simulé (prompt → arbre de noeuds) ─────── */
  function generateFromPrompt(prompt, depth, template) {
    const tpl = TEMPLATES[template] || TEMPLATES.brainstorm;
    const rootLabel = prompt.trim() || tpl.label;

    // Créer une structure adaptée au prompt
    const keywords = extractKeywords(prompt);
    const structure = buildStructure(rootLabel, keywords, depth, tpl);
    return structure;
  }

  function extractKeywords(prompt) {
    if (!prompt) return [];
    const stopWords = new Set(['de', 'du', 'des', 'le', 'la', 'les', 'un', 'une', 'et', 'ou', 'pour', 'avec', 'dans', 'sur', 'par', 'que', 'qui', 'est', 'sont', 'une', 'the', 'a', 'an', 'of', 'for', 'in', 'on', 'at', 'to', 'and', 'or']);
    return prompt.split(/[\s,;]+/)
      .map(w => w.toLowerCase().replace(/[^a-z0-9\u00C0-\u024F]/g, ''))
      .filter(w => w.length > 3 && !stopWords.has(w))
      .slice(0, 8);
  }

  function buildStructure(rootLabel, keywords, depth, tpl) {
    const nodes = [];
    const edges = [];
    let idCnt = 1;

    const rootId = idCnt++;
    nodes.push({ id: rootId, label: capitalizeFirst(rootLabel), sub: 'Carte principale', x: 0, y: 0, parentId: null, branch: -1, level: 0 });

    // Utiliser le template de base, enrichi avec les mots-clés
    const branches = tpl.children.length > 0 ? tpl.children : generateBranches(keywords);
    const bCount = Math.min(branches.length, 6);

    for (let b = 0; b < bCount; b++) {
      const branch = branches[b];
      const branchLabel = typeof branch === 'string' ? branch : branch.label;
      const pos = getRadialPos(b, bCount, 280);
      const bId = idCnt++;
      nodes.push({ id: bId, label: branchLabel, sub: '', x: pos.x, y: pos.y, parentId: rootId, branch: b, level: 1 });
      edges.push({ id: `e-${rootId}-${bId}`, fromId: rootId, toId: bId, branch: b });

      if (depth >= 2 && typeof branch === 'object' && branch.children) {
        const children = branch.children.slice(0, 4);
        children.forEach((ch, ci) => {
          const chLabel = typeof ch === 'string' ? ch : ch.label;
          const cpos = getChildPos(pos, b, bCount, ci, children.length, 160);
          const cId = idCnt++;
          nodes.push({ id: cId, label: chLabel, sub: '', x: cpos.x, y: cpos.y, parentId: bId, branch: b, level: 2 });
          edges.push({ id: `e-${bId}-${cId}`, fromId: bId, toId: cId, branch: b });

          if (depth >= 3 && typeof ch === 'object' && ch.children) {
            ch.children.slice(0, 3).forEach((sub, si) => {
              const spos = getChildPos(cpos, b, bCount, si, 3, 120);
              const sId = idCnt++;
              nodes.push({ id: sId, label: typeof sub === 'string' ? sub : sub.label, sub: '', x: spos.x, y: spos.y, parentId: cId, branch: b, level: 3 });
              edges.push({ id: `e-${cId}-${sId}`, fromId: cId, toId: sId, branch: b });
            });
          }
        });
      }
    }

    return { nodes, edges, nextId: idCnt };
  }

  function generateBranches(keywords) {
    const bases = ['Analyse', 'Stratégie', 'Actions', 'Ressources', 'Objectifs', 'Résultats'];
    if (keywords.length === 0) return bases.map(b => ({ label: b, children: [] }));
    return keywords.slice(0, 6).map((kw, i) => ({
      label: capitalizeFirst(kw),
      children: i < 3 ? [bases[i*2] || 'Détail 1', bases[i*2+1] || 'Détail 2'] : []
    }));
  }

  function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  function getRadialPos(index, total, radius) {
    const angle = (index / total) * Math.PI * 2 - Math.PI / 2;
    return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
  }

  function getChildPos(parentPos, branchIdx, branchTotal, childIdx, childTotal, radius) {
    const baseAngle = (branchIdx / branchTotal) * Math.PI * 2 - Math.PI / 2;
    const spread = Math.PI / 4;
    const angle = baseAngle + (childIdx - (childTotal - 1) / 2) * (spread / Math.max(childTotal - 1, 1));
    return {
      x: parentPos.x + Math.cos(angle) * radius,
      y: parentPos.y + Math.sin(angle) * radius
    };
  }

  /* ── Rendu ────────────────────────────────────────────────── */
  let canvas, svgLayer, zoomDisplay;

  function render() {
    if (!canvas || !svgLayer) return;
    renderEdges();
    renderNodes();
    updateZoomDisplay();
    updateMinimap();
  }

  function renderNodes() {
    // Supprimer les anciens noeuds
    canvas.querySelectorAll('.mm-node').forEach(el => el.remove());

    STATE.nodes.forEach(node => {
      const el = document.createElement('div');
      el.className = `mm-node${node.level === 0 ? ' root' : ''} branch-${node.branch} animating`;
      el.dataset.id = node.id;
      el.style.left = (node.x - (node.level === 0 ? 90 : 70)) + 'px';
      el.style.top  = (node.y - (node.level === 0 ? 28 : 22)) + 'px';

      // Accent couleur
      if (node.level > 0) {
        const accent = document.createElement('div');
        accent.className = 'mm-node-accent';
        accent.style.background = BRANCH_COLORS[node.branch % BRANCH_COLORS.length];
        el.appendChild(accent);
      }

      // Label
      const label = document.createElement('div');
      label.className = 'mm-node-label';
      label.textContent = node.label;
      label.contentEditable = 'true';
      label.spellcheck = false;
      el.appendChild(label);

      // Sous-titre
      if (node.sub) {
        const sub = document.createElement('div');
        sub.className = 'mm-node-sub';
        sub.textContent = node.sub;
        el.appendChild(sub);
      }

      // Actions sur le noeud
      const actions = document.createElement('div');
      actions.className = 'mm-node-actions';
      actions.innerHTML = `
        <button class="mm-node-action-btn add" data-action="add" data-id="${node.id}" title="Ajouter enfant">+</button>
        <button class="mm-node-action-btn" data-action="edit" data-id="${node.id}" title="Modifier">✏</button>
        ${node.level > 0 ? `<button class="mm-node-action-btn del" data-action="del" data-id="${node.id}" title="Supprimer">✕</button>` : ''}
      `;
      el.appendChild(actions);

      // Sélection
      if (STATE.selected === node.id) el.classList.add('selected');

      // Drag
      el.addEventListener('mousedown', onNodeMouseDown);
      el.addEventListener('touchstart', onNodeTouchStart, { passive: false });

      // Clic sélection (pas drag)
      el.addEventListener('click', (e) => {
        if (e.target.closest('[data-action]')) return;
        selectNode(node.id);
      });

      // Edition label en ligne
      label.addEventListener('blur', (e) => {
        const n = STATE.nodes.find(n => n.id === node.id);
        if (n) n.label = label.textContent.trim() || n.label;
      });
      label.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); label.blur(); } });

      canvas.appendChild(el);

      // Retirer classe animating après l'animation
      setTimeout(() => el.classList.remove('animating'), 400);
    });
  }

  function renderEdges() {
    svgLayer.innerHTML = '';
    // Defs pour les gradients
    const defs = document.createElementNS('http://www.w3.org/2000/svg', 'defs');
    svgLayer.appendChild(defs);

    STATE.edges.forEach(edge => {
      const fromNode = STATE.nodes.find(n => n.id === edge.fromId);
      const toNode   = STATE.nodes.find(n => n.id === edge.toId);
      if (!fromNode || !toNode) return;

      const color = fromNode.level === 0
        ? 'rgba(255,255,255,.25)'
        : BRANCH_COLORS[edge.branch % BRANCH_COLORS.length];

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('class', `mm-edge-path branch-${edge.branch}${fromNode.level === 0 ? ' root-edge' : ''}`);
      path.setAttribute('stroke', color);
      path.setAttribute('d', getBezierPath(fromNode, toNode));
      svgLayer.appendChild(path);
    });
  }

  function getBezierPath(from, to) {
    const fx = from.x, fy = from.y;
    const tx = to.x,   ty = to.y;
    const dx = (tx - fx) * 0.5;
    return `M ${fx},${fy} C ${fx + dx},${fy} ${tx - dx},${ty} ${tx},${ty}`;
  }

  function applyTransform() {
    if (!canvas || !svgLayer) return;
    const t = `translate(${STATE.panX}px,${STATE.panY}px) scale(${STATE.zoom})`;
    canvas.style.transform = t;
    svgLayer.style.transform = t;
    svgLayer.style.transformOrigin = '0 0';
    canvas.style.transformOrigin  = '0 0';
    updateZoomDisplay();
    updateMinimap();
  }

  function updateZoomDisplay() {
    if (zoomDisplay) zoomDisplay.textContent = Math.round(STATE.zoom * 100) + '%';
  }

  /* ── Drag noeud ───────────────────────────────────────────── */
  function onNodeMouseDown(e) {
    if (e.target.closest('[data-action]') || e.target.contentEditable === 'true') return;
    e.preventDefault(); e.stopPropagation();
    const nodeEl = e.currentTarget;
    const nodeId = parseInt(nodeEl.dataset.id);
    const node   = STATE.nodes.find(n => n.id === nodeId);
    if (!node) return;

    STATE.isDragging = true;
    STATE.dragNode   = nodeId;
    STATE.dragStart  = { mx: e.clientX, my: e.clientY, nx: node.x, ny: node.y };
    nodeEl.classList.add('dragging');

    const onMove = (ev) => {
      if (!STATE.isDragging) return;
      const dx = (ev.clientX - STATE.dragStart.mx) / STATE.zoom;
      const dy = (ev.clientY - STATE.dragStart.my) / STATE.zoom;
      node.x = STATE.dragStart.nx + dx;
      node.y = STATE.dragStart.ny + dy;
      nodeEl.style.left = (node.x - (node.level === 0 ? 90 : 70)) + 'px';
      nodeEl.style.top  = (node.y - (node.level === 0 ? 28 : 22)) + 'px';
      renderEdges();
    };
    const onUp = () => {
      STATE.isDragging = false;
      STATE.dragNode   = null;
      nodeEl.classList.remove('dragging');
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }

  function onNodeTouchStart(e) {
    if (e.target.closest('[data-action]')) return;
    e.preventDefault();
    const touch   = e.touches[0];
    const nodeEl  = e.currentTarget;
    const nodeId  = parseInt(nodeEl.dataset.id);
    const node    = STATE.nodes.find(n => n.id === nodeId);
    if (!node) return;

    STATE.dragStart = { mx: touch.clientX, my: touch.clientY, nx: node.x, ny: node.y };
    nodeEl.classList.add('dragging');

    const onMove = (ev) => {
      const t  = ev.touches[0];
      const dx = (t.clientX - STATE.dragStart.mx) / STATE.zoom;
      const dy = (t.clientY - STATE.dragStart.my) / STATE.zoom;
      node.x = STATE.dragStart.nx + dx;
      node.y = STATE.dragStart.ny + dy;
      nodeEl.style.left = (node.x - (node.level === 0 ? 90 : 70)) + 'px';
      nodeEl.style.top  = (node.y - (node.level === 0 ? 28 : 22)) + 'px';
      renderEdges();
    };
    const onUp = () => {
      nodeEl.classList.remove('dragging');
      document.removeEventListener('touchmove', onMove);
      document.removeEventListener('touchend', onUp);
    };
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onUp);
  }

  /* ── Pan canvas ───────────────────────────────────────────── */
  function initPan(workspaceEl) {
    workspaceEl.addEventListener('mousedown', (e) => {
      if (e.target.closest('.mm-node') || e.target.closest('.mm-toolbar') || e.target.closest('.mm-minimap') || e.target.closest('.mm-ia-indicator')) return;
      STATE.isPanning = true;
      STATE.panStart  = { x: e.clientX - STATE.panX, y: e.clientY - STATE.panY };
      canvas.classList.add('panning');
    });
    document.addEventListener('mousemove', (e) => {
      if (!STATE.isPanning) return;
      STATE.panX = e.clientX - STATE.panStart.x;
      STATE.panY = e.clientY - STATE.panStart.y;
      applyTransform();
    });
    document.addEventListener('mouseup', () => {
      if (!STATE.isPanning) return;
      STATE.isPanning = false;
      canvas.classList.remove('panning');
    });

    // Zoom molette
    workspaceEl.addEventListener('wheel', (e) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      const newZoom = Math.max(0.2, Math.min(3, STATE.zoom * delta));
      const rect = workspaceEl.getBoundingClientRect();
      const cx = e.clientX - rect.left;
      const cy = e.clientY - rect.top;
      STATE.panX = cx - (cx - STATE.panX) * (newZoom / STATE.zoom);
      STATE.panY = cy - (cy - STATE.panY) * (newZoom / STATE.zoom);
      STATE.zoom = newZoom;
      applyTransform();
    }, { passive: false });
  }

  /* ── Sélection noeud + panneau latéral ───────────────────── */
  function selectNode(id) {
    STATE.selected = id;
    canvas.querySelectorAll('.mm-node').forEach(el => {
      el.classList.toggle('selected', parseInt(el.dataset.id) === id);
    });
    const node = STATE.nodes.find(n => n.id === id);
    if (node) openSidePanel(node);
  }

  function openSidePanel(node) {
    const panel = document.getElementById('mm-side-panel');
    if (!panel) return;
    panel.classList.add('open');

    // Remplir le panneau
    const labelInput = document.getElementById('mm-panel-label');
    const subInput   = document.getElementById('mm-panel-sub');
    if (labelInput) labelInput.value = node.label;
    if (subInput)   subInput.value   = node.sub || '';
    labelInput && labelInput.addEventListener('input', () => { node.label = labelInput.value; renderNodes(); renderEdges(); });
    subInput   && subInput.addEventListener('input',   () => { node.sub   = subInput.value;   renderNodes(); });

    // Swatches de couleur
    panel.querySelectorAll('.mm-swatch').forEach(sw => {
      sw.addEventListener('click', () => {
        node.branch = parseInt(sw.dataset.branch);
        // Propager aux enfants
        propagateBranch(node.id, node.branch);
        render();
      });
    });
  }

  function propagateBranch(nodeId, branch) {
    STATE.nodes.filter(n => n.parentId === nodeId).forEach(child => {
      child.branch = branch;
      STATE.edges.filter(e => e.fromId === nodeId && e.toId === child.id).forEach(e => { e.branch = branch; });
      propagateBranch(child.id, branch);
    });
  }

  /* ── Actions sur noeuds ───────────────────────────────────── */
  function handleNodeAction(action, nodeId) {
    const node = STATE.nodes.find(n => n.id === nodeId);
    if (!node) return;

    if (action === 'add') {
      const newId = STATE.nextId++;
      const angle = Math.random() * Math.PI * 2;
      const dist  = 160 + Math.random() * 40;
      STATE.nodes.push({
        id: newId, label: 'Nouveau noeud', sub: '',
        x: node.x + Math.cos(angle) * dist,
        y: node.y + Math.sin(angle) * dist,
        parentId: nodeId,
        branch: node.branch < 0 ? 0 : node.branch,
        level: node.level + 1
      });
      STATE.edges.push({ id: `e-${nodeId}-${newId}`, fromId: nodeId, toId: newId, branch: node.branch < 0 ? 0 : node.branch });
      render();
      setTimeout(() => {
        const el = canvas.querySelector(`[data-id="${newId}"] .mm-node-label`);
        if (el) { el.focus(); document.execCommand('selectAll'); }
      }, 100);
    }

    if (action === 'del') {
      deleteNodeAndDescendants(nodeId);
      if (STATE.selected === nodeId) {
        STATE.selected = null;
        document.getElementById('mm-side-panel')?.classList.remove('open');
      }
      render();
    }

    if (action === 'edit') {
      selectNode(nodeId);
    }
  }

  function deleteNodeAndDescendants(nodeId) {
    const children = STATE.nodes.filter(n => n.parentId === nodeId).map(n => n.id);
    children.forEach(cid => deleteNodeAndDescendants(cid));
    STATE.nodes  = STATE.nodes.filter(n => n.id !== nodeId);
    STATE.edges  = STATE.edges.filter(e => e.fromId !== nodeId && e.toId !== nodeId);
  }

  /* ── Minimap ──────────────────────────────────────────────── */
  function updateMinimap() {
    const miniCanvas = document.getElementById('mm-minimap-canvas');
    if (!miniCanvas) return;
    const ctx = miniCanvas.getContext('2d');
    const W = miniCanvas.width, H = miniCanvas.height;
    ctx.clearRect(0, 0, W, H);

    if (STATE.nodes.length === 0) return;
    const xs = STATE.nodes.map(n => n.x);
    const ys = STATE.nodes.map(n => n.y);
    const minX = Math.min(...xs) - 100, maxX = Math.max(...xs) + 100;
    const minY = Math.min(...ys) - 60,  maxY = Math.max(...ys) + 60;
    const scaleX = W / (maxX - minX || 1);
    const scaleY = H / (maxY - minY || 1);
    const sc = Math.min(scaleX, scaleY) * 0.85;

    STATE.edges.forEach(e => {
      const fn = STATE.nodes.find(n => n.id === e.fromId);
      const tn = STATE.nodes.find(n => n.id === e.toId);
      if (!fn || !tn) return;
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255,255,255,.15)';
      ctx.lineWidth = 1;
      ctx.moveTo((fn.x - minX) * sc + (W - (maxX - minX) * sc) / 2,
                 (fn.y - minY) * sc + (H - (maxY - minY) * sc) / 2);
      ctx.lineTo((tn.x - minX) * sc + (W - (maxX - minX) * sc) / 2,
                 (tn.y - minY) * sc + (H - (maxY - minY) * sc) / 2);
      ctx.stroke();
    });

    STATE.nodes.forEach(n => {
      const cx = (n.x - minX) * sc + (W - (maxX - minX) * sc) / 2;
      const cy = (n.y - minY) * sc + (H - (maxY - minY) * sc) / 2;
      ctx.beginPath();
      ctx.arc(cx, cy, n.level === 0 ? 5 : 3, 0, Math.PI * 2);
      ctx.fillStyle = n.level === 0 ? '#818cf8' : (BRANCH_COLORS[n.branch % BRANCH_COLORS.length] || '#fff');
      ctx.fill();
    });
  }

  /* ── Export ───────────────────────────────────────────────── */
  function exportSVG() {
    const width  = 1600, height = 900;
    const padding = 80;

    let svgContent = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">`;
    svgContent += `<rect width="${width}" height="${height}" fill="#080b14"/>`;

    // Grille
    svgContent += `<defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,.03)" stroke-width="1"/></pattern></defs>`;
    svgContent += `<rect width="${width}" height="${height}" fill="url(#grid)"/>`;

    if (STATE.nodes.length === 0) {
      svgContent += `<text x="${width/2}" y="${height/2}" fill="rgba(255,255,255,.3)" text-anchor="middle" font-family="Arial" font-size="18">Carte vide</text>`;
      svgContent += '</svg>';
      downloadSVG(svgContent);
      return;
    }

    const xs = STATE.nodes.map(n => n.x);
    const ys = STATE.nodes.map(n => n.y);
    const minX = Math.min(...xs), maxX = Math.max(...xs);
    const minY = Math.min(...ys), maxY = Math.max(...ys);
    const contentW = maxX - minX || 1, contentH = maxY - minY || 1;
    const scale = Math.min((width - padding * 2) / contentW, (height - padding * 2) / contentH, 1.5);
    const offsetX = (width  - contentW * scale) / 2 - minX * scale;
    const offsetY = (height - contentH * scale) / 2 - minY * scale;

    const tx = (x) => x * scale + offsetX;
    const ty = (y) => y * scale + offsetY;

    // Edges
    STATE.edges.forEach(e => {
      const fn = STATE.nodes.find(n => n.id === e.fromId);
      const tn = STATE.nodes.find(n => n.id === e.toId);
      if (!fn || !tn) return;
      const color = fn.level === 0 ? 'rgba(255,255,255,.25)' : BRANCH_COLORS[e.branch % BRANCH_COLORS.length];
      const fx = tx(fn.x), fy = ty(fn.y), tx2 = tx(tn.x), ty2 = ty(tn.y);
      const dx = (tx2 - fx) * 0.5;
      svgContent += `<path d="M ${fx},${fy} C ${fx+dx},${fy} ${tx2-dx},${ty2} ${tx2},${ty2}" fill="none" stroke="${color}" stroke-width="2" opacity="0.7"/>`;
    });

    // Noeuds
    STATE.nodes.forEach(n => {
      const cx = tx(n.x), cy = ty(n.y);
      const rw = n.level === 0 ? 100 : 75, rh = n.level === 0 ? 32 : 24;
      const rx = cx - rw, ry = cy - rh;
      const bg = n.level === 0 ? '#6366f1' : 'rgba(18,22,42,.95)';
      const borderColor = n.level === 0 ? '#8b5cf6' : (BRANCH_COLORS[n.branch % BRANCH_COLORS.length] || 'rgba(255,255,255,.1)');
      svgContent += `<rect x="${rx}" y="${ry}" width="${rw*2}" height="${rh*2}" rx="12" fill="${bg}" stroke="${borderColor}" stroke-width="1.5"/>`;
      svgContent += `<text x="${cx}" y="${cy + 5}" fill="white" text-anchor="middle" font-family="Arial, sans-serif" font-size="${n.level === 0 ? 14 : 11}" font-weight="${n.level === 0 ? '900' : '700'}">${escapeXml(n.label)}</text>`;
      if (n.sub) {
        svgContent += `<text x="${cx}" y="${cy + 19}" fill="rgba(255,255,255,.4)" text-anchor="middle" font-family="Arial, sans-serif" font-size="9">${escapeXml(n.sub)}</text>`;
      }
    });

    // Watermark
    const card = STATE.cards.find(c => c.id === STATE.activeCard);
    const title = card ? card.name : 'FlowState';
    svgContent += `<text x="20" y="${height - 14}" fill="rgba(255,255,255,.2)" font-family="Arial" font-size="11">${escapeXml(title)} — FlowState Premium · ${new Date().toLocaleDateString('fr-CA')}</text>`;
    svgContent += '</svg>';

    downloadSVG(svgContent);
  }

  function escapeXml(str) {
    return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function downloadSVG(svgContent) {
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'carte-mentale-flowstate.svg';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    showToast('Carte exportée en SVG', 'success');
  }

  function exportJSON() {
    const card = STATE.cards.find(c => c.id === STATE.activeCard);
    const data = {
      version: '1.0',
      app: 'FlowState Cartes Mentales IA',
      exportedAt: new Date().toISOString(),
      carte: { name: card ? card.name : 'Sans titre', nodes: STATE.nodes, edges: STATE.edges }
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'carte-mentale.json';
    document.body.appendChild(a); a.click();
    document.body.removeChild(a); URL.revokeObjectURL(url);
    showToast('Carte exportée en JSON', 'success');
  }

  /* ── Centre la carte ──────────────────────────────────────── */
  function centerMap() {
    const ws = document.getElementById('mm-workspace');
    if (!ws || STATE.nodes.length === 0) return;
    const rect  = ws.getBoundingClientRect();
    STATE.panX  = rect.width  / 2;
    STATE.panY  = rect.height / 2;
    STATE.zoom  = 1;
    applyTransform();
  }

  /* ── Cartes sauvegardées ──────────────────────────────────── */
  const DEFAULT_CARDS = [
    { id: 1, name: 'Feuille de route Q2', template: 'projet',    color: '#818cf8', nodes: null, edges: null },
    { id: 2, name: 'Stratégie marketing', template: 'strategie', color: '#22d3ee', nodes: null, edges: null },
    { id: 3, name: 'Brainstorm produit',  template: 'brainstorm', color: '#34d399', nodes: null, edges: null }
  ];

  function initCards() {
    STATE.cards = DEFAULT_CARDS.map(c => ({ ...c }));
    renderCardChips();
    loadCard(STATE.cards[0]);
  }

  function renderCardChips() {
    const bar = document.getElementById('mm-cards-bar');
    if (!bar) return;
    bar.innerHTML = '<div class="mm-cards-label">Mes cartes</div>';

    STATE.cards.forEach(card => {
      const chip = document.createElement('div');
      chip.className = `mm-card-chip${card.id === STATE.activeCard ? ' active' : ''}`;
      chip.dataset.cardId = card.id;
      chip.innerHTML = `<div class="mm-card-chip-dot" style="background:${card.color}"></div>${card.name}`;
      chip.addEventListener('click', () => loadCard(card));
      bar.appendChild(chip);
    });

    const newChip = document.createElement('div');
    newChip.className = 'mm-card-chip mm-card-chip-new';
    newChip.innerHTML = '+ Nouvelle carte';
    newChip.addEventListener('click', openNewCardModal);
    bar.appendChild(newChip);
  }

  function loadCard(card) {
    // Sauvegarder l'état de la carte précédente
    if (STATE.activeCard) {
      const prev = STATE.cards.find(c => c.id === STATE.activeCard);
      if (prev) { prev.nodes = STATE.nodes; prev.edges = STATE.edges; prev.nextId = STATE.nextId; }
    }

    STATE.activeCard = card.id;

    if (card.nodes) {
      STATE.nodes  = card.nodes;
      STATE.edges  = card.edges;
      STATE.nextId = card.nextId || (Math.max(...card.nodes.map(n => n.id)) + 1);
    } else {
      // Générer la carte par défaut du template
      const generated = generateFromPrompt('', 2, card.template || 'brainstorm');
      STATE.nodes  = generated.nodes.map(n => ({
        ...n,
        label: n.id === generated.nodes[0].id ? card.name : n.label
      }));
      STATE.edges  = generated.edges;
      STATE.nextId = generated.nextId;
      card.nodes   = STATE.nodes;
      card.edges   = STATE.edges;
    }

    STATE.selected = null;
    document.getElementById('mm-side-panel')?.classList.remove('open');
    renderCardChips();
    centerMap();
    render();
  }

  /* ── Modals ───────────────────────────────────────────────── */
  function openNewCardModal() {
    const overlay = document.getElementById('mm-new-modal-overlay');
    if (overlay) overlay.classList.add('open');
    document.getElementById('mm-new-card-name')?.focus();
  }

  function closeNewCardModal() {
    document.getElementById('mm-new-modal-overlay')?.classList.remove('open');
  }

  function openIAModal() {
    const overlay = document.getElementById('mm-ia-modal-overlay');
    if (overlay) overlay.classList.add('open');
    document.getElementById('mm-ia-prompt')?.focus();
  }

  function closeIAModal() {
    document.getElementById('mm-ia-modal-overlay')?.classList.remove('open');
  }

  /* ── Génération IA avec animation ────────────────────────── */
  function triggerIAGenerate() {
    const prompt    = document.getElementById('mm-ia-prompt')?.value.trim() || '';
    const depth     = parseInt(document.getElementById('mm-ia-depth')?.value || '2');
    const template  = document.querySelector('.mm-template-card.selected')?.dataset.template || 'brainstorm';

    closeIAModal();

    const indicator = document.getElementById('mm-ia-indicator');
    if (indicator) indicator.classList.add('visible');

    setTimeout(() => {
      const generated = generateFromPrompt(prompt, depth, template);

      // Mettre à jour la carte courante
      STATE.nodes  = generated.nodes;
      STATE.edges  = generated.edges;
      STATE.nextId = generated.nextId;

      // Mettre à jour le label racine si prompt fourni
      if (prompt && STATE.nodes[0]) STATE.nodes[0].label = prompt.charAt(0).toUpperCase() + prompt.slice(1);

      const card = STATE.cards.find(c => c.id === STATE.activeCard);
      if (card) {
        if (prompt) card.name = STATE.nodes[0].label;
        card.nodes  = STATE.nodes;
        card.edges  = STATE.edges;
        card.nextId = STATE.nextId;
      }

      if (indicator) indicator.classList.remove('visible');
      centerMap();
      render();
      renderCardChips();
      showToast('Carte générée par ARIA', 'success');
    }, 1800 + Math.random() * 800);
  }

  /* ── Toast ────────────────────────────────────────────────── */
  function showToast(message, type) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed;bottom:5.5rem;left:50%;transform:translateX(-50%);
      padding:.55rem 1.2rem;border-radius:10px;z-index:9999;
      font-size:.78rem;font-weight:700;color:#fff;
      backdrop-filter:blur(12px);pointer-events:none;
      animation:slideUp .3s ease forwards;
    `;
    toast.style.background = type === 'success' ? 'rgba(52,211,153,.9)' : 'rgba(251,113,133,.9)';
    toast.textContent = message;

    const style = document.createElement('style');
    style.textContent = '@keyframes slideUp { from { opacity:0; transform:translateX(-50%) translateY(12px); } to { opacity:1; transform:translateX(-50%) translateY(0); } }';
    document.head.appendChild(style);
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2800);
  }

  /* ════════════════════════════════════════════════════════════
     INIT PRINCIPAL
  ════════════════════════════════════════════════════════════ */
  function init() {
    const viewMindmap = document.getElementById('view-mindmap');
    if (!viewMindmap) return;

    const observer = new MutationObserver(() => {
      if (!viewMindmap.classList.contains('view-hidden')) {
        initMindmapUI();
      }
    });
    observer.observe(viewMindmap, { attributes: true, attributeFilter: ['class'] });
    if (!viewMindmap.classList.contains('view-hidden')) initMindmapUI();

    // Clic sur nav mindmap
    const navBtn = document.querySelector('[data-view="mindmap"]');
    if (navBtn) navBtn.addEventListener('click', () => setTimeout(initMindmapUI, 100));
  }

  let _initialized = false;
  function initMindmapUI() {
    if (_initialized) return;
    _initialized = true;

    canvas    = document.getElementById('mm-canvas');
    svgLayer  = document.getElementById('mm-svg-layer');
    zoomDisplay = document.getElementById('mm-zoom-display');

    if (!canvas || !svgLayer) return;

    const workspace = document.getElementById('mm-workspace');
    if (workspace) initPan(workspace);

    // Gate premium (désactivé pour dev)
    if (!STATE.isPremium) {
      document.getElementById('mm-premium-gate')?.classList.add('visible');
    }
    document.getElementById('mm-gate-bypass')?.addEventListener('click', () => {
      STATE.isPremium = true;
      document.getElementById('mm-premium-gate')?.classList.remove('visible');
      initCards();
    });
    document.getElementById('mm-gate-btn')?.addEventListener('click', () => {
      STATE.isPremium = true;
      document.getElementById('mm-premium-gate')?.classList.remove('visible');
      initCards();
    });

    if (STATE.isPremium) initCards();

    // Délégation d'actions sur noeuds
    canvas.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      handleNodeAction(btn.dataset.action, parseInt(btn.dataset.id));
    });

    // Désélectionner en cliquant sur le fond
    document.getElementById('mm-workspace')?.addEventListener('click', (e) => {
      if (!e.target.closest('.mm-node') && !e.target.closest('.mm-side-panel')) {
        STATE.selected = null;
        canvas.querySelectorAll('.mm-node').forEach(el => el.classList.remove('selected'));
        document.getElementById('mm-side-panel')?.classList.remove('open');
      }
    });

    // Panneau latéral
    document.getElementById('mm-side-close')?.addEventListener('click', () => {
      document.getElementById('mm-side-panel')?.classList.remove('open');
      STATE.selected = null;
      canvas.querySelectorAll('.mm-node').forEach(el => el.classList.remove('selected'));
    });
    document.getElementById('mm-panel-label')?.addEventListener('input', (e) => {
      const node = STATE.nodes.find(n => n.id === STATE.selected);
      if (node) { node.label = e.target.value; renderNodes(); renderEdges(); }
    });
    document.getElementById('mm-panel-sub')?.addEventListener('input', (e) => {
      const node = STATE.nodes.find(n => n.id === STATE.selected);
      if (node) { node.sub = e.target.value; renderNodes(); }
    });
    document.querySelectorAll('.mm-swatch').forEach(sw => {
      sw.addEventListener('click', () => {
        const node = STATE.nodes.find(n => n.id === STATE.selected);
        if (!node) return;
        const b = parseInt(sw.dataset.branch);
        node.branch = b;
        STATE.edges.filter(e => e.toId === node.id).forEach(e => { e.branch = b; });
        propagateBranch(node.id, b);
        render();
      });
    });

    // Barre d'outils canvas
    document.getElementById('mm-tool-center')?.addEventListener('click', centerMap);
    document.getElementById('mm-tool-zoom-in')?.addEventListener('click', () => {
      STATE.zoom = Math.min(3, STATE.zoom * 1.2); applyTransform();
    });
    document.getElementById('mm-tool-zoom-out')?.addEventListener('click', () => {
      STATE.zoom = Math.max(0.2, STATE.zoom * 0.8); applyTransform();
    });
    document.getElementById('mm-tool-export-svg')?.addEventListener('click', exportSVG);
    document.getElementById('mm-tool-export-json')?.addEventListener('click', exportJSON);
    document.getElementById('mm-tool-add-node')?.addEventListener('click', () => {
      if (!STATE.nodes[0]) return;
      handleNodeAction('add', STATE.nodes[0].id);
    });

    // Boutons hero
    document.getElementById('mm-btn-new')?.addEventListener('click', openNewCardModal);
    document.getElementById('mm-btn-ia')?.addEventListener('click', openIAModal);
    document.getElementById('mm-btn-export')?.addEventListener('click', exportSVG);

    // Modal nouvelle carte
    document.getElementById('mm-new-modal-close')?.addEventListener('click', closeNewCardModal);
    document.getElementById('mm-new-cancel-btn')?.addEventListener('click', closeNewCardModal);
    document.getElementById('mm-new-create-btn')?.addEventListener('click', () => {
      const nameInput = document.getElementById('mm-new-card-name');
      const name = nameInput?.value.trim() || 'Nouvelle carte';
      const template = document.querySelector('#mm-new-modal-overlay .mm-template-card.selected')?.dataset.template || 'brainstorm';
      const colors = ['#818cf8','#22d3ee','#34d399','#fb7185','#fbbf24','#a78bfa'];
      const color = colors[STATE.cards.length % colors.length];
      const newCard = { id: Date.now(), name, template, color, nodes: null, edges: null };
      STATE.cards.push(newCard);
      closeNewCardModal();
      loadCard(newCard);
    });

    // Modal IA
    document.getElementById('mm-ia-modal-close')?.addEventListener('click', closeIAModal);
    document.getElementById('mm-ia-cancel-btn')?.addEventListener('click', closeIAModal);
    document.getElementById('mm-ia-generate-btn')?.addEventListener('click', triggerIAGenerate);

    // Templates dans le modal IA
    document.querySelectorAll('#mm-ia-modal-overlay .mm-template-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('#mm-ia-modal-overlay .mm-template-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    // Templates dans le modal nouvelle carte
    document.querySelectorAll('#mm-new-modal-overlay .mm-template-card').forEach(card => {
      card.addEventListener('click', () => {
        document.querySelectorAll('#mm-new-modal-overlay .mm-template-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
      });
    });

    // Profondeur slider
    const depthSlider = document.getElementById('mm-ia-depth');
    const depthVal    = document.getElementById('mm-ia-depth-val');
    depthSlider?.addEventListener('input', () => {
      if (depthVal) depthVal.textContent = depthSlider.value;
    });

    // Fermer modals sur clic backdrop
    ['mm-new-modal-overlay', 'mm-ia-modal-overlay'].forEach(id => {
      document.getElementById(id)?.addEventListener('click', (e) => {
        if (e.target.id === id) document.getElementById(id).classList.remove('open');
      });
    });

    // Raccourcis clavier
    document.addEventListener('keydown', (e) => {
      if (!document.getElementById('view-mindmap') || document.getElementById('view-mindmap').classList.contains('view-hidden')) return;
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.contentEditable === 'true') return;
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (STATE.selected) handleNodeAction('del', STATE.selected);
      }
      if (e.key === 'Tab') { e.preventDefault(); if (STATE.selected) handleNodeAction('add', STATE.selected); }
      if (e.key === 'Escape') { STATE.selected = null; canvas.querySelectorAll('.mm-node').forEach(el => el.classList.remove('selected')); document.getElementById('mm-side-panel')?.classList.remove('open'); }
    });

    centerMap();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
