/**
 * FlowState — Outils Universels
 * Import / Export / Télécharger / Imprimer / Rapport Global PDF/IMG/CSV
 */

(function () {
  'use strict';

  /* ─────────────────────────────────────────────
     DONNÉES AGRÉGÉES PAR SECTEUR
  ───────────────────────────────────────────── */

  const DATA = {
    dashboard: {
      label: 'Tableau de bord',
      icon: '📊',
      color: '#818cf8',
      kpis: [
        { k: 'Score Flow', v: '87 / 100', cls: 'info' },
        { k: 'Flows actifs', v: '14' },
        { k: 'Heures en flow', v: '6h' },
        { k: 'Tâches accomplies', v: '28' },
        { k: 'Énergie', v: '92 %', cls: 'positive' }
      ]
    },
    projets: {
      label: 'Projets',
      icon: '📁',
      color: '#a78bfa',
      kpis: [
        { k: 'Projets actifs', v: '3' },
        { k: 'Tâches cette semaine', v: '12' },
        { k: 'Tâches terminées', v: '28', cls: 'positive' },
        { k: 'Sprint en cours', v: 'Sprint 14' },
        { k: 'Vélocité', v: '38 pts / sprint', cls: 'info' }
      ]
    },
    equipes: {
      label: 'Équipes',
      icon: '👥',
      color: '#22d3ee',
      kpis: [
        { k: 'Membres actifs', v: '5' },
        { k: 'Tâches assignées', v: '18' },
        { k: 'Tâches en cours', v: '7', cls: 'info' },
        { k: 'Taux de complétion', v: '72 %', cls: 'positive' },
        { k: 'Réunions/semaine', v: '4' }
      ]
    },
    calendrier: {
      label: 'Calendrier',
      icon: '📅',
      color: '#34d399',
      kpis: [
        { k: 'Événements avril', v: '19' },
        { k: 'Calendriers actifs', v: '4' },
        { k: 'Prochaine réunion', v: 'Standup 09:00', cls: 'info' },
        { k: 'Heures planifiées', v: '38h' },
        { k: 'Invitations en attente', v: '2', cls: 'negative' }
      ]
    },
    courriel: {
      label: 'Courriel',
      icon: '✉️',
      color: '#fb7185',
      kpis: [
        { k: 'Messages reçus', v: '8' },
        { k: 'Non lus', v: '3', cls: 'negative' },
        { k: 'En attente de réponse', v: '2', cls: 'negative' },
        { k: 'Contacts', v: '6' },
        { k: 'Notes créées', v: '5', cls: 'positive' }
      ]
    },
    finance: {
      label: 'Finances',
      icon: '💰',
      color: '#34d399',
      kpis: [
        { k: 'Solde total', v: '84 320 $', cls: 'positive' },
        { k: 'Revenus avril', v: '12 500 $', cls: 'positive' },
        { k: 'Dépenses avril', v: '4 320 $', cls: 'negative' },
        { k: 'Flux net', v: '+8 180 $', cls: 'positive' },
        { k: 'Budget restant', v: '68 %', cls: 'info' }
      ]
    },
    agent: {
      label: 'Agent IA',
      icon: '🤖',
      color: '#818cf8',
      kpis: [
        { k: 'Commandes vocales', v: '24' },
        { k: 'Tâches exécutées', v: '18', cls: 'positive' },
        { k: 'Secteurs accessibles', v: '7' },
        { k: 'Précision STT', v: '97 %', cls: 'positive' },
        { k: 'Temps de réponse', v: '< 1.2s', cls: 'info' }
      ]
    }
  };

  /* ─────────────────────────────────────────────
     TOAST GLOBAL
  ───────────────────────────────────────────── */

  function showToast(msg, icon) {
    let toast = document.getElementById('outils-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'outils-toast';
      toast.className = 'outils-toast';
      toast.innerHTML = '<span class="outils-toast-icon"></span><span class="outils-toast-msg"></span>';
      document.body.appendChild(toast);
    }
    toast.querySelector('.outils-toast-icon').textContent = icon || '✅';
    toast.querySelector('.outils-toast-msg').textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), 2800);
  }

  /* ─────────────────────────────────────────────
     EXPORT CSV
  ───────────────────────────────────────────── */

  function exportCSV(sectorId) {
    const sector = DATA[sectorId];
    if (!sector) return;
    const rows = [['Indicateur', 'Valeur', 'Secteur', 'Date']];
    sector.kpis.forEach(k => rows.push([k.k, k.v, sector.label, new Date().toLocaleDateString('fr-CA')]));
    const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    downloadText(csv, 'flowstate-' + sectorId + '-' + datestamp() + '.csv', 'text/csv');
    showToast('Export CSV téléchargé — ' + sector.label, '📊');
  }

  function exportAllCSV() {
    const rows = [['Secteur', 'Indicateur', 'Valeur', 'Date']];
    Object.values(DATA).forEach(sector => {
      sector.kpis.forEach(k => rows.push([sector.label, k.k, k.v, new Date().toLocaleDateString('fr-CA')]));
    });
    const csv = rows.map(r => r.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    downloadText(csv, 'flowstate-rapport-complet-' + datestamp() + '.csv', 'text/csv');
    showToast('Export CSV complet téléchargé', '📊');
  }

  /* ─────────────────────────────────────────────
     EXPORT JSON
  ───────────────────────────────────────────── */

  function exportJSON(sectorId) {
    const sector = DATA[sectorId];
    if (!sector) return;
    const data = {
      application: 'FlowState',
      secteur: sector.label,
      date: new Date().toISOString(),
      indicateurs: sector.kpis.reduce((acc, k) => { acc[k.k] = k.v; return acc; }, {})
    };
    downloadText(JSON.stringify(data, null, 2), 'flowstate-' + sectorId + '-' + datestamp() + '.json', 'application/json');
    showToast('Export JSON téléchargé — ' + sector.label, '📄');
  }

  /* ─────────────────────────────────────────────
     IMPORT FICHIERS
  ───────────────────────────────────────────── */

  function openImportModal(sectorId) {
    const modal = document.getElementById('import-modal-overlay');
    if (!modal) return;
    const titleEl = modal.querySelector('#import-modal-title');
    if (titleEl) {
      const s = DATA[sectorId] || { label: 'Document', icon: '📁' };
      titleEl.textContent = 'Importer — ' + s.label;
    }
    modal.dataset.sector = sectorId || '';
    modal.classList.add('open');
    resetDropzone();
  }

  function closeImportModal() {
    const modal = document.getElementById('import-modal-overlay');
    if (modal) modal.classList.remove('open');
    resetDropzone();
  }

  function resetDropzone() {
    const list = document.getElementById('upload-files-list');
    if (list) list.innerHTML = '';
    window._importedFiles = [];
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' o';
    if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' Ko';
    return (bytes / 1048576).toFixed(1) + ' Mo';
  }

  function fileIcon(name) {
    const ext = (name.split('.').pop() || '').toLowerCase();
    const map = { pdf: '📕', doc: '📘', docx: '📘', xls: '📗', xlsx: '📗', csv: '📊', ppt: '📙', pptx: '📙', jpg: '🖼️', jpeg: '🖼️', png: '🖼️', gif: '🖼️', zip: '🗜️', txt: '📄', json: '📋' };
    return map[ext] || '📎';
  }

  function handleFiles(files) {
    if (!files || !files.length) return;
    window._importedFiles = window._importedFiles || [];
    const list = document.getElementById('upload-files-list');
    Array.from(files).forEach(file => {
      window._importedFiles.push(file);
      const item = document.createElement('div');
      item.className = 'upload-file-item';
      item.innerHTML = `
        <span class="upload-file-icon">${fileIcon(file.name)}</span>
        <span class="upload-file-name">${file.name}</span>
        <span class="upload-file-size">${formatSize(file.size)}</span>
        <button class="upload-file-remove" title="Retirer">✕</button>
      `;
      item.querySelector('.upload-file-remove').addEventListener('click', () => item.remove());
      if (list) list.appendChild(item);
    });
  }

  function confirmImport() {
    const files = window._importedFiles || [];
    const count = document.querySelectorAll('.upload-file-item').length;
    if (count === 0) { showToast('Aucun fichier sélectionné', '⚠️'); return; }
    closeImportModal();
    showToast(count + ' fichier(s) importé(s) avec succès', '📥');
  }

  /* ─────────────────────────────────────────────
     TÉLÉCHARGER VUE (screenshot simulé)
  ───────────────────────────────────────────── */

  function downloadView(sectorId) {
    // Générer un SVG représentant un résumé de la vue
    const sector = DATA[sectorId] || DATA.dashboard;
    const svgContent = generateViewSVG(sector, sectorId);
    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'flowstate-' + sectorId + '-' + datestamp() + '.svg';
    a.click();
    URL.revokeObjectURL(url);
    showToast('Vue téléchargée — ' + sector.label, '⬇️');
  }

  function generateViewSVG(sector, sectorId) {
    const now = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' });
    const rows = sector.kpis.map((k, i) => {
      const y = 180 + i * 36;
      const cls = k.cls === 'positive' ? '#34d399' : k.cls === 'negative' ? '#fb7185' : k.cls === 'info' ? '#22d3ee' : '#e2e8f0';
      return `
        <rect x="32" y="${y - 14}" width="636" height="30" rx="6" fill="${i % 2 === 0 ? 'rgba(255,255,255,0.03)' : 'none'}"/>
        <text x="48" y="${y + 6}" font-family="system-ui,sans-serif" font-size="13" fill="rgba(255,255,255,0.55)">${k.k}</text>
        <text x="652" y="${y + 6}" text-anchor="end" font-family="system-ui,sans-serif" font-size="13" font-weight="bold" fill="${cls}">${k.v}</text>
      `;
    }).join('');

    const totalH = 200 + sector.kpis.length * 36 + 60;
    return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="700" height="${totalH}" viewBox="0 0 700 ${totalH}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="700" y2="${totalH}" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#0f0f1a"/>
      <stop offset="100%" stop-color="#0a0a14"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="${sector.color}"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="700" height="${totalH}" rx="16" fill="url(#bg)"/>
  <rect x="0" y="0" width="700" height="3" rx="0" fill="url(#accent)"/>
  <!-- Header -->
  <text x="48" y="52" font-family="system-ui,sans-serif" font-size="11" fill="rgba(255,255,255,0.3)" letter-spacing="2">FLOWSTATE</text>
  <text x="48" y="85" font-family="system-ui,sans-serif" font-size="26" font-weight="900" fill="#ffffff">${sector.label}</text>
  <text x="48" y="110" font-family="system-ui,sans-serif" font-size="12" fill="rgba(255,255,255,0.4)">Généré le ${now}</text>
  <!-- Separator -->
  <rect x="32" y="130" width="636" height="1" fill="rgba(255,255,255,0.08)"/>
  <!-- KPIs -->
  ${rows}
  <!-- Footer -->
  <rect x="32" y="${totalH - 50}" width="636" height="1" fill="rgba(255,255,255,0.06)"/>
  <text x="48" y="${totalH - 25}" font-family="system-ui,sans-serif" font-size="11" fill="rgba(255,255,255,0.2)">FlowState Liquid Workspace · ${now}</text>
</svg>`;
  }

  /* ─────────────────────────────────────────────
     IMPRIMER
  ───────────────────────────────────────────── */

  function printView(sectorId) {
    const sector = DATA[sectorId] || DATA.dashboard;
    const now = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' });
    const rows = sector.kpis.map(k => {
      const color = k.cls === 'positive' ? '#059669' : k.cls === 'negative' ? '#dc2626' : k.cls === 'info' ? '#0284c7' : '#1e293b';
      return `<tr><td style="padding:8px 12px;border-bottom:1px solid #e2e8f0;color:#475569;">${k.k}</td><td style="padding:8px 12px;border-bottom:1px solid #e2e8f0;font-weight:700;color:${color};text-align:right;">${k.v}</td></tr>`;
    }).join('');
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>FlowState — ${sector.label}</title>
    <style>body{font-family:system-ui,sans-serif;margin:40px;color:#1e293b;}h1{font-size:28px;font-weight:900;color:#0f172a;margin:0 0 4px;}p{color:#64748b;font-size:13px;margin:0 0 24px;}table{width:100%;border-collapse:collapse;}th{padding:10px 12px;background:#f8fafc;font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;text-align:left;border-bottom:2px solid #e2e8f0;}footer{margin-top:32px;font-size:11px;color:#94a3b8;border-top:1px solid #e2e8f0;padding-top:12px;}</style>
    </head><body>
    <h1>${sector.icon} ${sector.label}</h1>
    <p>FlowState Liquid Workspace · ${now}</p>
    <table><thead><tr><th>Indicateur</th><th style="text-align:right;">Valeur</th></tr></thead><tbody>${rows}</tbody></table>
    <footer>Rapport généré automatiquement par FlowState · ${now}</footer>
    </body></html>`;
    const w = window.open('', '_blank', 'width=800,height=600');
    if (!w) { showToast('Autoriser les popups pour imprimer', '⚠️'); return; }
    w.document.write(html);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 400);
    showToast('Impression lancée — ' + sector.label, '🖨️');
  }

  /* ─────────────────────────────────────────────
     RAPPORT GLOBAL
  ───────────────────────────────────────────── */

  let rapportSections = Object.keys(DATA);
  let rapportFormat = 'pdf';

  function openRapportModal() {
    const modal = document.getElementById('rapport-overlay');
    if (modal) modal.classList.add('open');
    renderRapportPreview();
  }

  function closeRapportModal() {
    const modal = document.getElementById('rapport-overlay');
    if (modal) modal.classList.remove('open');
    const progress = document.getElementById('rapport-progress');
    if (progress) progress.classList.remove('visible');
  }

  function renderRapportPreview() {
    const preview = document.getElementById('rapport-preview-content');
    if (!preview) return;
    const now = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' });
    const selected = rapportSections.filter(id => DATA[id]);
    const totalKpis = selected.reduce((acc, id) => acc + DATA[id].kpis.length, 0);
    preview.innerHTML = `
      <div class="rapport-preview-title">Rapport FlowState — Synthèse Globale</div>
      <div class="rapport-preview-meta">Généré le ${now} · ${selected.length} sections · ${totalKpis} indicateurs</div>
      ${selected.map(id => `<div class="rapport-preview-row"><span class="rapport-preview-key">${DATA[id].icon} ${DATA[id].label}</span><span class="rapport-preview-val">${DATA[id].kpis.length} KPIs</span></div>`).join('')}
    `;
  }

  function generateRapport() {
    const selected = rapportSections.filter(id => DATA[id]);
    if (selected.length === 0) { showToast('Sélectionnez au moins une section', '⚠️'); return; }

    const btn = document.getElementById('rapport-generate-btn');
    if (btn) btn.disabled = true;

    const progress = document.getElementById('rapport-progress');
    const progressBar = document.getElementById('rapport-progress-bar');
    const progressLabel = document.getElementById('rapport-progress-label');
    if (progress) progress.classList.add('visible');

    let pct = 0;
    const steps = ['Collecte des données...', 'Agrégation des KPIs...', 'Mise en forme...', 'Génération du fichier...', 'Finalisation...'];
    let step = 0;

    const interval = setInterval(() => {
      pct += 18 + Math.random() * 12;
      if (pct > 95) pct = 95;
      if (progressBar) progressBar.style.width = pct + '%';
      if (progressLabel && steps[step]) { progressLabel.textContent = steps[step]; step++; }
    }, 300);

    setTimeout(() => {
      clearInterval(interval);
      if (progressBar) progressBar.style.width = '100%';
      if (progressLabel) progressLabel.textContent = 'Terminé !';

      setTimeout(() => {
        if (rapportFormat === 'csv') {
          exportAllCSV();
        } else if (rapportFormat === 'json') {
          exportRapportJSON(selected);
        } else {
          // PDF / IMG / HTML → générer SVG complet
          exportRapportSVG(selected, rapportFormat);
        }
        if (btn) btn.disabled = false;
        closeRapportModal();
      }, 500);
    }, 1800);
  }

  function exportRapportJSON(selected) {
    const data = {
      application: 'FlowState Liquid Workspace',
      titre: 'Rapport Global',
      date: new Date().toISOString(),
      sections: selected.map(id => ({
        secteur: DATA[id].label,
        indicateurs: DATA[id].kpis.reduce((acc, k) => { acc[k.k] = k.v; return acc; }, {})
      }))
    };
    downloadText(JSON.stringify(data, null, 2), 'flowstate-rapport-' + datestamp() + '.json', 'application/json');
    showToast('Rapport JSON téléchargé', '📋');
  }

  function exportRapportSVG(selected, format) {
    const now = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' });
    const COLS = 2;
    const CARD_W = 480;
    const CARD_H_BASE = 60 + 5 * 34;
    const PAD = 24;
    const cols = selected.length === 1 ? 1 : COLS;
    const rows = Math.ceil(selected.length / cols);
    const totalW = cols * (CARD_W + PAD) + PAD * 2;
    const totalH = 120 + rows * (CARD_H_BASE + PAD) + PAD + 60;

    let cards = '';
    selected.forEach((id, i) => {
      const sector = DATA[id];
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = PAD + col * (CARD_W + PAD);
      const y = 110 + row * (CARD_H_BASE + PAD);
      const kpiRows = sector.kpis.map((k, ki) => {
        const ky = y + 50 + ki * 32;
        const vc = k.cls === 'positive' ? '#34d399' : k.cls === 'negative' ? '#fb7185' : k.cls === 'info' ? '#22d3ee' : '#e2e8f0';
        return `
          <rect x="${x + 12}" y="${ky - 14}" width="${CARD_W - 24}" height="26" rx="5" fill="${ki % 2 === 0 ? 'rgba(255,255,255,0.025)' : 'none'}"/>
          <text x="${x + 24}" y="${ky + 4}" font-family="system-ui,sans-serif" font-size="12" fill="rgba(255,255,255,0.5)">${k.k}</text>
          <text x="${x + CARD_W - 16}" y="${ky + 4}" text-anchor="end" font-family="system-ui,sans-serif" font-size="12" font-weight="700" fill="${vc}">${k.v}</text>
        `;
      }).join('');
      cards += `
        <rect x="${x}" y="${y}" width="${CARD_W}" height="${CARD_H_BASE}" rx="14" fill="rgba(255,255,255,0.04)" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>
        <rect x="${x}" y="${y}" width="4" height="${CARD_H_BASE}" rx="2" fill="${sector.color}"/>
        <text x="${x + 20}" y="${y + 28}" font-family="system-ui,sans-serif" font-size="16" font-weight="900" fill="#ffffff">${sector.icon} ${sector.label}</text>
        <rect x="${x + 12}" y="${y + 40}" width="${CARD_W - 24}" height="1" fill="rgba(255,255,255,0.07)"/>
        ${kpiRows}
      `;
    });

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${totalW}" height="${totalH}" viewBox="0 0 ${totalW} ${totalH}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bgr" x1="0" y1="0" x2="${totalW}" y2="${totalH}" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#0f0f1a"/>
      <stop offset="100%" stop-color="#0a0a14"/>
    </linearGradient>
    <linearGradient id="acr" x1="0" y1="0" x2="${totalW}" y2="0" gradientUnits="userSpaceOnUse">
      <stop offset="0%" stop-color="#fb7185"/>
      <stop offset="50%" stop-color="#a78bfa"/>
      <stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <rect width="${totalW}" height="${totalH}" fill="url(#bgr)"/>
  <rect x="0" y="0" width="${totalW}" height="4" fill="url(#acr)"/>
  <text x="${PAD}" y="50" font-family="system-ui,sans-serif" font-size="11" fill="rgba(255,255,255,0.3)" letter-spacing="3">FLOWSTATE LIQUID WORKSPACE</text>
  <text x="${PAD}" y="82" font-family="system-ui,sans-serif" font-size="28" font-weight="900" fill="#ffffff">Rapport Global</text>
  <text x="${PAD}" y="102" font-family="system-ui,sans-serif" font-size="12" fill="rgba(255,255,255,0.4)">Synthèse de ${selected.length} secteurs · ${now}</text>
  ${cards}
  <rect x="${PAD}" y="${totalH - 44}" width="${totalW - PAD * 2}" height="1" fill="rgba(255,255,255,0.06)"/>
  <text x="${PAD}" y="${totalH - 18}" font-family="system-ui,sans-serif" font-size="11" fill="rgba(255,255,255,0.2)">Généré par FlowState · ${now} · Confidentiel</text>
</svg>`;

    const ext = format === 'img' ? 'svg' : format === 'html' ? 'svg' : 'svg';
    downloadText(svg, 'flowstate-rapport-' + datestamp() + '.' + ext, 'image/svg+xml');
    showToast('Rapport ' + format.toUpperCase() + ' téléchargé (' + selected.length + ' sections)', '📄');
  }

  /* ─────────────────────────────────────────────
     UTILITAIRES
  ───────────────────────────────────────────── */

  function downloadText(content, filename, type) {
    const blob = new Blob([content], { type: type || 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function datestamp() {
    return new Date().toISOString().slice(0, 10);
  }

  /* ─────────────────────────────────────────────
     INIT — BOUTONS DE BARRE D'OUTILS
  ───────────────────────────────────────────── */

  function initToolbar() {
    // Délégation sur tous les boutons tool-btn
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-tool]');
      if (!btn) return;
      const tool = btn.dataset.tool;
      const sector = btn.dataset.sector || 'dashboard';

      switch (tool) {
        case 'import':    openImportModal(sector); break;
        case 'export-csv': exportCSV(sector); break;
        case 'export-json': exportJSON(sector); break;
        case 'download':  downloadView(sector); break;
        case 'print':     printView(sector); break;
        case 'rapport':   openRapportModal(); break;
      }
    });
  }

  /* ─────────────────────────────────────────────
     INIT — MODAL IMPORT
  ───────────────────────────────────────────── */

  function initImportModal() {
    const overlay = document.getElementById('import-modal-overlay');
    if (!overlay) return;

    // Fermer
    const closeBtn = overlay.querySelector('#import-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closeImportModal);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeImportModal(); });

    // Confirmer
    const confirmBtn = overlay.querySelector('#import-confirm-btn');
    if (confirmBtn) confirmBtn.addEventListener('click', confirmImport);

    // Dropzone
    const dropzone = overlay.querySelector('#upload-dropzone');
    const fileInput = overlay.querySelector('#upload-file-input');
    if (dropzone && fileInput) {
      fileInput.addEventListener('change', e => handleFiles(e.target.files));
      dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
      dropzone.addEventListener('drop', e => {
        e.preventDefault();
        dropzone.classList.remove('drag-over');
        handleFiles(e.dataTransfer.files);
      });
    }
  }

  /* ─────────────────────────────────────────────
     INIT — MODAL RAPPORT
  ───────────────────────────────────────────── */

  function initRapportModal() {
    const overlay = document.getElementById('rapport-overlay');
    if (!overlay) return;

    // Fermer
    const closeBtn = overlay.querySelector('#rapport-modal-close');
    if (closeBtn) closeBtn.addEventListener('click', closeRapportModal);
    const cancelBtn = overlay.querySelector('#rapport-cancel-btn');
    if (cancelBtn) cancelBtn.addEventListener('click', closeRapportModal);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeRapportModal(); });

    // Sections à inclure
    overlay.querySelectorAll('.rapport-section-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.dataset.section;
        card.classList.toggle('selected');
        const check = card.querySelector('.rapport-section-check');
        if (card.classList.contains('selected')) {
          if (!rapportSections.includes(id)) rapportSections.push(id);
          if (check) check.textContent = '✓';
        } else {
          rapportSections = rapportSections.filter(s => s !== id);
          if (check) check.textContent = '';
        }
        renderRapportPreview();
      });
    });

    // Format
    overlay.querySelectorAll('.rapport-format-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        rapportFormat = btn.dataset.format;
        overlay.querySelectorAll('.rapport-format-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
      });
    });

    // Générer
    const genBtn = overlay.querySelector('#rapport-generate-btn');
    if (genBtn) genBtn.addEventListener('click', generateRapport);

    // Nav rapport global
    const navBtn = document.querySelector('[data-view="rapport"]');
    if (navBtn) navBtn.addEventListener('click', () => openRapportModal());

    // Actions dans #view-rapport
    document.addEventListener('click', e => {
      const btn = e.target.closest('[data-rapport-action]');
      if (!btn) return;
      const action = btn.dataset.rapportAction;
      rapportSections = Object.keys(DATA);
      if (action === 'csv') { rapportFormat = 'csv'; generateRapport(); }
      else if (action === 'img') { rapportFormat = 'img'; openRapportModal(); }
      else if (action === 'pdf') { rapportFormat = 'pdf'; openRapportModal(); }
      else if (action === 'print') { rapportFormat = 'print'; printAllSectors(); }
      else openRapportModal();
    });
  }

  function printAllSectors() {
    const now = new Date().toLocaleDateString('fr-CA', { day: 'numeric', month: 'long', year: 'numeric' });
    const sections = Object.values(DATA).map(s => {
      const rows = s.kpis.map(k => {
        const color = k.cls === 'positive' ? '#059669' : k.cls === 'negative' ? '#dc2626' : k.cls === 'info' ? '#0284c7' : '#1e293b';
        return `<tr><td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;color:#475569;font-size:13px;">${k.k}</td><td style="padding:6px 10px;border-bottom:1px solid #f1f5f9;font-weight:700;color:${color};text-align:right;font-size:13px;">${k.v}</td></tr>`;
      }).join('');
      return `<div style="margin-bottom:28px;"><h2 style="font-size:18px;font-weight:900;color:#0f172a;margin:0 0 4px;">${s.icon} ${s.label}</h2><table style="width:100%;border-collapse:collapse;"><thead><tr><th style="padding:8px 10px;background:#f8fafc;font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;text-align:left;border-bottom:2px solid #e2e8f0;">Indicateur</th><th style="padding:8px 10px;background:#f8fafc;font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;text-align:right;border-bottom:2px solid #e2e8f0;">Valeur</th></tr></thead><tbody>${rows}</tbody></table></div>`;
    }).join('');
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>FlowState — Rapport Global</title><style>body{font-family:system-ui,sans-serif;margin:40px;color:#1e293b;}h1{font-size:28px;font-weight:900;color:#0f172a;margin:0 0 4px;}p{color:#64748b;font-size:13px;margin:0 0 28px;}</style></head><body><h1>📊 Rapport Global — FlowState</h1><p>${now} · Synthèse de ${Object.keys(DATA).length} secteurs</p>${sections}</body></html>`;
    const w = window.open('', '_blank', 'width=900,height=700');
    if (!w) { showToast('Autoriser les popups pour imprimer', '⚠️'); return; }
    w.document.write(html);
    w.document.close();
    w.focus();
    setTimeout(() => { w.print(); w.close(); }, 500);
    showToast('Impression du rapport global lancée', '🖨️');
  }

  /* ─────────────────────────────────────────────
     REMPLIR VUE RAPPORT GLOBAL
  ───────────────────────────────────────────── */

  function renderRapportView() {
    const grid = document.getElementById('rapport-kpi-grid');
    if (!grid) return;
    grid.innerHTML = Object.entries(DATA).map(([id, s]) => `
      <div class="rapport-card">
        <div class="rapport-card-header">
          <div class="rapport-card-icon" style="background:${s.color}18;font-size:1.1rem;">${s.icon}</div>
          <div>
            <div class="rapport-card-title">${s.label}</div>
            <div class="rapport-card-sub">${s.kpis.length} indicateurs</div>
          </div>
        </div>
        <div class="rapport-card-kpis">
          ${s.kpis.map(k => `<div class="rapport-kpi-row"><span>${k.k}</span><span class="rapport-kpi-val${k.cls ? ' ' + k.cls : ''}">${k.v}</span></div>`).join('')}
        </div>
      </div>
    `).join('');
  }

  /* ─────────────────────────────────────────────
     INIT PRINCIPAL
  ───────────────────────────────────────────── */

  function init() {
    initToolbar();
    initImportModal();
    initRapportModal();

    // Remplir la vue rapport si elle existe
    const viewRapport = document.getElementById('view-rapport');
    if (viewRapport) {
      const observer = new MutationObserver(() => {
        if (!viewRapport.classList.contains('view-hidden')) renderRapportView();
      });
      observer.observe(viewRapport, { attributes: true, attributeFilter: ['class'] });
      // Si déjà visible
      if (!viewRapport.classList.contains('view-hidden')) renderRapportView();
      // Clic nav
      const navBtn = document.querySelector('[data-view="rapport"]');
      if (navBtn) navBtn.addEventListener('click', () => setTimeout(renderRapportView, 100));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();

})();
