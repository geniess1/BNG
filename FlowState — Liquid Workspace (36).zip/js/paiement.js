/* ═══════════════════════════════════════════════════════════════
   FlowState — Module Paiement & Abonnements
   paiement.js — Gestion plans, formulaire, historique
   ═══════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── État ─────────────────────────────────────────────────── */
  const STATE = {
    isAnnual: false,
    selectedPlan: 'pro',
    currentPlan: 'free', // plan actuel simulé
    couponApplied: false,
    couponDiscount: 0,
  };

  const PLANS = {
    free: { name: 'Starter', price_monthly: 0, price_annual: 0, icon: '🚀' },
    pro:  { name: 'Pro', price_monthly: 29, price_annual: 23, icon: '⚡' },
    enterprise: { name: 'Entreprise', price_monthly: 89, price_annual: 71, icon: '🏢' },
  };

  const COUPONS = {
    'FLOW20': { discount: 20, label: '20% de réduction appliquée' },
    'BIENVENUE': { discount: 15, label: '15% de réduction pour nouveaux membres' },
    'ANNUAL30': { discount: 30, label: '30% de réduction exclusive' },
  };

  /* ── Init ─────────────────────────────────────────────────── */
  const viewEl = document.getElementById('view-paiement');
  if (!viewEl) return;

  const obs = new MutationObserver(mutations => {
    mutations.forEach(mut => {
      if (mut.attributeName === 'class' && !mut.target.classList.contains('view-hidden')) {
        initPaiement();
      }
    });
  });
  obs.observe(viewEl, { attributes: true });
  if (!viewEl.classList.contains('view-hidden')) initPaiement();

  document.addEventListener('click', e => {
    if (e.target.closest('[data-view="paiement"]')) setTimeout(initPaiement, 80);
  });

  let inited = false;
  function initPaiement() {
    if (inited) return;
    inited = true;

    setupBillingToggle();
    setupPlanCards();
    setupPlanTabs();
    setupCardPreview();
    setupCoupon();
    setupFormSubmit();
    setupSuccessModal();
    setupHistoryActions();
    updateSummary();
  }

  /* ── Toggle mensuel/annuel ───────────────────────────────── */
  function setupBillingToggle() {
    const sw = document.getElementById('billing-switch');
    const labelMonthly = document.getElementById('label-monthly');
    const labelAnnual = document.getElementById('label-annual');

    sw && sw.addEventListener('click', () => {
      STATE.isAnnual = !STATE.isAnnual;
      sw.classList.toggle('annual', STATE.isAnnual);
      if (labelMonthly) labelMonthly.classList.toggle('active', !STATE.isAnnual);
      if (labelAnnual)  labelAnnual.classList.toggle('active', STATE.isAnnual);
      updatePlanPrices();
      updateSummary();
    });
  }

  function updatePlanPrices() {
    document.querySelectorAll('[data-plan]').forEach(card => {
      const plan = card.dataset.plan;
      if (!PLANS[plan]) return;
      const priceEl = card.querySelector('.amount');
      const noteEl  = card.querySelector('.plan-annual-note');
      const p = PLANS[plan];
      if (priceEl) {
        priceEl.textContent = STATE.isAnnual ? p.price_annual : p.price_monthly;
        priceEl.setAttribute('data-target-price', STATE.isAnnual ? p.price_annual : p.price_monthly);
      }
      if (noteEl) {
        noteEl.style.display = STATE.isAnnual ? '' : 'none';
      }
    });
  }

  /* ── Sélection plan ──────────────────────────────────────── */
  function setupPlanCards() {
    document.querySelectorAll('.plan-cta[data-select-plan]').forEach(btn => {
      if (btn.classList.contains('current-plan')) return;
      btn.addEventListener('click', () => {
        const plan = btn.dataset.selectPlan;
        if (!plan || plan === STATE.currentPlan) return;
        selectPlan(plan);
        // Scroll vers formulaire
        const checkout = document.getElementById('pay-checkout');
        checkout && checkout.scrollIntoView({ behavior: 'smooth', block: 'start' });
        showPayToast(`Plan ${PLANS[plan]?.name} sélectionné`, '⚡');
      });
    });
  }

  function selectPlan(plan) {
    STATE.selectedPlan = plan;
    // Highlight carte
    document.querySelectorAll('.plan-card').forEach(c => c.classList.remove('selected-plan'));
    const card = document.querySelector(`.plan-card[data-plan="${plan}"]`);
    card && card.classList.add('selected-plan');
    // Sync tabs
    document.querySelectorAll('.plan-select-tab').forEach(t => {
      t.classList.toggle('active', t.dataset.selectTab === plan);
    });
    updateSummary();
  }

  function setupPlanTabs() {
    document.querySelectorAll('.plan-select-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        selectPlan(tab.dataset.selectTab);
      });
    });
  }

  /* ── Résumé commande ─────────────────────────────────────── */
  function updateSummary() {
    const plan = PLANS[STATE.selectedPlan];
    if (!plan) return;

    const price = STATE.isAnnual ? plan.price_annual : plan.price_monthly;
    const cycle = STATE.isAnnual ? 'an' : 'mois';

    const nameEl   = document.getElementById('summary-plan-name');
    const cycleEl  = document.getElementById('summary-plan-cycle');
    const iconEl   = document.getElementById('summary-plan-icon');
    const subEl    = document.getElementById('summary-subtotal');
    const discEl   = document.getElementById('summary-discount-row');
    const discValEl= document.getElementById('summary-discount-val');
    const taxEl    = document.getElementById('summary-tax');
    const totalEl  = document.getElementById('summary-total');

    if (nameEl) nameEl.textContent = `FlowState ${plan.name}`;
    if (cycleEl) cycleEl.textContent = `Facturation ${STATE.isAnnual ? 'annuelle' : 'mensuelle'}`;
    if (iconEl) iconEl.textContent = plan.icon;

    const subtotal = price;
    const annual_bonus = STATE.isAnnual ? Math.round(price * 0.2) : 0;
    let discountAmt = STATE.couponApplied ? Math.round(subtotal * STATE.couponDiscount / 100) : 0;
    const taxable = subtotal - discountAmt;
    const tps = Math.round(taxable * 0.05 * 100) / 100;
    const tvq = Math.round(taxable * 0.09975 * 100) / 100;
    const total = (taxable + tps + tvq).toFixed(2);

    if (subEl) subEl.textContent = `${subtotal} $ / ${cycle}`;
    if (taxEl) taxEl.textContent = `${(tps + tvq).toFixed(2)} $`;
    if (totalEl) totalEl.textContent = `${total} $`;

    if (discEl) {
      discEl.style.display = STATE.couponApplied ? '' : 'none';
      if (discValEl) discValEl.textContent = `-${discountAmt} $`;
    }

    // Bouton payer
    const submitBtn = document.getElementById('pay-submit-btn');
    if (submitBtn) {
      const submitText = submitBtn.querySelector('.pay-submit-text');
      if (submitText) {
        submitText.textContent = price === 0 ? 'Activer le plan gratuit' : `Payer ${total} $`;
      }
    }
  }

  /* ── Prévisualisation carte ──────────────────────────────── */
  function setupCardPreview() {
    const numInput  = document.getElementById('card-number');
    const nameInput = document.getElementById('cardholder');
    const expInput  = document.getElementById('card-expiry');

    const previewNum  = document.getElementById('preview-number');
    const previewName = document.getElementById('preview-name');
    const previewExp  = document.getElementById('preview-exp');

    numInput && numInput.addEventListener('input', e => {
      let val = e.target.value.replace(/\D/g, '').substring(0, 16);
      val = val.replace(/(.{4})/g, '$1 ').trim();
      e.target.value = val;
      if (previewNum) {
        const raw = val.replace(/\s/g, '');
        const padded = raw.padEnd(16, '•');
        previewNum.textContent = padded.replace(/(.{4})/g, '$1 ').trim();
      }
    });

    nameInput && nameInput.addEventListener('input', e => {
      if (previewName) previewName.textContent = e.target.value.toUpperCase() || 'VOTRE NOM';
    });

    expInput && expInput.addEventListener('input', e => {
      let val = e.target.value.replace(/\D/g, '').substring(0, 4);
      if (val.length >= 3) val = val.substring(0, 2) + '/' + val.substring(2);
      e.target.value = val;
      if (previewExp) previewExp.textContent = val || 'MM/AA';
    });
  }

  /* ── Coupon ──────────────────────────────────────────────── */
  function setupCoupon() {
    const btn   = document.getElementById('coupon-apply-btn');
    const input = document.getElementById('coupon-input');
    const msg   = document.getElementById('coupon-msg');

    btn && btn.addEventListener('click', () => {
      const code = (input ? input.value.trim().toUpperCase() : '');
      if (!code) return;

      const coupon = COUPONS[code];
      if (coupon) {
        STATE.couponApplied = true;
        STATE.couponDiscount = coupon.discount;
        if (msg) {
          msg.textContent = '✓ ' + coupon.label;
          msg.style.color = '#34d399';
          msg.style.display = '';
        }
        if (btn) btn.textContent = 'Appliqué ✓';
        btn && (btn.style.color = '#34d399');
        showPayToast(coupon.label, '🎉');
        updateSummary();
      } else {
        if (msg) {
          msg.textContent = '✗ Code invalide. Essayez FLOW20';
          msg.style.color = '#fb7185';
          msg.style.display = '';
        }
        STATE.couponApplied = false;
        STATE.couponDiscount = 0;
        updateSummary();
      }
    });
  }

  /* ── Soumission formulaire ───────────────────────────────── */
  function setupFormSubmit() {
    const form = document.getElementById('pay-checkout-form');
    const btn  = document.getElementById('pay-submit-btn');

    form && form.addEventListener('submit', e => {
      e.preventDefault();
      if (!validateForm()) return;

      // Simuler chargement
      btn && btn.classList.add('loading');

      setTimeout(() => {
        btn && btn.classList.remove('loading');
        openSuccessModal();
      }, 2200);
    });
  }

  function validateForm() {
    const fields = ['cardholder', 'card-number', 'card-expiry', 'card-cvv'];
    let valid = true;

    fields.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const val = el.value.trim();
      if (!val) {
        el.style.borderColor = 'rgba(251,113,133,.5)';
        el.style.background  = 'rgba(251,113,133,.07)';
        valid = false;
        setTimeout(() => {
          el.style.borderColor = '';
          el.style.background  = '';
        }, 2000);
      }
    });

    if (!valid) showPayToast('Veuillez remplir tous les champs requis', '⚠️');
    return valid;
  }

  /* ── Modale succès ───────────────────────────────────────── */
  function setupSuccessModal() {
    const overlay = document.getElementById('pay-success-overlay');
    const closeBtn = document.getElementById('pay-success-close');

    closeBtn && closeBtn.addEventListener('click', () => {
      overlay && overlay.classList.remove('open');
      // Simuler changement de plan
      STATE.currentPlan = STATE.selectedPlan;
      updateCurrentPlanBanner();
      showPayToast(`Plan ${PLANS[STATE.selectedPlan]?.name} activé avec succès !`, '✅');
      // Ajouter à l'historique
      addHistoryEntry();
    });

    overlay && overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  }

  function openSuccessModal() {
    const overlay  = document.getElementById('pay-success-overlay');
    const planName = document.getElementById('success-plan-name');
    if (planName) planName.textContent = `FlowState ${PLANS[STATE.selectedPlan]?.name}`;
    overlay && overlay.classList.add('open');
  }

  function updateCurrentPlanBanner() {
    const banner = document.getElementById('current-plan-banner');
    const bannerName = document.getElementById('current-plan-name');
    const bannerSub  = document.getElementById('current-plan-sub');
    if (!banner) return;

    const plan = PLANS[STATE.currentPlan];
    if (bannerName) bannerName.textContent = `Plan actuel : FlowState ${plan?.name}`;
    if (bannerSub) {
      const price = STATE.isAnnual ? plan?.price_annual : plan?.price_monthly;
      bannerSub.textContent = price ? `${price} $ / ${STATE.isAnnual ? 'mois (annuel)' : 'mois'}` : 'Gratuit';
    }
    banner.style.display = '';
  }

  /* ── Historique ──────────────────────────────────────────── */
  function setupHistoryActions() {
    document.querySelectorAll('.pay-download-btn').forEach(btn => {
      btn.addEventListener('click', () => showPayToast('Facture téléchargée', '📄'));
    });
  }

  function addHistoryEntry() {
    const tbody = document.getElementById('history-tbody');
    if (!tbody) return;
    const plan = PLANS[STATE.selectedPlan];
    const price = STATE.isAnnual ? plan?.price_annual : plan?.price_monthly;
    const now = new Date().toLocaleDateString('fr-CA');
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="pay-history-date">${now}</td>
      <td>FlowState ${plan?.name} — ${STATE.isAnnual ? 'Annuel' : 'Mensuel'}</td>
      <td><span class="pay-status-badge paid">Payé</span></td>
      <td class="pay-history-amount">${price} $</td>
      <td><button class="pay-download-btn" title="Télécharger la facture">
        <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" width="14" height="14">
          <path d="M10 3v10M6 9l4 4 4-4M4 17h12" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </button></td>`;
    tbody.prepend(tr);
    tr.animate([
      { opacity: 0, transform: 'translateX(-10px)' },
      { opacity: 1, transform: 'translateX(0)' }
    ], { duration: 350, easing: 'cubic-bezier(.16,1,.3,1)', fill: 'both' });
    tr.querySelector('.pay-download-btn')?.addEventListener('click', () => showPayToast('Facture téléchargée', '📄'));
  }

  /* ── Toast ───────────────────────────────────────────────── */
  function showPayToast(msg, icon = '✓') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<span style="font-size:.95rem">${icon}</span><span>${msg}</span>`;
    container.appendChild(toast);
    setTimeout(() => {
      toast.classList.add('removing');
      setTimeout(() => toast.remove(), 280);
    }, 2800);
  }

})();
